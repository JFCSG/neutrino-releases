"""
path_targets.py - Local PATH command accept registry for Neutrino Apply.
Controls /etc/neutrino/apply.d/path-wrap.json:
1. Local accept registry for /usr/local/bin executables.
2. Refuses prohibited binaries: python3, bash, sh, ssh, sudo, apt, systemctl,
   anything in /bin or /usr/bin, and deny list.
3. Schema version 1:
   {
     "version": 1,
     "commands": [
       {
         "basename": "nightly-etl",
         "class": "etl",
         "accepted": true
       }
     ]
   }
Standard library only. Zero external dependencies.
"""

import json
import os
import secrets
from typing import Dict, Any, List, Optional, Set

from neutrino.capture.recipe import DENY_BASENAMES, check_deny_match, ALL_CLASSES

DEFAULT_PATH_WRAP_JSON = "/etc/neutrino/apply.d/path-wrap.json"

PROHIBITED_PATH_SHIMS: Set[str] = {
    "python",
    "python3",
    "python3.10",
    "python3.11",
    "python3.12",
    "bash",
    "sh",
    "dash",
    "zsh",
    "ssh",
    "sshd",
    "sudo",
    "su",
    "apt",
    "apt-get",
    "dpkg",
    "rpm",
    "systemctl",
    "journalctl",
    "init",
    "cron",
    "crond",
    "run-parts",
    "neutrino",
    "neutrino-run",
    "kernel",
    "udev",
    "dbus",
    "neutrino-enable-shims",
    "neutrino-capture-helper",
    "neutrino-oltp-load",
    "neutrino-mq-append",
    "neutrino-bsub",
    "neutrino-srun",
    "neutrino-setup",
}


def get_path_wrap_path(root: str = "/", apply_dir: Optional[str] = None) -> str:
    """Returns absolute path to path-wrap.json under root or apply_dir."""
    if apply_dir:
        return os.path.join(apply_dir, "path-wrap.json")
    return os.path.join(root, "etc", "neutrino", "apply.d", "path-wrap.json")


def load_path_targets(root: str = "/", apply_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    Loads path-wrap.json under root.
    Returns {"version": 1, "commands": []} if missing or invalid.
    """
    path = get_path_wrap_path(root, apply_dir=apply_dir)
    if not os.path.isfile(path):
        return {"version": 1, "commands": []}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if (
                isinstance(data, dict)
                and data.get("version") == 1
                and isinstance(data.get("commands"), list)
            ):
                return data
    except Exception:
        pass
    return {"version": 1, "commands": []}


def save_path_targets(path_data: Dict[str, Any], root: str = "/", apply_dir: Optional[str] = None) -> str:
    """
    Atomically writes path-wrap.json under root with mode 0640.
    Attempts group chown to 'neutrino' if running as root.
    """
    if (
        not isinstance(path_data, dict)
        or path_data.get("version") != 1
        or not isinstance(path_data.get("commands"), list)
    ):
        raise ValueError("Invalid path_data: must be dict with version=1 and list 'commands'")

    path = get_path_wrap_path(root, apply_dir=apply_dir)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    tmp_path = f"{path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(path_data, f, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())

    if neutrino_gid is not None and os.geteuid() == 0:
        try:
            os.chown(tmp_path, -1, neutrino_gid)
        except OSError:
            pass

    os.chmod(tmp_path, 0o640)
    os.replace(tmp_path, path)
    return path


def find_path_command(basename: str, path_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Finds command entry in path_data by basename (case-sensitive)."""
    norm = basename.strip()
    for cmd in path_data.get("commands", []):
        if isinstance(cmd, dict) and cmd.get("basename") == norm:
            return cmd
    return None


def accept_path_command(
    basename: str,
    feature_class: Optional[str] = None,
    root: str = "/",
) -> Dict[str, Any]:
    """
    Accepts a single command into path-wrap.json.
    Enforces:
    1. Basename must not be in PROHIBITED_PATH_SHIMS or DENY_BASENAMES.
    2. Target executable must exist under /usr/local/bin/<basename> (or under root).
    3. Never wraps system binaries in /bin or /usr/bin.
    4. Enforces valid class mapping.
    """
    cmd_clean = os.path.basename(basename.strip())
    if not cmd_clean:
        raise ValueError("Empty command basename")

    if cmd_clean.lower() in PROHIBITED_PATH_SHIMS:
        raise ValueError(f"Command '{cmd_clean}' is prohibited from PATH shimming")

    deny_hit = check_deny_match(cmd_clean, set(DENY_BASENAMES))
    if deny_hit:
        raise ValueError(f"Command '{cmd_clean}' matches denied basename '{deny_hit}'")

    # Check executable existence in /usr/local/bin
    local_bin_path = os.path.join(root, "usr", "local", "bin", cmd_clean)
    if not os.path.isfile(local_bin_path):
        raise FileNotFoundError(f"Command '{cmd_clean}' not found in /usr/local/bin: {local_bin_path}")

    if not os.access(local_bin_path, os.X_OK):
        raise PermissionError(f"Target '{local_bin_path}' is not executable")

    path_data = load_path_targets(root=root)
    existing = find_path_command(cmd_clean, path_data)

    target_class = None
    if feature_class:
        target_class = str(feature_class).strip().lower()
    elif existing and existing.get("class"):
        target_class = str(existing.get("class")).strip().lower()

    if not target_class:
        return {
            "ok": False,
            "status": "need_class",
            "basename": cmd_clean,
            "message": f"Command '{cmd_clean}' has no class mapping. Pass --class <class> to accept.",
        }

    all_set = set(ALL_CLASSES)
    if target_class not in all_set:
        raise ValueError(f"Unknown class '{target_class}'. Allowed: {sorted(all_set)}")

    if existing:
        existing["class"] = target_class
        existing["accepted"] = True
    else:
        path_data["commands"].append({
            "basename": cmd_clean,
            "class": target_class,
            "accepted": True,
        })

    save_path_targets(path_data, root=root)
    return {
        "ok": True,
        "status": "accepted",
        "basename": cmd_clean,
        "class": target_class,
        "accepted": True,
    }


def remove_path_command(basename: str, root: str = "/") -> bool:
    """Removes a command entry from path-wrap.json."""
    data = load_path_targets(root=root)
    norm = basename.strip()
    orig_len = len(data.get("commands", []))
    data["commands"] = [
        c for c in data.get("commands", [])
        if isinstance(c, dict) and c.get("basename") != norm
    ]
    if len(data["commands"]) != orig_len:
        save_path_targets(data, root=root)
        return True
    return False
