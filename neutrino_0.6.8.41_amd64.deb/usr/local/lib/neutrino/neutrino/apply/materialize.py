"""
materialize.py - Compile workload artifact materialization helper for Neutrino.
Maintains bytecode caches (PYTHONPYCACHEPREFIX) for warm reuse instead of clean-rebuild wiping.
Standard library only. Zero external dependencies.
"""

import os
import sys
from typing import Dict, Any, Optional, Tuple

from neutrino.apply.manager import get_active_policy

DEFAULT_CACHE_DIR = "/var/lib/neutrino/cache"


def resolve_compile_materialize(
    job_class: str,
    cfg: Optional[Dict[str, Any]] = None,
    current_env: Optional[Dict[str, str]] = None,
) -> Tuple[bool, Optional[str], Optional[Dict[str, str]], str]:
    """
    Evaluates whether bytecode cache materialization should be applied to child workload.

    Rules:
    1. Only active when job_class == "compile" AND apply.d/compile.enabled AND claims.apply.
    2. When active:
       - Set env PYTHONPYCACHEPREFIX to /var/lib/neutrino/cache/pyc/<uid> if unset by user.
       - Directory created with mode 0750 (neutrino group if available).
       - Never delete __pycache__ or *.pyc files.
       - Helper never performs recursive deletion or deletes buyer source paths.
       - Refuses to implement "clean rebuild" as a lever.
       Returns (True, cache_dir, modified_env, "pycache")
    3. When disabled or other class:
       Returns (False, None, current_env or dict(os.environ), "default")
    """
    cfg = cfg or {}
    child_env = dict(current_env if current_env is not None else os.environ)
    norm_class = str(job_class or "unspecified").strip().lower()

    if norm_class != "compile":
        return False, None, child_env, "not_compile_class"

    policy = get_active_policy("compile", cfg)
    if not policy.get("applied"):
        return False, None, child_env, "not_applied"

    uid = os.getuid()
    cache_base = cfg.get("cache_dir", DEFAULT_CACHE_DIR)
    cache_dir = os.path.join(cache_base, "pyc", str(uid))

    try:
        os.makedirs(cache_dir, mode=0o750, exist_ok=True)
        try:
            import grp
            gid = grp.getgrnam("neutrino").gr_gid
            os.chown(cache_dir, -1, gid)
        except Exception:
            pass
    except Exception:
        pass

    if "PYTHONPYCACHEPREFIX" not in child_env:
        child_env["PYTHONPYCACHEPREFIX"] = cache_dir

    return True, cache_dir, child_env, "pycache"
