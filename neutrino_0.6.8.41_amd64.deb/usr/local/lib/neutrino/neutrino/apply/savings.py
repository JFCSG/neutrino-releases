"""
savings.py - Policy version period savings accounting.
Computes descriptive energy delta and percentage change across policy version periods
from history.jsonl and jobs.jsonl.
Standard library only. Zero external dependencies.
"""

import json
import os
import time
from typing import Dict, Any, List, Optional

from neutrino.config import DEFAULT_APPLY_HISTORY_FILE, DEFAULT_JOBS_FILE

VALID_CLASSES = {
    "compile",
    "batch",
    "mq",
    "oltp",
    "oltp-conn",
    "hpc",
    "infer-cpu",
    "render",
}


def calculate_apply_savings(
    feature_class: str,
    cfg: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Computes descriptive energy savings across policy version periods for a given feature class.

    Standing Rules:
    - Same class only (no cross-class comparisons).
    - Real measured energy sum (no idle subtraction).
    - Jobs with t < 1s are excluded from mean power, but included in total energy.
    - If fewer than 2 periods exist, need_observe=True and no %E is computed.
    - Fails closed on 'unspecified' or unknown class.
    """
    norm_class = str(feature_class or "").strip().lower()
    if not norm_class or norm_class == "unspecified":
        raise ValueError("Class 'unspecified' cannot be evaluated for savings (meter-only class)")

    if norm_class not in VALID_CLASSES:
        raise ValueError(f"Unknown or unmanaged class '{feature_class}'")

    cfg = cfg or {}
    history_file = cfg.get("apply_history_file", DEFAULT_APPLY_HISTORY_FILE)
    jobs_file = cfg.get("jobs_file", DEFAULT_JOBS_FILE)

    # 1. Load history events for this class
    events: List[Dict[str, Any]] = []
    if os.path.isfile(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            ev = json.loads(line)
                            feat = ev.get("feature") or ev.get("class")
                            if feat == norm_class:
                                events.append(ev)
                        except Exception:
                            pass
        except OSError:
            pass

    # Sort events chronologically by t_start
    events.sort(key=lambda x: float(x.get("t_start") or x.get("t0") or 0.0))

    # 2. Load all matching jobs
    all_jobs: List[Dict[str, Any]] = []
    if os.path.isfile(jobs_file):
        try:
            with open(jobs_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            j = json.loads(line)
                            j_cls = j.get("class") or j.get("policy", {}).get("class")
                            if j_cls == norm_class:
                                all_jobs.append(j)
                        except Exception:
                            pass
        except OSError:
            pass

    # 3. Partition jobs into period windows
    periods: List[Dict[str, Any]] = []
    prev_energy: Optional[float] = None
    now = time.time()
    n_periods = len(events)
    need_observe = n_periods < 2

    for ev in events:
        v_id = ev.get("version_id")
        action = ev.get("event") or ev.get("action")
        t0 = float(ev.get("t_start") if ev.get("t_start") is not None else ev.get("t0", 0.0))
        raw_t1 = ev.get("t_end") if ev.get("t_end") is not None else ev.get("t1")
        t1 = float(raw_t1) if raw_t1 is not None else None
        effective_t1 = t1 if t1 is not None else now

        period_jobs = [
            j for j in all_jobs
            if t0 <= float(j.get("t_start", 0.0)) < effective_t1
        ]

        n_jobs = len(period_jobs)
        sum_energy_j = round(sum(float(j.get("energy_j", 0.0)) for j in period_jobs), 3)

        # Mean power: ONLY for jobs with t_elapsed_s >= 1.0s
        ge_1s_jobs = [
            j for j in period_jobs
            if float(j.get("t_elapsed_s", 0.0)) >= 1.0
        ]
        mean_p_w: Optional[float] = None
        if ge_1s_jobs:
            mean_p_w = round(sum(float(j.get("p_mean_w", 0.0)) for j in ge_1s_jobs) / len(ge_1s_jobs), 3)

        mean_t_s: Optional[float] = None
        if n_jobs > 0:
            mean_t_s = round(sum(float(j.get("t_elapsed_s", 0.0)) for j in period_jobs) / n_jobs, 3)

        # Comparisons vs previous period
        delta_e_j: Optional[float] = None
        pct_energy: Optional[float] = None

        if prev_energy is not None:
            delta_e_j = round(sum_energy_j - prev_energy, 3)
            if not need_observe and prev_energy > 0:
                pct_energy = round((sum_energy_j - prev_energy) / prev_energy * 100.0, 2)

        periods.append({
            "version_id": v_id,
            "action": action,
            "t0": t0,
            "t1": t1,
            "duration_s": round(effective_t1 - t0, 2),
            "n_jobs": n_jobs,
            "sum_energy_j": sum_energy_j,
            "mean_power_w": mean_p_w,
            "mean_t_s": mean_t_s,
            "delta_energy_prev_j": delta_e_j,
            "pct_energy_prev": pct_energy,
            "restored_from": ev.get("restored_from"),
        })

        prev_energy = sum_energy_j

    return {
        "ok": True,
        "class": norm_class,
        "note": "descriptive; no idle baseline",
        "need_observe": need_observe,
        "n_periods": n_periods,
        "periods": periods,
    }

