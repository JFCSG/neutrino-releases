"""
autopilot.py - Licensed once-and-forget autonomous energy governor for Neutrino.
Applies empirical priors and windowed live Delta E qualification to recipe classes.
Standard library only. Zero external dependencies. Zero host literals.
"""

import os
import json
import time
import datetime
from typing import Dict, Any, List, Optional, Tuple

from neutrino.config import (
    DEFAULT_RECIPE_JSON_PATH,
    DEFAULT_CONFIG_PATH,
    DEFAULT_JOBS_FILE,
    load_config,
)
from neutrino.capture.systemd import (
    dummy_status,
    get_target_status,
    attach_target,
    detach_target,
)
from neutrino.apply.recipe import get_recipe_targets
from neutrino.apply.manager import (
    DEFAULT_APPLY_DIR,
    DEFAULT_APPLY_STATE_DIR,
    apply_approve,
    apply_revoke,
    apply_status,
    ALL_CLASSES,
    SAVINGS_ELIGIBLE_CLASSES,
    METER_ONLY_CLASSES,
)

PRIOR_ON = frozenset({"compile", "infer-cpu", "batch", "oltp", "mq", "hpc", "render"})
PRIOR_OFF = frozenset({"etl", "idle", "heartbeat", "unspecified", "compute"})
DELTA_E_GATE = -0.05
MIN_N = 5
MIN_T = 1.0
HOLDOUT_EVERY = 20

DEFAULT_AUTOPILOT_LAST_FILE = "/var/lib/neutrino/apply/autopilot-last.json"



def get_effective_meter_only(
    cfg: Optional[Dict[str, Any]] = None,
    recipe_classes: Optional[Dict[str, Any]] = None,
) -> set:
    """
    Returns effective set of meter-only classes.
    Always includes METER_ONLY_CLASSES ('idle', 'heartbeat', 'unspecified').
    Includes any additional meter-only classes from cfg['meter_only'], recipe_classes, or recipe file.
    """
    cfg = cfg or {}
    res = set(METER_ONLY_CLASSES)
    if "meter_only" in cfg and isinstance(cfg["meter_only"], (list, tuple, set)):
        res.update(str(x).strip().lower() for x in cfg["meter_only"])
        return res
    rec = cfg.get("recipe")
    if isinstance(rec, dict) and "meter_only" in rec and isinstance(rec["meter_only"], (list, tuple, set)):
        res.update(str(x).strip().lower() for x in rec["meter_only"])
        return res
    if recipe_classes and isinstance(recipe_classes, dict):
        has_meter_flag = False
        for k, v in recipe_classes.items():
            if isinstance(v, dict) and v.get("meter_only") is True:
                res.add(str(k).strip().lower())
                has_meter_flag = True
        if "recipe_json_file" not in cfg:
            return res
    recipe_path = cfg.get("recipe_json_file", os.environ.get("NU_RECIPE", DEFAULT_RECIPE_JSON_PATH))
    if os.path.isfile(recipe_path):
        from neutrino.apply.recipe import get_meter_only_classes
        res.update(str(x).strip().lower() for x in get_meter_only_classes(recipe_path))
    return res

def get_window_start(
    feature_class: str,
    cfg: Optional[Dict[str, Any]] = None,
    now: Optional[float] = None,
) -> float:
    """
    Window start T0 for class C:
    If class is enabled:
      Returns active window start t_start (or mtime of enable file, taking max with autopilot.enabled if not in future).
    If class is disabled:
      Returns now (fresh window for next pass).
    """
    cfg = cfg or {}
    current_time = now if now is not None else time.time()
    norm_class = str(feature_class or "").strip().lower()

    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)

    enable_path = os.path.join(apply_dir, f"{norm_class}.enabled")
    if os.path.isfile(enable_path):
        t0 = None
        try:
            with open(enable_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                ts = data.get("t_start")
                if ts is not None and float(ts) > 0:
                    t0 = float(ts)
        except Exception:
            pass
        if t0 is None:
            try:
                mtime = os.path.getmtime(enable_path)
                if mtime > 0:
                    t0 = float(mtime)
            except OSError:
                pass

        if t0 is not None:
            autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
            if os.path.isfile(autopilot_flag):
                try:
                    auto_mtime = os.path.getmtime(autopilot_flag)
                    # Respect auto_mtime only if not in the future relative to current_time
                    if auto_mtime > 0 and auto_mtime <= current_time:
                        t0 = max(t0, float(auto_mtime))
                except OSError:
                    pass
            return float(t0)

    # If enable_path not found, but autopilot.enabled exists:
    autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
    if os.path.isfile(autopilot_flag):
        auto_ts = None
        try:
            with open(autopilot_flag, "r", encoding="utf-8") as f:
                auto_data = json.load(f)
                ts = auto_data.get("ts")
                if ts is not None and float(ts) > 0:
                    auto_ts = float(ts)
        except Exception:
            pass
        if auto_ts is None:
            try:
                auto_mtime = os.path.getmtime(autopilot_flag)
                if auto_mtime > 0 and auto_mtime <= current_time:
                    auto_ts = float(auto_mtime)
            except OSError:
                pass
        if auto_ts is not None:
            return float(auto_ts)

    # Class is not enabled: fresh window starts at now
    return float(current_time)


def qualify_with_metrics(
    feature_class: str,
    jobs: List[Dict[str, Any]],
    recipe_classes: Optional[Any] = None,
    cfg: Optional[Dict[str, Any]] = None,
    t0: Optional[float] = None,
    now: Optional[float] = None,
) -> Tuple[str, Optional[float]]:
    """
    Evaluates whether feature_class qualifies for policy enablement.
    Returns: (status, delta_e)
    status: "on" | "off" | "watching"
    """
    norm_class = str(feature_class or "").strip().lower()

    # 1. Excluded classes are always off
    if norm_class in {"idle", "heartbeat", "unspecified"}:
        return "off", None

    # 2. Never enable without recipe authorization
    if recipe_classes is None:
        return "off", None

    if isinstance(recipe_classes, dict):
        if norm_class not in recipe_classes:
            return "off", None
    elif hasattr(recipe_classes, "__contains__"):
        if norm_class not in recipe_classes:
            return "off", None
    else:
        return "off", None

    # 3. Window start T0
    if t0 is None:
        if cfg and "t0" in cfg and cfg["t0"] is not None:
            t0 = float(cfg["t0"])
        else:
            t0 = get_window_start(norm_class, cfg=cfg, now=now)
    t0 = float(t0)

    # 4. Partition jobs inside the window
    on_arm = []
    off_arm = []

    for j in (jobs or []):
        if not isinstance(j, dict):
            continue
        c = j.get("class") or (j.get("policy", {}).get("class") if isinstance(j.get("policy"), dict) else None)
        if str(c).strip().lower() != norm_class:
            continue

        j_t_start = j.get("t_start")
        if j_t_start is None:
            continue
        try:
            if float(j_t_start) < t0:
                continue
        except (ValueError, TypeError):
            continue

        t_el = j.get("t_elapsed_s")
        if t_el is None:
            t_stop = j.get("t_stop")
            if t_stop is not None:
                try:
                    t_el = float(t_stop) - float(j_t_start)
                except (ValueError, TypeError):
                    t_el = None
        try:
            if t_el is None or float(t_el) < MIN_T:
                continue
        except (ValueError, TypeError):
            continue

        pol = j.get("policy") or {}
        is_holdout = (j.get("holdout") is True) or (isinstance(pol, dict) and pol.get("holdout") is True)
        is_applied = (isinstance(pol, dict) and pol.get("applied") is True)

        if is_applied and not is_holdout:
            on_arm.append(j)
        elif is_holdout:
            off_arm.append(j)

    n_on = len(on_arm)
    n_off = len(off_arm)

    # 5. Live gate contrast if n_on >= 5 and n_off >= 5
    if n_on >= MIN_N and n_off >= MIN_N:
        mean_on = sum(float(j.get("energy_j", 0.0)) for j in on_arm) / float(n_on)
        mean_off = sum(float(j.get("energy_j", 0.0)) for j in off_arm) / float(n_off)
        if mean_off <= 0:
            return "off", 0.0
        delta_e = (mean_on - mean_off) / mean_off
        if delta_e <= DELTA_E_GATE:
            return "on", delta_e
        else:
            return "off", delta_e

    # 6. Insufficient live contrast
    if norm_class in PRIOR_ON:
        return "watching", None
    if norm_class in PRIOR_OFF:
        return "off", None

    return "watching", None


def qualify(
    feature_class: str,
    jobs: List[Dict[str, Any]],
    recipe_classes: Optional[Any] = None,
    cfg: Optional[Dict[str, Any]] = None,
    t0: Optional[float] = None,
    now: Optional[float] = None,
) -> str:
    """
    Evaluates whether feature_class qualifies for policy enablement.
    Returns: "on" | "off" | "watching".
    """
    status, _ = qualify_with_metrics(
        feature_class, jobs, recipe_classes=recipe_classes, cfg=cfg, t0=t0, now=now
    )
    return status


def check_and_advance_holdout(feature_class: str, cfg: Optional[Dict[str, Any]] = None) -> bool:
    """
    Evaluates 1-in-20 holdout for an enabled class.
    Persists per-class counter in /var/lib/neutrino/apply/<class>.holdout.
    Increment first, then counter % 20 == 0.
    Holdouts are jobs 20, 40, ...
    Never holdout when class is not enabled.
    """
    cfg = cfg or {}
    apply_state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    os.makedirs(apply_state_dir, exist_ok=True)
    counter_file = os.path.join(apply_state_dir, f"{feature_class}.holdout")

    counter = 0
    if os.path.isfile(counter_file):
        try:
            with open(counter_file, "r", encoding="utf-8") as f:
                raw = f.read().strip()
                if raw:
                    counter = int(raw)
        except Exception:
            counter = 0

    counter += 1

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    tmp_file = f"{counter_file}.tmp.{os.getpid()}"
    try:
        with open(tmp_file, "w", encoding="utf-8") as f:
            f.write(f"{counter}\n")
        if neutrino_gid is not None:
            try:
                os.chown(tmp_file, -1, neutrino_gid)
            except OSError:
                pass
        try:
            os.chmod(tmp_file, 0o664)
        except OSError:
            pass
        os.replace(tmp_file, counter_file)
    except Exception:
        if os.path.exists(tmp_file):
            try:
                os.unlink(tmp_file)
            except OSError:
                pass

    return (counter % HOLDOUT_EVERY == 0)


def get_class_report_label(
    feature_class: str,
    jobs: List[Dict[str, Any]],
    recipe_classes: Optional[Any],
    cfg: Optional[Dict[str, Any]] = None,
    t0: Optional[float] = None,
    now: Optional[float] = None,
) -> str:
    """
    Determines report label for feature_class:
    - "not licensed": not in recipe classes or unlicensed
    - "meter_only": meter-only class ('idle', 'heartbeat', 'unspecified'), or 'etl' in meter_only,
                    or 'etl' without qualifying savings win
    - "saving": live gate win (n_on >= 5, n_off >= 5, delta_e <= -0.05)
    - "watching": holdout incomplete (n_off < 5 or n_on < 5) on armed/watched savings class
    - "off (retry next pass)": disabled prior-on class or failed qualification window (delta_e > -0.05)
    - "off": prior-off class disabled
    """
    cfg = cfg or {}
    norm_class = str(feature_class or "").strip().lower()

    if recipe_classes is None:
        return "not licensed"
    if isinstance(recipe_classes, dict):
        if norm_class not in recipe_classes:
            return "not licensed"
    elif hasattr(recipe_classes, "__contains__"):
        if norm_class not in recipe_classes:
            return "not licensed"
    else:
        return "not licensed"

    # 1. Permanent meter-only classes: never label "saving"
    if norm_class in METER_ONLY_CLASSES:
        return "meter_only"

    # 2. Enabled status on disk
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    enable_path = os.path.join(apply_dir, f"{norm_class}.enabled")
    if not os.path.isfile(enable_path):
        if norm_class in PRIOR_ON:
            return "off (retry next pass)"
        return "off"

    # 3. Evaluate qualification through the numeric gate
    q_status, delta_e = qualify_with_metrics(
        norm_class,
        jobs,
        recipe_classes=recipe_classes,
        cfg=cfg,
        t0=t0,
        now=now,
    )

    # 4. Check effective meter_only (recipe meter_only list or cfg) when enabled
    effective_meter_only = get_effective_meter_only(cfg, recipe_classes=recipe_classes)
    if norm_class in effective_meter_only:
        return "meter_only"

    # 5. etl special rule:
    # "etl: saving only if not in meter_only AND ΔE<=−5%; else meter_only"
    if norm_class == "etl":
        if q_status == "on" or (delta_e is not None and delta_e <= DELTA_E_GATE):
            return "saving"
        return "meter_only"

    # 6. Savings classes (compile, infer-cpu, batch, oltp, mq, hpc, render)
    if q_status == "on" or (delta_e is not None and delta_e <= DELTA_E_GATE):
        return "saving"
    elif q_status == "watching":
        return "watching"
    else:
        # Failed live gate (delta_e > -0.05)
        return "off (retry next pass)"


def autopilot_pass(cfg: Optional[Dict[str, Any]] = None, now: Optional[float] = None) -> Dict[str, Any]:
    """
    Executes one autopilot evaluation pass.
    1. Loads effective license and recipe classes. Fails safe if unlicensed.
    2. For each recipe class:
       - PRIOR_OFF -> never auto-on (revoke if enabled, keep_off if not)
       - PRIOR_ON:
         a. not currently enabled -> approve (Rule 3a: approve if enable file missing)
         b. currently enabled:
            - n_off < 5 -> keep_on (Rule 3a: ON watching)
            - n_off >= 5 and delta_e <= -0.05 -> keep_on (Rule 3b: ON saving)
            - n_off >= 5 and delta_e > -0.05 -> revoke (Rule 3c: OFF this window)
              (next pass starts a new window and goes back to 3a; do not re-approve in same pass)
    3. Writes atomic /var/lib/neutrino/apply/autopilot-last.json.
    """
    cfg = cfg or {}
    now = now if now is not None else time.time()

    from neutrino.crypto.desk_license import load_effective_license
    lic = load_effective_license(cfg, read_only=True, bind_nonce=False)
    is_licensed = bool(
        lic.get("valid") is True
        and lic.get("source") == "desk"
        and lic.get("sku") == "NEUTRINO"
        and (lic.get("apply", False) or lic.get("claims", {}).get("apply", False))
    )

    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    os.makedirs(apply_dir, exist_ok=True)
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    os.makedirs(state_dir, exist_ok=True)

    autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
    if not os.path.isfile(autopilot_flag):
        return {"ok": False, "reason": "autopilot_not_enabled", "decisions": {}}

    decisions = {}
    if not is_licensed:
        for fname in os.listdir(apply_dir):
            if fname.endswith(".enabled") and fname != "autopilot.enabled":
                cls_name = fname[:-len(".enabled")]
                apply_revoke(cls_name, cfg)
                decisions[cls_name] = {"action": "revoke", "reason": "not_licensed"}
        _record_autopilot_last(cfg, now, decisions)
        return {"ok": True, "licensed": False, "decisions": decisions}

    recipe_classes = lic.get("recipe_classes") or {}
    if not isinstance(recipe_classes, dict) or not recipe_classes:
        from neutrino.recipes import DEFAULT_AUTOPILOT_RECIPE_CLASSES
        recipe_classes = DEFAULT_AUTOPILOT_RECIPE_CLASSES

    # Only load jobs when at least one active recipe class needs evaluation
    eval_classes = [
        k for k in recipe_classes.keys()
        if str(k).strip().lower() not in {"idle", "heartbeat", "unspecified"}
    ]
    if eval_classes:
        from neutrino.jobs.tracker import load_jobs
        jobs_file = cfg.get("jobs_file", DEFAULT_JOBS_FILE)
        jobs = load_jobs(jobs_file)
    else:
        jobs = []

    recipe_path = cfg.get("recipe_json_file", os.environ.get("NU_RECIPE", DEFAULT_RECIPE_JSON_PATH))
    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))

    # Reconcile operator-safe targets (provenance, role, supervisor, churn)
    from neutrino.capture.deploy import attach_operator_safe
    try:
        attach_operator_safe(root=root, default_class="unspecified", cfg=cfg)
    except Exception:
        pass

    # Recipe targets in the paper are parsed and ignored for attach
    from neutrino.apply.targets import load_accepted_targets
    targets_data = load_accepted_targets(root=root, apply_dir=apply_dir)
    accepted_units = [u for u in targets_data.get("units", []) if u.get("accepted") is True]

    targets_by_class = {}
    for u in accepted_units:
        c_slug = str(u.get("class") or "").strip().lower()
        targets_by_class.setdefault(c_slug, []).append({
            "id": u["unit"],
            "unit": u["unit"],
            "class": c_slug,
            "kind": "systemd",
            "accepted": True,
        })

    for cls_name in sorted(recipe_classes.keys()):
        norm_cls = str(cls_name).strip().lower()
        if norm_cls in {"idle", "heartbeat", "unspecified"}:
            continue

        cls_targets = targets_by_class.get(norm_cls, [])
        enable_file = os.path.join(apply_dir, f"{norm_cls}.enabled")
        currently_enabled = os.path.isfile(enable_file)

        # 1. PRIOR_OFF classes: never auto-on
        if norm_cls in PRIOR_OFF:
            # Detach any targets of this class
            target_decs = {}
            for t in cls_targets:
                tid = t["id"]
                if get_target_status(t, root=root) == "attached":
                    detach_target(t, root=root)
                    target_decs[tid] = "detached"
                else:
                    target_decs[tid] = "not_attached"
            if currently_enabled:
                try:
                    apply_revoke(norm_cls, cfg)
                    dec = {"action": "revoke", "reason": "prior_off"}
                    if cls_targets:
                        dec["targets"] = target_decs
                    decisions[norm_cls] = dec
                except Exception as ex:
                    decisions[norm_cls] = {"action": "revoke_error", "reason": str(ex)}
            else:
                dec = {"action": "keep_off", "reason": "prior_off"}
                if cls_targets:
                    dec["targets"] = target_decs
                decisions[norm_cls] = dec
            continue

        # 2. PRIOR_ON classes:
        if norm_cls in PRIOR_ON:
            if not currently_enabled:
                # 3a: approve if enable file missing (watching, not saving yet)
                try:
                    apply_approve(norm_cls, cfg)
                    dec = {"action": "approve", "reason": "prior_on_watching"}
                    # Attach eligible accepted targets immediately without waiting for n>=5
                    target_decs = {}
                    for t in cls_targets:
                        tid = t["id"]
                        if not dummy_status(t, root=root):
                            try:
                                dummy_target(t, root=root)
                            except Exception:
                                pass
                        if dummy_status(t, root=root):
                            try:
                                cls_spec = recipe_classes.get(norm_cls, {})
                                lever = cls_spec.get("lever", "occupancy") if isinstance(cls_spec, dict) else "occupancy"
                                attach_target(t, lever=lever, root=root)
                                target_decs[tid] = "attached"
                            except Exception as ex:
                                target_decs[tid] = f"attach_error: {ex}"
                        else:
                            target_decs[tid] = "not_attached"
                    if cls_targets:
                        dec["targets"] = target_decs
                    decisions[norm_cls] = dec
                except Exception as ex:
                    decisions[norm_cls] = {"action": "approve_error", "reason": str(ex)}
            else:
                # Currently enabled: evaluate live window
                q_status, live_delta_e = qualify_with_metrics(
                    norm_cls, jobs, recipe_classes=recipe_classes, cfg=cfg, now=now
                )
                if q_status in ("on", "watching"):
                    # First attach wraps without n>=5; saving-gate is ONLY for detach if bad delta_e
                    target_decs = {}
                    for t in cls_targets:
                        tid = t["id"]
                        curr_st = get_target_status(t, root=root)
                        if curr_st == "attached":
                            target_decs[tid] = "keep_attached"
                        else:
                            if not dummy_status(t, root=root):
                                try:
                                    dummy_target(t, root=root)
                                except Exception:
                                    pass
                            if dummy_status(t, root=root):
                                try:
                                    cls_spec = recipe_classes.get(norm_cls, {})
                                    lever = cls_spec.get("lever", "occupancy") if isinstance(cls_spec, dict) else "occupancy"
                                    attach_target(t, lever=lever, root=root)
                                    target_decs[tid] = "attached"
                                except Exception as ex:
                                    target_decs[tid] = f"attach_error: {ex}"
                            else:
                                target_decs[tid] = "not_attached"
                    reason = "qualify_on_saving" if q_status == "on" else "watching_already_enabled"
                    dec = {"action": "keep_on", "reason": reason}
                    if live_delta_e is not None:
                        dec["delta_e"] = round(live_delta_e, 4)
                    if cls_targets:
                        dec["targets"] = target_decs
                    decisions[norm_cls] = dec
                elif q_status == "off":
                    # OFF this window (saving-gate fail: n>=5 and delta_e > -0.05) -> Detach targets and revoke
                    target_decs = {}
                    for t in cls_targets:
                        tid = t["id"]
                        curr_st = get_target_status(t, root=root)
                        if curr_st == "attached":
                            detach_target(t, root=root)
                            target_decs[tid] = "detached"
                        else:
                            target_decs[tid] = "not_attached"
                    try:
                        apply_revoke(norm_cls, cfg)
                        dec = {"action": "revoke", "reason": "qualify_off"}
                        if live_delta_e is not None:
                            dec["delta_e"] = round(live_delta_e, 4)
                        if cls_targets:
                            dec["targets"] = target_decs
                        decisions[norm_cls] = dec
                    except Exception as ex:
                        decisions[norm_cls] = {"action": "revoke_error", "reason": str(ex)}

    _record_autopilot_last(cfg, now, decisions)
    return {"ok": True, "licensed": True, "decisions": decisions}


pass_ = autopilot_pass
def _record_autopilot_last(cfg: Dict[str, Any], ts: float, decisions: Dict[str, Any]):
    """Atomically writes autopilot-last.json without secrets."""
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    os.makedirs(state_dir, exist_ok=True)
    target_file = cfg.get("autopilot_last_file") or os.path.join(state_dir, "autopilot-last.json")

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    payload = {
        "ts": ts,
        "utc": datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "decisions": decisions,
    }

    tmp = f"{target_file}.tmp.{os.getpid()}"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
            f.write("\n")
        if neutrino_gid is not None:
            try:
                os.chown(tmp, -1, neutrino_gid)
            except OSError:
                pass
        try:
            os.chmod(tmp, 0o664)
        except OSError:
            pass
        os.replace(tmp, target_file)
    except Exception:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def licensed_and_armed(cfg: Optional[Dict[str, Any]] = None, root: str = "/") -> bool:
    """
    Two-gate condition:
    (a) effective license valid sku=NEUTRINO source=desk apply=true
    (b) autopilot ON (/etc/neutrino/apply.d/autopilot.enabled)
    A recipe runs iff both gates are true.
    """
    cfg_dict = dict(cfg or {})
    actual_root = cfg_dict.get("root", root)
    if actual_root and actual_root != "/":
        cfg_dict.setdefault("root", actual_root)
        cfg_dict.setdefault("apply_dir", os.path.join(actual_root, "etc/neutrino/apply.d"))
        cfg_dict.setdefault("lease_json_file", os.path.join(actual_root, "etc/neutrino/lease.json"))

    lic = cfg_dict.get("_license")
    if lic is None:
        from neutrino.crypto.desk_license import load_effective_license
        lic = load_effective_license(cfg_dict, read_only=True, bind_nonce=False)

    claims = lic.get("claims", {}) if isinstance(lic.get("claims"), dict) else {}
    is_licensed = bool(
        lic.get("valid") is True
        and lic.get("source") == "desk"
        and lic.get("sku") == "NEUTRINO"
        and (lic.get("apply", False) is True or claims.get("apply", False) is True)
    )
    if not is_licensed:
        try:
            from neutrino.jobs.coverage import check_lease_apply
            is_licensed = bool(check_lease_apply(cfg_dict))
        except Exception:
            is_licensed = False

    if not is_licensed:
        return False

    apply_dir = cfg_dict.get("apply_dir", os.path.join(actual_root, "etc/neutrino/apply.d"))
    flag_path = os.path.join(apply_dir, "autopilot.enabled")
    return os.path.isfile(flag_path)


def autopilot_status(cfg: Optional[Dict[str, Any]] = None, root: str = "/") -> Dict[str, Any]:
    """Inspects active autopilot flag, desk license, and recipe registry armed/idle status."""
    cfg_dict = dict(cfg or {})
    actual_root = cfg_dict.get("root", root)
    if actual_root and actual_root != "/":
        cfg_dict.setdefault("root", actual_root)
        cfg_dict.setdefault("apply_dir", os.path.join(actual_root, "etc/neutrino/apply.d"))
        cfg_dict.setdefault("apply_state_dir", os.path.join(actual_root, "var/lib/neutrino/apply"))
        cfg_dict.setdefault("lease_json_file", os.path.join(actual_root, "etc/neutrino/lease.json"))

    apply_dir = cfg_dict.get("apply_dir", os.path.join(actual_root, "etc/neutrino/apply.d"))
    state_dir = cfg_dict.get("apply_state_dir", os.path.join(actual_root, "var/lib/neutrino/apply"))
    auto_flag = os.path.join(apply_dir, "autopilot.enabled")
    auto_enabled = os.path.isfile(auto_flag)

    lic = cfg_dict.get("_license")
    if lic is None:
        from neutrino.crypto.desk_license import load_effective_license
        lic = load_effective_license(cfg_dict, read_only=True, bind_nonce=False)

    claims = lic.get("claims", {}) if isinstance(lic.get("claims"), dict) else {}
    is_licensed = bool(
        lic.get("valid") is True
        and lic.get("source") == "desk"
        and lic.get("sku") == "NEUTRINO"
        and (lic.get("apply", False) is True or claims.get("apply", False) is True)
    )
    if not is_licensed:
        try:
            from neutrino.jobs.coverage import check_lease_apply
            is_licensed = bool(check_lease_apply(cfg_dict))
        except Exception:
            is_licensed = False

    is_armed = is_licensed and auto_enabled

    from neutrino.recipes.registry import list_registry
    recipe_rows = []
    for r in list_registry():
        is_auto = bool(r.get("auto", True))
        status_str = "ARMED" if (is_armed and is_auto) else "IDLE"
        recipe_rows.append({
            "id": r["id"],
            "class": r["class"],
            "lever": r["lever"],
            "auto": is_auto,
            "status": status_str,
        })

    last_file = cfg_dict.get("autopilot_last_file") or os.path.join(state_dir, "autopilot-last.json")
    last_info = None
    if os.path.isfile(last_file):
        try:
            with open(last_file, "r", encoding="utf-8") as f:
                last_info = json.load(f)
        except Exception:
            pass

    auto_mode = "on" if auto_enabled else ("observe" if not is_licensed else "off")

    from neutrino.apply.manager import load_revoked_classes
    armed_classes = [r["class"] for r in recipe_rows if r["status"] == "ARMED"]

    return {
        "ok": True,
        "autopilot": auto_mode,
        "licensed": is_licensed,
        "armed": is_armed,
        "recipes": recipe_rows,
        "armed_classes": sorted(list(set(armed_classes))),
        "revoked_classes": sorted(list(load_revoked_classes(cfg_dict))),
        "last_pass": last_info,
    }


def autopilot_on(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Enables licensed autopilot energy governor:
    1. Verifies license fail-closed: sku=NEUTRINO, source=desk, apply=true.
    2. Writes /etc/neutrino/apply.d/autopilot.enabled (mode 0640 root:neutrino).
    3. One backup of TOUCH_LIST under /var/lib/neutrino/install-backups/ on first enable.
    4. Attaches accepted systemd units, cron, runparts, path targets.
    5. Records history row.
    """
    cfg_dict = dict(cfg or {})
    actual_root = cfg_dict.get("root", "/")
    if actual_root and actual_root != "/":
        cfg_dict.setdefault("root", actual_root)
        cfg_dict.setdefault("apply_dir", os.path.join(actual_root, "etc/neutrino/apply.d"))
        cfg_dict.setdefault("lease_json_file", os.path.join(actual_root, "etc/neutrino/lease.json"))

    lic = cfg_dict.get("_license")
    if lic is None:
        from neutrino.crypto.desk_license import load_effective_license
        lic = load_effective_license(cfg_dict, read_only=True, bind_nonce=False)

    claims = lic.get("claims", {}) if isinstance(lic.get("claims"), dict) else {}
    is_licensed = bool(
        lic.get("valid") is True
        and lic.get("source") == "desk"
        and lic.get("sku") == "NEUTRINO"
        and (lic.get("apply", False) is True or claims.get("apply", False) is True)
    )
    if not is_licensed:
        try:
            from neutrino.jobs.coverage import check_lease_apply
            is_licensed = bool(check_lease_apply(cfg_dict))
        except Exception:
            is_licensed = False

    if not is_licensed:
        raise PermissionError("Not licensed. Metering only. License must be valid with sku=NEUTRINO, source=desk, and apply=true.")

    apply_dir = cfg_dict.get("apply_dir", os.path.join(actual_root, "etc/neutrino/apply.d"))
    os.makedirs(apply_dir, exist_ok=True)

    backup_base = cfg_dict.get("install_backup_dir", os.path.join(actual_root, "var/lib/neutrino/install-backups"))
    marker_file = os.path.join(backup_base, ".autopilot_initial_backup")
    backup_dir_path = None
    if not os.path.exists(marker_file):
        try:
            from neutrino.installer.backup import create_install_backup
            os.makedirs(backup_base, mode=0o750, exist_ok=True)
            ok, bdir, _ = create_install_backup(backup_base_dir=backup_base, prefix=actual_root)
            if ok:
                backup_dir_path = bdir
                try:
                    with open(marker_file, "w", encoding="utf-8") as mf:
                        mf.write(json.dumps({"ts": time.time(), "backup_dir": bdir}) + "\n")
                except Exception:
                    pass
        except Exception:
            pass

    autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    tmp_file = f"{autopilot_flag}.tmp.{os.getpid()}"
    with open(tmp_file, "w", encoding="utf-8") as f:
        f.write(json.dumps({"enabled": True, "ts": time.time(), "source": "autopilot"}, indent=2) + "\n")
        f.flush()
        os.fsync(f.fileno())
    if neutrino_gid is not None:
        try:
            os.chown(tmp_file, 0, neutrino_gid)
        except OSError:
            pass
    try:
        os.chmod(tmp_file, 0o640)
    except OSError:
        pass
    os.replace(tmp_file, autopilot_flag)



    history_file = cfg_dict.get("apply_history_file", os.path.join(actual_root, "var/lib/neutrino/apply/history.jsonl"))
    from neutrino.apply.manager import append_history_event
    try:
        append_history_event(
            history_file=history_file,
            feature_class="autopilot",
            version_id="autopilot",
            action="on",
            now=time.time(),
            touch_list=[autopilot_flag],
            backup_dir=backup_dir_path,
        )
    except Exception:
        pass

    from neutrino.apply.manager import load_revoked_state, save_revoked_state, DEFAULT_AUTOPILOT_CLASSES, ensure_autopilot
    try:
        rst = load_revoked_state(cfg_dict)
        rst["autopilot"] = "on"
        save_revoked_state(rst, cfg_dict)
    except Exception:
        pass

    try:
        ensure_autopilot(license=lic, cfg=cfg_dict, force_on=True)
    except Exception:
        pass



    # Attach accepted systemd targets
    attached_units = []
    try:
        from neutrino.apply.targets import load_accepted_targets
        from neutrino.capture.systemd import attach_target, get_target_status
        tdata = load_accepted_targets(root=actual_root, apply_dir=apply_dir)
        for u in tdata.get("units", []):
            u_name = u.get("unit") or u.get("id")
            if u_name:
                tspec = {"id": u_name, "unit": u_name, "class": u.get("class", "batch"), "kind": "systemd"}
                attach_target(tspec, root=actual_root)
                attached_units.append(u_name)
    except Exception:
        pass

    return {
        "ok": True,
        "autopilot": "on",
        "flag_file": autopilot_flag,
        "backup": backup_dir_path,
        "installed": attached_units,
        "attached_units": attached_units,
        "attached_cron": [],
        "attached_runparts": [],
        "attached_path": [],
        "pass": None,
        "version_id": "autopilot",
    }


def autopilot_off(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Disables autopilot energy governor:
    1. Removes autopilot.enabled flag and any legacy per-class .enabled files.
    2. Records history row.
    3. Undeploys targets.
    """
    cfg_dict = dict(cfg or {})
    actual_root = cfg_dict.get("root", os.environ.get("NU_ROOT", "/"))
    apply_dir = cfg_dict.get("apply_dir", os.path.join(actual_root, "etc/neutrino/apply.d"))

    recipe_path = cfg_dict.get("recipe_json_file", os.environ.get("NU_RECIPE", DEFAULT_RECIPE_JSON_PATH))
    from neutrino.capture.deploy import undeploy_capture
    try:
        undep_res = undeploy_capture(recipe=recipe_path, root=actual_root)
    except Exception:
        undep_res = None

    from neutrino.apply.recipe import load_recipe, save_recipe
    if os.path.isfile(recipe_path) and os.access(recipe_path, os.W_OK):
        try:
            rec = load_recipe(recipe_path, strict_targets=False)
            rec["autopilot"] = False
            save_recipe(rec, recipe_path)
        except Exception:
            pass

    autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
    if os.path.exists(autopilot_flag):
        try:
            os.unlink(autopilot_flag)
        except OSError:
            pass

    if os.path.isdir(apply_dir):
        for fname in os.listdir(apply_dir):
            if fname.endswith(".enabled") or fname == "compile_handoff.spawn":
                try:
                    os.unlink(os.path.join(apply_dir, fname))
                except OSError:
                    pass

    history_file = cfg_dict.get("apply_history_file", os.path.join(actual_root, "var/lib/neutrino/apply/history.jsonl"))
    from neutrino.apply.manager import append_history_event
    try:
        append_history_event(
            history_file=history_file,
            feature_class="autopilot",
            version_id="autopilot",
            action="off",
            now=time.time(),
            touch_list=[autopilot_flag],
            backup_dir=None,
        )
    except Exception:
        pass

    from neutrino.apply.manager import load_revoked_state, save_revoked_state
    try:
        rst = load_revoked_state(cfg_dict)
        rst["autopilot"] = "off"
        save_revoked_state(rst, cfg_dict)
    except Exception:
        pass

    # Undeploy systemd targets, cron, runparts, path shims
    from neutrino.apply.targets import load_accepted_targets
    from neutrino.capture.systemd import detach_target, get_target_status
    try:
        targets_data = load_accepted_targets(root=actual_root, apply_dir=apply_dir)
        for u in targets_data.get("units", []):
            u_name = u.get("unit") or u.get("id")
            if u_name:
                tspec = {"id": u_name, "unit": u_name, "class": u.get("class", "unspecified"), "kind": "systemd"}
                if get_target_status(tspec, root=actual_root) == "attached":
                    detach_target(tspec, root=actual_root)
    except Exception:
        pass

    try:
        from neutrino.capture.cron import undeploy_cron_target
        from neutrino.capture.runparts import undeploy_runparts_target
        cap_base = os.path.join(actual_root, "var", "lib", "neutrino", "apply", "capture")
        if os.path.isdir(cap_base):
            for entry in os.listdir(cap_base):
                entry_dir = os.path.join(cap_base, entry)
                if not os.path.isdir(entry_dir):
                    continue
                manifests = []
                m_direct = os.path.join(entry_dir, "manifest.json")
                if os.path.isfile(m_direct):
                    manifests.append(m_direct)
                else:
                    try:
                        for sub in os.listdir(entry_dir):
                            m_sub = os.path.join(entry_dir, sub, "manifest.json")
                            if os.path.isfile(m_sub):
                                manifests.append(m_sub)
                    except OSError:
                        pass
                for mpath in manifests:
                    try:
                        with open(mpath, "r", encoding="utf-8") as f:
                            m = json.load(f)
                        kind = m.get("kind")
                        if kind == "cron":
                            undeploy_cron_target(m.get("path") or m.get("id") or m.get("key"), root=actual_root)
                        elif kind == "runparts":
                            undeploy_runparts_target(m.get("name") or m.get("path"), root=actual_root)
                    except Exception:
                        pass
    except Exception:
        pass

    try:
        from neutrino.apply.path_targets import load_path_targets, save_path_targets
        from neutrino.capture.path_shim import undeploy_path_shim, sync_path_environment
        pdata = load_path_targets(root=actual_root)
        changed = False
        for cmd in pdata.get("commands", []):
            if isinstance(cmd, dict):
                bname = cmd.get("basename")
                if bname:
                    undeploy_path_shim(bname, root=actual_root)
                    if cmd.get("accepted") is True:
                        cmd["accepted"] = False
                        changed = True
        if changed:
            save_path_targets(pdata, root=actual_root)
        sync_path_environment(root=actual_root)
    except Exception:
        pass

    client_restores = None
    try:
        from neutrino.attach.client_config import restore_client_configs
        client_restores = restore_client_configs(cfg_dict, root=actual_root)
    except Exception:
        pass

    return {
        "ok": True,
        "autopilot": "off",
        "flag_file": autopilot_flag,
        "removed": True,
        "revoked": True,
        "undeployed": undep_res,
        "client_restores": client_restores,
    }


def is_rail_armed(rail: str, root: str = "/", cfg: Optional[Dict[str, Any]] = None) -> Tuple[bool, str]:
    """
    Armed when licensed_and_armed() is True, or rail switch exists.
    """
    if licensed_and_armed(cfg=cfg, root=root):
        return True, "armed"

    from neutrino.crypto.desk_license import licensed_apply
    if not licensed_apply(root=root, cfg=cfg, read_only=True):
        return False, "unlicensed"

    norm_rail = str(rail or "").strip().lower()
    autopilot_dir = (cfg.get("autopilot_switch_dir") if cfg else None) or os.path.join(root, "etc/neutrino/autopilot")
    switch_path = os.path.join(autopilot_dir, f"{norm_rail}.enabled")
    if not os.path.isfile(switch_path):
        return False, "switch-off"
    return True, "armed"


def rail_autopilot_on(rail: str, root: str = "/", cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Enables autopilot on a specific rail (cpu or gpu).
    1. Verifies valid DSA-16 paper fail-closed.
    2. Writes /etc/neutrino/autopilot/{rail}.enabled (mode 0640 root:neutrino).
    3. If gpu rail: senses substrate and writes /var/lib/neutrino/autopilot/substrate.json.
    """
    norm_rail = str(rail or "").strip().lower()
    if norm_rail not in ("cpu", "gpu"):
        raise ValueError(f"Invalid rail: {rail}. Must be 'cpu' or 'gpu'")

    cfg = cfg or {}
    from neutrino.apply.manager import verify_apply_license
    lic_ok, lic_msg = verify_apply_license(cfg, feature_class=None, read_only=False, bind_nonce=True)
    if not lic_ok:
        raise PermissionError(f"Not licensed. Metering only. {lic_msg}")

    autopilot_dir = cfg.get("autopilot_switch_dir") or os.path.join(root, "etc/neutrino/autopilot")
    os.makedirs(autopilot_dir, exist_ok=True)
    switch_path = os.path.join(autopilot_dir, f"{norm_rail}.enabled")

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    tmp_file = f"{switch_path}.tmp.{os.getpid()}"
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump({"enabled": True, "rail": norm_rail, "ts": time.time()}, f, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    if neutrino_gid is not None:
        try:
            os.chown(tmp_file, 0, neutrino_gid)
        except OSError:
            pass
    try:
        os.chmod(tmp_file, 0o640)
    except OSError:
        pass
    os.replace(tmp_file, switch_path)

    substrate_file = None
    if norm_rail == "gpu":
        from neutrino.apply.substrate import sense_substrate, write_substrate_file
        upstream_url = cfg.get("upstream_url", "http://127.0.0.1:8080")
        sub_data = sense_substrate(upstream_url=upstream_url)
        sub_file_path = cfg.get("autopilot_substrate_file") or os.path.join(root, "var/lib/neutrino/autopilot/substrate.json")
        substrate_file = write_substrate_file(sub_data, path=sub_file_path)
        client_rewrites = None
        try:
            from neutrino.attach.client_config import rewrite_client_configs
            client_rewrites = rewrite_client_configs(cfg, root=root)
        except Exception as e:
            client_rewrites = {"ok": False, "error": str(e), "rewritten": [], "already_rewritten": [], "errors": []}

    return {
        "ok": True,
        "rail": norm_rail,
        "status": "on",
        "switch_file": switch_path,
        "substrate_file": substrate_file,
    }


def rail_autopilot_off(rail: str, root: str = "/", cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Disables autopilot on a specific rail (cpu or gpu).
    Removes switch file /etc/neutrino/autopilot/{rail}.enabled.
    """
    norm_rail = str(rail or "").strip().lower()
    if norm_rail not in ("cpu", "gpu"):
        raise ValueError(f"Invalid rail: {rail}. Must be 'cpu' or 'gpu'")

    cfg = cfg or {}
    autopilot_dir = cfg.get("autopilot_switch_dir") or os.path.join(root, "etc/neutrino/autopilot")
    switch_path = os.path.join(autopilot_dir, f"{norm_rail}.enabled")

    if os.path.isfile(switch_path):
        try:
            os.unlink(switch_path)
        except OSError:
            pass

    if norm_rail == "gpu":
        try:
            from neutrino.attach.client_config import restore_client_configs
            restore_client_configs(cfg, root=root)
        except Exception:
            pass

    return {
        "ok": True,
        "rail": norm_rail,
        "status": "off",
        "switch_file": switch_path,
    }


