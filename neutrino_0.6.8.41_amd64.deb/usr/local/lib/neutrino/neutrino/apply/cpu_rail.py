"""
cpu_rail.py - CPU rail decision, qualification, and holdout policy.
FNV-1a 1-in-20 holdout. Package energy (uj_delta) evaluation.
Standard library only. Zero host literals.
"""

from typing import Dict, Any, List, Optional, Tuple
from neutrino.apply.caps import fnv1a_32

CPU_CLASS_LEVERS = {
    "compile": "materialize",
    "infer-cpu": "materialize",
    "batch": "occupancy",
    "hpc": "occupancy",
    "oltp": "group-commit",
    "mq": "batched-fsync",
    "etl": "residency",
}


def evaluate_cpu_qualification(job_class: str, jobs: List[Dict[str, Any]]) -> Tuple[str, Optional[float]]:
    """
    Evaluates CPU class qualification from ledger history:
    Score only holdout rows and rows where the lever was applied.
    Dropped rows must not enter the mean.
    pct = (mean(holdout J) - mean(applied J)) / mean(holdout J)
    ready when n_holdout >= 5 and n_applied >= 5:
    - not ready -> scoring, lever on
    - ready and pct > 0.05 -> kept
    - ready and pct <= 0.05 -> dropped, and it stays dropped
    package joules, method uj_delta. Record wall seconds. Wall does not vote.
    """
    norm_cls = str(job_class or "").strip().lower()
    holdout_j: List[float] = []
    applied_j: List[float] = []

    for j in jobs:
        c = str(j.get("class", "")).strip().lower()
        if c != norm_cls:
            continue
        if j.get("method") != "uj_delta":
            continue

        e_pkg = j.get("energy_pkg_j")
        if e_pkg is None:
            e_pkg = j.get("energy_j")
        if e_pkg is None:
            continue
        try:
            val = float(e_pkg)
        except (ValueError, TypeError):
            continue

        pol = j.get("policy")
        pol_dict = pol if isinstance(pol, dict) else {}

        is_holdout = bool(j.get("holdout") is True or pol_dict.get("holdout") is True)
        is_applied = bool(pol_dict.get("applied") is True or j.get("applied") is True)
        is_dropped = bool(pol_dict.get("status") == "dropped" or pol_dict.get("reason") == "dropped")

        # Dropped rows must not enter the mean.
        if is_dropped:
            continue

        if is_holdout:
            holdout_j.append(val)
        elif is_applied:
            applied_j.append(val)

    n_h = len(holdout_j)
    n_a = len(applied_j)

    if n_h < 5 or n_a < 5:
        return "scoring", None

    mean_h = sum(holdout_j) / n_h
    mean_a = sum(applied_j) / n_a

    if mean_h <= 0.0:
        return "dropped", 0.0

    pct = (mean_h - mean_a) / mean_h
    if pct > 0.05:
        return "kept", pct
    else:
        return "dropped", pct


def decide_cpu_job(
    job_id: str,
    job_class: str,
    jobs: List[Dict[str, Any]],
    armed: bool,
) -> Dict[str, Any]:
    """
    Decides CPU lever policy for an incoming job.
    Hold out 1 in 20. Bucket = FNV-1a(cpu:{class}:{job_id}) mod 20 == 0.
    Class is read off the job. Unknown class: pass-through.
    """
    norm_cls = str(job_class or "").strip().lower()
    if norm_cls not in CPU_CLASS_LEVERS:
        return {
            "class": norm_cls,
            "applied": False,
            "reason": "unknown-class",
            "lever": "none",
            "holdout": False,
        }

    if not armed:
        return {
            "class": norm_cls,
            "applied": False,
            "reason": "switch-off",
            "lever": "none",
            "holdout": False,
        }

    # Evaluate qualification
    status, pct = evaluate_cpu_qualification(norm_cls, jobs)

    bucket = fnv1a_32(f"cpu:{norm_cls}:{job_id}") % 20
    is_holdout = (bucket == 0)

    if status == "dropped":
        return {
            "class": norm_cls,
            "applied": False,
            "reason": "dropped",
            "lever": "none",
            "holdout": is_holdout,
            "status": "dropped",
            "pct": pct,
        }

    if is_holdout:
        return {
            "class": norm_cls,
            "applied": False,
            "reason": "holdout",
            "lever": "none",
            "holdout": True,
            "status": status,
            "pct": pct,
        }

    lever = CPU_CLASS_LEVERS[norm_cls]
    return {
        "class": norm_cls,
        "applied": True,
        "reason": "always" if status == "kept" else "scoring",
        "lever": lever,
        "holdout": False,
        "status": status,
        "pct": pct,
    }
