"""
etl.py - Neutrino ETL workload helper.
Standard library only. Zero external dependencies.
When class == "etl" AND apply.d/etl.enabled AND claims.apply AND not baseline:
  stream-aggregates line by line (residency lever, O(1) memory).
  stamps lever=residency execution=stream_aggregate
Otherwise:
  slurps entire file (f.readlines()) into memory.
  stamps lever=none execution=slurp_readlines
Produces identical records, byte count, and checksum on both arms.
"""

import argparse
import os
import sys
from typing import Dict, Any, Optional, Tuple

from neutrino.config import (
    DEFAULT_APPLY_DIR,
    DEFAULT_CONFIG_PATH,
    load_config,
)
from neutrino.apply.manager import get_active_policy


def resolve_etl_policy(
    job_class: str = "etl",
    cfg: Optional[Dict[str, Any]] = None,
    baseline: bool = False,
) -> Tuple[bool, str, str]:
    cfg = cfg or {}
    norm_class = str(job_class or "unspecified").strip().lower()
    if norm_class != "etl" or baseline or os.environ.get("NEUTRINO_LEVER_OFF") == "1":
        return False, "slurp_readlines", "none"

    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    if os.path.isfile(os.path.join(apply_dir, "etl.enabled")):
        return True, "stream_aggregate", "residency"
    policy = get_active_policy("etl", cfg)
    if policy.get("applied"):
        return True, "stream_aggregate", "residency"

    return False, "slurp_readlines", "none"


def run_etl(
    input_path: str,
    output_path: Optional[str] = None,
    job_class: str = "etl",
    cfg: Optional[Dict[str, Any]] = None,
    baseline: bool = False,
) -> Dict[str, Any]:
    if not input_path or not os.path.isfile(input_path):
        raise ValueError(f"Input file not found: {input_path}")

    applied, execution, lever = resolve_etl_policy(job_class, cfg, baseline=baseline)

    if applied:
        os.environ["NEUTRINO_ATTACH_INJECT"] = "residency"
        os.environ["NEUTRINO_ATTACH_CLASS"] = "etl"
    else:
        os.environ.pop("NEUTRINO_ATTACH_INJECT", None)

    count = 0
    total_bytes = 0
    checksum = 0

    if applied:
        # Stream-aggregate arm (O(1) memory residency)
        with open(input_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                count += 1
                b = len(line.encode("utf-8"))
                total_bytes += b
                checksum = (checksum * 31 + b) & 0xFFFFFFFF
    else:
        # Baseline arm (slurp into memory)
        with open(input_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        for line in lines:
            count += 1
            b = len(line.encode("utf-8"))
            total_bytes += b
            checksum = (checksum * 31 + b) & 0xFFFFFFFF

    out_msg = (
        f"records={count} bytes={total_bytes} checksum={checksum} "
        f"lever={lever} execution={execution}"
    )
    print(out_msg, flush=True)

    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(out_msg + "\n")

    return {
        "records": count,
        "bytes": total_bytes,
        "checksum": checksum,
        "lever": lever,
        "execution": execution,
        "applied": applied,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Neutrino ETL workload residency helper")
    parser.add_argument("--input", "-i", required=True, help="Input data file to process")
    parser.add_argument("--output", "-o", default=None, help="Optional output result file")
    parser.add_argument("--baseline", action="store_true", help="Force baseline (Arm A) slurp mode")
    parser.add_argument("--class", dest="job_class", default="etl", help="Workload class")
    parser.add_argument("--config", default=DEFAULT_CONFIG_PATH, help="Path to neutrino.toml")

    args = parser.parse_args(argv)
    cfg = load_config(args.config) if os.path.isfile(args.config) else {}

    try:
        run_etl(
            input_path=args.input,
            output_path=args.output,
            job_class=args.job_class,
            cfg=cfg,
            baseline=args.baseline,
        )
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
