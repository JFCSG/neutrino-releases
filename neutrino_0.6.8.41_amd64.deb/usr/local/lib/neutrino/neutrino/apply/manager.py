"""
manager.py - Neutrino Apply subsystem manager.
Controls:
1. Apply after approval with license gating (apply feature).
2. Per-feature pre-mutation backup and surgical restore (explicit TOUCH_LIST).
3. History tracking and version period energy attribution.
Standard library only. Zero external dependencies.
"""

import hashlib
import json
import os
import secrets
import time
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple, Set

from neutrino.apply.savings import calculate_apply_savings
from neutrino.crypto.desk_license import licensed_apply
from neutrino.config import (
    DEFAULT_APPLY_DIR,
    DEFAULT_APPLY_STATE_DIR,
    DEFAULT_APPLY_BACKUP_DIR,
    DEFAULT_APPLY_HISTORY_FILE,
    DEFAULT_LICENSE_PATH,
    DEFAULT_JOBS_FILE,
    DEFAULT_RECIPE_JSON_PATH,
)

SAVINGS_ELIGIBLE_CLASSES: List[str] = [
    "compile", "infer-cpu", "batch", "oltp", "mq", "hpc", "render", "etl"
]
METER_ONLY_CLASSES: List[str] = ["idle", "heartbeat", "unspecified"]

DEFAULT_AUTOPILOT_CLASSES = (
    "compile",
    "batch",
    "oltp",
    "mq",
    "etl",
    "infer-cpu",
    "hpc",
    "render",
)
DEFAULT_RECIPE_CLASSES = (
    "batch",
    "compile",
    "compile_handoff",
    "dump_guard",
    "hpc",
    "infer-cpu",
    "mq",
    "oltp",
    "render",
)
ALL_CLASSES: List[str] = [
    "compile", "infer-cpu", "batch", "oltp", "mq", "hpc", "render", "etl",
    "idle", "heartbeat", "unspecified"
]

CLASS_LEVERS: Dict[str, str] = {
    "batch": "occupancy",
    "hpc": "occupancy",
    "render": "occupancy",
    "compile": "materialize",
    "infer-cpu": "materialize",
    "oltp": "group-commit",
    "mq": "batched-fsync",
    "etl": "residency-stream",
    "infer-gpu": "cache_prompt",
    "infer-gpu-chat": "cache_prompt",
    "infer-gpu-repeat": "cache_prompt",
    "compile_handoff": "compile_handoff",
    "dump_guard": "dump_guard",
}


def get_touch_list(
    feature_class: str,
    apply_dir: str = DEFAULT_APPLY_DIR,
    state_dir: str = DEFAULT_APPLY_STATE_DIR,
) -> List[str]:
    """Returns the explicit, strictly confined TOUCH_LIST for a feature class."""
    norm_class = str(feature_class or "").strip().lower()
    if norm_class in METER_ONLY_CLASSES:
        raise ValueError(
            f"Class '{feature_class}' is meter-only and has no touch list"
        )
    if norm_class in ("infer-gpu", "infer-gpu-chat", "infer-gpu-repeat"):
        return []
    if feature_class not in CLASS_LEVERS:
        raise ValueError(
            f"Unknown feature class '{feature_class}'. Supported: {', '.join(sorted(CLASS_LEVERS.keys()))}"
        )
    paths = [
        os.path.join(apply_dir, f"{norm_class}.enabled"),
        os.path.join(apply_dir, f"{norm_class}.conf"),
        os.path.join(state_dir, f"{norm_class}.state"),
    ]
    if norm_class == "compile_handoff":
        paths.insert(2, os.path.join(apply_dir, "compile_handoff.spawn"))
    if norm_class == "compile":
        c_dir = os.path.join(os.path.dirname(state_dir), "ccache")
        if not c_dir.endswith("/"):
            c_dir += "/"
        paths.append(c_dir)
    return paths


def hash_file_sha256(path: str) -> Optional[str]:
    if not os.path.isfile(path):
        return None
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def generate_version_id() -> str:
    utc_str = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    rand_hex = secrets.token_hex(4)
    return f"v-{utc_str}-{rand_hex}"


def atomic_write(path: str, content: str, mode: int = 0o640, gid: Optional[int] = None):
    parent = os.path.dirname(path)
    os.makedirs(parent, exist_ok=True)
    tmp_path = f"{path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp_path, mode)
    if gid is not None and os.geteuid() == 0:
        try:
            os.chown(tmp_path, 0, gid)
        except OSError:
            pass
    os.rename(tmp_path, path)


def verify_apply_license(
    cfg: Optional[Dict[str, Any]] = None,
    feature_class: Optional[str] = None,
    read_only: bool = False,
    bind_nonce: Optional[bool] = None,
) -> Tuple[bool, str]:
    cfg = cfg or {}
    if bind_nonce is None:
        bind_nonce = not read_only
    lic = cfg.get("_license")
    if lic is None:
        from neutrino.crypto.desk_license import load_effective_license
        lic = load_effective_license(cfg, read_only=read_only, bind_nonce=bind_nonce)

    # 1. Lease check FIRST (Nit 1: do not let recipe error swallow lease error)
    if not lic.get("valid"):
        return False, f"License invalid: {lic.get('reason', 'unverified')}"
    if lic.get("source") != "desk":
        return False, f"License source '{lic.get('source')}' is observe-only; DSA-16 desk paper required for apply"
    if lic.get("sku") and lic.get("sku") != "NEUTRINO":
        return False, f"License sku '{lic.get('sku')}' is not NEUTRINO"
    claims = lic.get("claims", {}) if isinstance(lic.get("claims"), dict) else {}
    if not (lic.get("apply") is True or claims.get("apply") is True):
        return False, f"License does not grant 'apply' claim (active claims: {claims})"

    if lic.get("recipe_valid") is False and "recipe_valid" in lic:
        return False, lic.get("recipe_reason", "recipe invalid")

    recipe_classes = lic.get("recipe_classes")
    if not recipe_classes:
        rec_obj = lic.get("recipe")
        if isinstance(rec_obj, dict):
            recipe_classes = rec_obj.get("classes")
    if not recipe_classes:
        from neutrino.recipes import DEFAULT_AUTOPILOT_RECIPE_CLASSES
        recipe_classes = DEFAULT_AUTOPILOT_RECIPE_CLASSES

    if feature_class is not None:
        norm_class = str(feature_class).strip().lower()
        if norm_class in METER_ONLY_CLASSES:
            return False, f"Class '{norm_class}' cannot be applied (meter-only class)"
        if norm_class in ("infer-gpu", "infer-gpu-chat", "infer-gpu-repeat", "compile_handoff", "dump_guard"):
            return True, "Valid with apply feature and compile handoff / GPU attach recipe"
        if recipe_classes is not None:
            if isinstance(recipe_classes, (list, tuple, set)) and norm_class not in recipe_classes:
                return False, f"no signed recipe for class {feature_class}"
            elif isinstance(recipe_classes, dict) and norm_class not in recipe_classes:
                return False, f"no signed recipe for class {feature_class}"

    return True, "Valid with apply feature and signed recipe"


def create_backup(
    feature_class: str,
    version_id: str,
    backup_base_dir: str = DEFAULT_APPLY_BACKUP_DIR,
    apply_dir: str = DEFAULT_APPLY_DIR,
    state_dir: str = DEFAULT_APPLY_STATE_DIR,
    extra_paths: Optional[List[str]] = None,
) -> str:
    touch_list = list(get_touch_list(feature_class, apply_dir, state_dir))
    if extra_paths:
        touch_list.extend(extra_paths)
    target_backup_dir = os.path.join(backup_base_dir, feature_class, version_id)
    os.makedirs(target_backup_dir, exist_ok=True)

    manifest_paths = []
    now = time.time()

    for path in touch_list:
        if os.path.exists(path):
            if os.path.isdir(path):
                manifest_paths.append({
                    "path": path,
                    "absent": False,
                    "is_dir": True,
                })
                continue
            sha = hash_file_sha256(path)
            st = os.stat(path)
            backup_file_rel = os.path.basename(path)
            backup_file_abs = os.path.join(target_backup_dir, backup_file_rel)
            with open(path, "rb") as src, open(backup_file_abs, "wb") as dst:
                dst.write(src.read())
            os.chmod(backup_file_abs, st.st_mode)
            manifest_paths.append({
                "path": path,
                "absent": False,
                "backup_file": backup_file_rel,
                "sha256": sha,
                "mode": st.st_mode,
                "uid": st.st_uid,
                "gid": st.st_gid,
            })
        else:
            manifest_paths.append({
                "path": path,
                "absent": True,
                "is_dir": path.endswith("/"),
            })

    manifest = {
        "feature": feature_class,
        "version_id": version_id,
        "t_start": now,
        "paths": manifest_paths,
    }
    manifest_path = os.path.join(target_backup_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    return target_backup_dir


def append_history_event(
    history_file: str,
    feature: str,
    version_id: str,
    event: str,
    t_start: float,
    paths: List[str],
    backup_dir: str,
    restored_from: Optional[str] = None,
):
    parent = os.path.dirname(history_file)
    os.makedirs(parent, exist_ok=True)
    events = []
    if os.path.isfile(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            events.append(json.loads(line))
                        except Exception:
                            pass
        except OSError:
            pass

    # Close previous open period for this feature
    for ev in reversed(events):
        if ev.get("feature") == feature and ev.get("t_end") is None:
            ev["t_end"] = t_start
            break

    new_event = {
        "feature": feature,
        "version_id": version_id,
        "event": event,
        "t_start": t_start,
        "t_end": None,
        "paths": paths,
        "backup_dir": backup_dir,
        "restored_from": restored_from,
    }
    events.append(new_event)

    tmp_hist = f"{history_file}.tmp.{secrets.token_hex(4)}"
    with open(tmp_hist, "w", encoding="utf-8") as f:
        for ev in events:
            f.write(json.dumps(ev) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp_hist, 0o664)
    os.rename(tmp_hist, history_file)


def get_effective_targets(cfg: Optional[Dict[str, Any]] = None, norm_class: Optional[str] = None) -> List[Dict[str, Any]]:
    """Returns combined target list from targets.json and recipe (targets.json takes precedence)."""
    cfg = cfg or {}
    recipe_path = cfg.get("recipe_json_file", os.environ.get("NU_RECIPE", DEFAULT_RECIPE_JSON_PATH))
    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
    from neutrino.apply.recipe import get_recipe_targets
    from neutrino.apply.targets import load_accepted_targets
    apply_dir = cfg.get("apply_dir")
    targets_data = load_accepted_targets(root=root, apply_dir=apply_dir)
    local_targets = [
        {"id": u["unit"], "unit": u["unit"], "class": u.get("class", "batch"), "kind": "systemd"}
        for u in targets_data.get("units", [])
        if u.get("accepted") is True
    ]
    seen_tids = {t["id"] for t in local_targets}
    targets = list(local_targets)
    for rt in get_recipe_targets(recipe_path, strict_targets=False):
        if isinstance(rt, dict) and rt.get("id") not in seen_tids:
            targets.append(rt)
            seen_tids.add(rt.get("id"))
    if norm_class:
        return [t for t in targets if str(t.get("class") or "").strip().lower() == norm_class]
    return targets

def apply_preview(feature_class: Optional[str] = None, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = cfg or {}
    norm_class = str(feature_class or "").strip().lower() if feature_class is not None else None

    # Recipe-wide preview across all 11 classes when feature_class is omitted or "all"
    if norm_class is None or norm_class in ("all", ""):
        lic_ok, lic_msg = verify_apply_license(cfg, feature_class=None, read_only=True, bind_nonce=False)
        from neutrino.crypto.desk_license import load_effective_license
        lic = load_effective_license(cfg, read_only=True, bind_nonce=False)
        recipe_classes = lic.get("recipe_classes") or {}
        if not recipe_classes:
            rec_obj = lic.get("recipe")
            if isinstance(rec_obj, dict):
                recipe_classes = rec_obj.get("classes")
        if not recipe_classes:
            from neutrino.recipes import DEFAULT_AUTOPILOT_RECIPE_CLASSES
            recipe_classes = DEFAULT_AUTOPILOT_RECIPE_CLASSES
        if not recipe_classes:
            rec_obj = lic.get("recipe")
            if isinstance(rec_obj, dict):
                recipe_classes = rec_obj.get("classes")
        if not recipe_classes:
            from neutrino.recipes import DEFAULT_AUTOPILOT_RECIPE_CLASSES
            recipe_classes = DEFAULT_AUTOPILOT_RECIPE_CLASSES

        apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
        state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)

        classes_preview = {}
        for cls in ALL_CLASSES:
            if cls in METER_ONLY_CLASSES:
                # Meter-only in recipe-wide preview: proposed_action none, empty touch_list.
                # Do not call get_touch_list for idle / heartbeat / unspecified.
                classes_preview[cls] = {
                    "ok": True,
                    "class": cls,
                    "lever": "none",
                    "licensed": False,
                    "license_message": f"Class '{cls}' is meter-only",
                    "touch_list": [],
                    "proposed_action": "none",
                }
            else:
                cls_lic_ok, cls_lic_msg = verify_apply_license(cfg, feature_class=cls, read_only=True, bind_nonce=False)
                touch_list = get_touch_list(cls, apply_dir, state_dir)
                if isinstance(recipe_classes, dict) and cls in recipe_classes and isinstance(recipe_classes[cls], dict):
                    lever = recipe_classes[cls].get("lever", CLASS_LEVERS.get(cls, "unspecified"))
                else:
                    lever = CLASS_LEVERS.get(cls, "unspecified")
                cls_preview = {
                    "ok": True,
                    "class": cls,
                    "lever": lever,
                    "licensed": cls_lic_ok,
                    "license_message": cls_lic_msg,
                    "touch_list": touch_list,
                    "proposed_action": "approve" if cls_lic_ok else "blocked_unlicensed",
                }
                if cls == "compile_handoff":
                    cls_preview["copy"] = "skip engine compile-in-chat; make only if spawn file present"
                elif cls == "dump_guard":
                    cls_preview["copy"] = "same edit; send a patch not the whole file"
                elif cls in ("infer-gpu", "infer-gpu-chat", "infer-gpu-repeat"):
                    cls_preview["copy"] = "same task output; less GPU work"
                classes_preview[cls] = cls_preview

        # Recipe & local targets for preview
        root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
        from neutrino.capture.systemd import get_target_status
        targets = get_effective_targets(cfg)
        target_ids = []
        targets_info = []
        targets_status = {}
        for t in targets:
            if isinstance(t, dict) and "id" in t:
                tid = t["id"]
                target_ids.append(tid)
                st = get_target_status(t, root=root)
                targets_status[tid] = st
                action = "none"
                if st == "attached":
                    action = "would-detach"
                elif st == "dummy":
                    action = "would-attach"
                elif st == "denied":
                    action = "blocked_denied"
                else:
                    action = "not_attached"
                targets_info.append({
                    "id": tid,
                    "class": t.get("class"),
                    "kind": t.get("kind"),
                    "status": st,
                    "action": action,
                    "would_attach": (action == "would-attach"),
                })

        return {
            "ok": True,
            "licensed": lic_ok,
            "license_message": lic_msg,
            "targets_count": len(target_ids),
            "target_ids": target_ids,
            "targets": targets_info,
            "targets_status": targets_status,
            "classes": classes_preview,
        }

    # Single-class preview (debug)
    if norm_class in METER_ONLY_CLASSES:
        raise ValueError(f"Class '{norm_class}' cannot be applied (meter-only class)")

    lic_ok, lic_msg = verify_apply_license(cfg, feature_class=norm_class, read_only=True, bind_nonce=False)
    if norm_class in ("infer-gpu", "infer-gpu-chat", "infer-gpu-repeat"):
        from neutrino.agent import CLASS_RECOMMENDATIONS
        from neutrino.apply.gpu_models import get_depth3_preview
        rec_info = CLASS_RECOMMENDATIONS.get(norm_class, {})
        depth3 = get_depth3_preview(cfg=cfg)
        return {
            "ok": True,
            "class": feature_class,
            "lever": "cache_prompt",
            "copy": "same task output; less GPU work",
            "levers": rec_info.get("levers", ["cache_prompt", "holdout"]),
            "licensed": lic_ok,
            "license_message": lic_msg,
            "touch_list": [],
            "targets_count": 0,
            "target_ids": [],
            "targets": [],
            "targets_status": {},
            "proposed_action": "approve" if lic_ok else "blocked_unlicensed",
            "advice": rec_info.get("advice", []),
            "do_not": rec_info.get("do_not", []),
            "depth3": depth3,
        }
    touch_list = get_touch_list(
        feature_class,
        cfg.get("apply_dir", DEFAULT_APPLY_DIR),
        cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR),
    )
# compile touch_list already includes ccache dir via get_touch_list
    from neutrino.crypto.desk_license import load_effective_license
    lic = load_effective_license(cfg, read_only=True, bind_nonce=False)
    recipe_classes = lic.get("recipe_classes") or {}
    if isinstance(recipe_classes, dict) and norm_class in recipe_classes and isinstance(recipe_classes[norm_class], dict):
        lever = recipe_classes[norm_class].get("lever", CLASS_LEVERS.get(feature_class, "unspecified"))
    else:
        lever = CLASS_LEVERS.get(feature_class, "unspecified")
    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
    from neutrino.capture.systemd import get_target_status
    cls_targets = get_effective_targets(cfg, norm_class=norm_class)
    cls_target_ids = [t["id"] for t in cls_targets if "id" in t]
    cls_targets_info = []
    cls_targets_status = {}
    for t in cls_targets:
        if isinstance(t, dict) and "id" in t:
            tid = t["id"]
            st = get_target_status(t, root=root)
            cls_targets_status[tid] = st
            action = "none"
            if st == "attached":
                action = "would-detach"
            elif st == "dummy":
                action = "would-attach"
            elif st == "denied":
                action = "blocked_denied"
            else:
                action = "not_attached"
            cls_targets_info.append({
                "id": tid,
                "class": t.get("class"),
                "kind": t.get("kind"),
                "status": st,
                "action": action,
                "would_attach": (action == "would-attach"),
            })

    res = {
        "ok": True,
        "class": feature_class,
        "lever": lever,
        "licensed": lic_ok,
        "license_message": lic_msg,
        "touch_list": touch_list,
        "targets_count": len(cls_target_ids),
        "target_ids": cls_target_ids,
        "targets": cls_targets_info,
        "targets_status": cls_targets_status,
        "proposed_action": "approve" if lic_ok else "blocked_unlicensed",
    }
    if norm_class == "compile_handoff":
        res["copy"] = "skip engine compile-in-chat; make only if spawn file present"
    elif norm_class == "dump_guard":
        res["copy"] = "same edit; send a patch not the whole file"
    elif norm_class in ("infer-gpu", "infer-gpu-chat", "infer-gpu-repeat"):
        res["copy"] = "same task output; less GPU work"
    return res


def apply_approve(feature_class: str, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    norm_class = str(feature_class or "").strip().lower()
    if not norm_class or norm_class in METER_ONLY_CLASSES:
        raise ValueError(f"Class '{norm_class}' cannot be approved (meter-only class)")
    if norm_class not in CLASS_LEVERS:
        raise ValueError(
            f"Unknown feature class '{feature_class}'. "
            f"Supported: {', '.join(sorted(CLASS_LEVERS.keys()))}"
        )

    lic_ok, lic_msg = verify_apply_license(cfg, feature_class=norm_class, read_only=False, bind_nonce=True)
    if not lic_ok:
        raise PermissionError(f"Cannot approve {feature_class}: {lic_msg}")

    cfg = cfg or {}
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    backup_base = cfg.get("apply_backup_dir", DEFAULT_APPLY_BACKUP_DIR)
    history_file = cfg.get("apply_history_file", DEFAULT_APPLY_HISTORY_FILE)

    version_id = generate_version_id()
    extra_paths = []
    backup_dir = create_backup(feature_class, version_id, backup_base, apply_dir, state_dir, extra_paths=extra_paths)

    lic = cfg.get("_license")
    if lic is None:
        from neutrino.crypto.desk_license import load_effective_license
        lic = load_effective_license(cfg, read_only=False, bind_nonce=True)
    recipe_classes = lic.get("recipe_classes") or {}
    if not recipe_classes:
        rec_obj = lic.get("recipe")
        if isinstance(rec_obj, dict):
            recipe_classes = rec_obj.get("classes")
    if not recipe_classes or len(recipe_classes) == 0:
        from neutrino.recipes import DEFAULT_AUTOPILOT_RECIPE_CLASSES
        recipe_classes = DEFAULT_AUTOPILOT_RECIPE_CLASSES
    if isinstance(recipe_classes, dict) and norm_class in recipe_classes and isinstance(recipe_classes[norm_class], dict):
        lever = recipe_classes[norm_class].get("lever", CLASS_LEVERS.get(feature_class, "unspecified"))
    else:
        lever = CLASS_LEVERS.get(feature_class, "unspecified")
    now = time.time()

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    # 1. Enable file
    enable_path = os.path.join(apply_dir, f"{feature_class}.enabled")
    enable_content = json.dumps({
        "class": feature_class,
        "lever": lever,
        "version_id": version_id,
        "enabled": True,
        "t_start": now,
    }, indent=2) + "\n"
    atomic_write(enable_path, enable_content, mode=0o640, gid=neutrino_gid)

    # 2. Conf file
    conf_path = os.path.join(apply_dir, f"{feature_class}.conf")
    if norm_class == "compile":
        from neutrino.levers.ccache_env import resolve_ccache
        c_dir = cfg.get("ccache_dir", "/var/lib/neutrino/ccache")
        if resolve_ccache():
            try:
                os.makedirs(c_dir, mode=0o750, exist_ok=True)
                os.chmod(c_dir, 0o750)
                if neutrino_gid is not None and os.geteuid() == 0:
                    os.chown(c_dir, 0, neutrino_gid)
            except Exception:
                pass
        conf_content = (
            f"# Neutrino apply configuration for compile\n"
            f"class=compile\n"
            f"lever=materialize\n"
            f"backend=ccache\n"
            f"ccache_dir={c_dir}\n"
            f"wrap=neutrino-run-path\n"
            f"version_id={version_id}\n"
        )
    elif norm_class == "compile_handoff":
        conf_content = (
            f"# Neutrino apply configuration for compile_handoff\n"
            f"class=compile_handoff\n"
            f"lever=compile_handoff\n"
            f"spawn=false\n"
            f"version_id={version_id}\n"
        )
    elif norm_class == "dump_guard":
        conf_content = (
            f"# Neutrino apply configuration for dump_guard\n"
            f"class=dump_guard\n"
            f"lever=dump_guard\n"
            f"version_id={version_id}\n"
        )
    else:
        conf_content = f"# Neutrino apply configuration for {feature_class}\nclass={feature_class}\nlever={lever}\nversion_id={version_id}\n"
    atomic_write(conf_path, conf_content, mode=0o640, gid=neutrino_gid)

    # 3. State file
    state_path = os.path.join(state_dir, f"{feature_class}.state")
    state_content = json.dumps({
        "class": feature_class,
        "status": "approved",
        "version_id": version_id,
        "t_start": now,
    }, indent=2) + "\n"
    atomic_write(state_path, state_content, mode=0o640, gid=neutrino_gid)

    # 4. History event
    touch_list = get_touch_list(feature_class, apply_dir, state_dir)
    append_history_event(history_file, feature_class, version_id, "approve", now, touch_list, backup_dir)

    # 5. Attach accepted targets for this class from targets.json
    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
    from neutrino.apply.targets import load_accepted_targets
    from neutrino.capture.systemd import dummy_target, dummy_status, attach_target
    apply_dir = cfg.get("apply_dir")
    targets_data = load_accepted_targets(root=root, apply_dir=apply_dir)
    attached_units = []
    for u in targets_data.get("units", []):
        if str(u.get("class") or "").strip().lower() == norm_class and u.get("accepted") is True:
            u_name = u["unit"]
            tspec = {"id": u_name, "unit": u_name, "class": norm_class, "kind": "systemd"}
            if not dummy_status(tspec, root=root):
                try:
                    dummy_target(tspec, root=root)
                except Exception:
                    pass
            if dummy_status(tspec, root=root):
                try:
                    attach_target(tspec, lever=lever, root=root)
                    attached_units.append(u_name)
                except Exception:
                    pass

    # 6. Attach / wrap cron targets for this class
    attached_cron = []
    try:
        from neutrino.capture.cron import discover_cron_targets, deploy_cron_target
        cron_targets = discover_cron_targets(root=root)
        for c in cron_targets:
            if not c.get("is_vendor") and c.get("status") in ("candidate", "dummy_ok"):
                try:
                    res = deploy_cron_target({"path": c["path"], "class": norm_class}, root=root)
                    attached_cron.append(c["path"])
                except Exception:
                    pass
    except Exception:
        pass

    # 7. Attach / wrap run-parts targets for this class
    attached_runparts = []
    try:
        from neutrino.capture.runparts import discover_runparts_targets, deploy_runparts_target
        rp_targets = discover_runparts_targets(root=root)
        for r in rp_targets:
            if not r.get("is_vendor") and r.get("status") == "candidate":
                try:
                    deploy_runparts_target({"name": r["name"], "path": r["path"], "class": norm_class}, root=root)
                    attached_runparts.append(r["name"])
                except Exception:
                    pass
    except Exception:
        pass

    # 8. Deploy PATH shims for this class
    attached_path = []
    try:
        from neutrino.apply.path_targets import load_path_targets
        from neutrino.capture.path_shim import deploy_path_shim, sync_path_environment
        pdata = load_path_targets(root=root)
        for cmd in pdata.get("commands", []):
            if isinstance(cmd, dict) and cmd.get("class") == norm_class and cmd.get("accepted") is True:
                try:
                    deploy_path_shim(cmd, root=root)
                    attached_path.append(cmd["basename"])
                except Exception:
                    pass
        sync_path_environment(root=root)
    except Exception:
        pass

    # 9. Deploy attach shims for approved class
    if norm_class in ("batch", "oltp", "mq", "etl"):
        try:
            from neutrino.attach.shims import install_shims
            from neutrino.config import ATTACH_BIN_DIR, ATTACH_PROFILE_D
            bin_dir = cfg.get("attach_bin_dir", ATTACH_BIN_DIR)
            profile_d = cfg.get("attach_profile_d", ATTACH_PROFILE_D)
            install_shims([norm_class], bin_dir=bin_dir, profile_d_path=profile_d)
        except Exception:
            pass

    # Autopilot gate: ensure autopilot flag exists
    autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
    if not os.path.isfile(autopilot_flag):
        try:
            flag_data = json.dumps({"enabled": True, "ts": now, "source": "apply_approve"}, indent=2) + chr(10)
            atomic_write(autopilot_flag, flag_data, mode=0o640, gid=neutrino_gid)
        except Exception:
            pass

    remove_revoked_class(norm_class, cfg)
    all_attached = attached_units + attached_cron + attached_runparts + attached_path

    res = {
        "ok": True,
        "class": feature_class,
        "lever": lever,
        "version_id": version_id,
        "backup_dir": backup_dir,
        "t_start": now,
        "attached_targets": all_attached,
        "attached_units": attached_units,
        "attached_cron": attached_cron,
        "attached_runparts": attached_runparts,
        "attached_path": attached_path,
    }
    if norm_class == "compile_handoff":
        res["copy"] = "skip engine compile-in-chat; make only if spawn file present"
    elif norm_class == "dump_guard":
        res["copy"] = "same edit; send a patch not the whole file"
    elif norm_class in ("infer-gpu", "infer-gpu-chat", "infer-gpu-repeat"):
        res["copy"] = "same task output; less GPU work"
    return res



def get_revoked_file_path(cfg: Optional[Dict[str, Any]] = None) -> str:
    cfg = cfg or {}
    from neutrino.config import DEFAULT_REVOKED_CLASSES_FILE
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    return cfg.get("apply_revoked_file") or os.path.join(state_dir, "revoked.json")


def load_revoked_state(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    rev_path = get_revoked_file_path(cfg)
    if not os.path.isfile(rev_path):
        return {"revoked": [], "autopilot": "on"}
    try:
        with open(rev_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return {"revoked": data, "autopilot": "on"}
            elif isinstance(data, dict):
                return {
                    "revoked": list(data.get("revoked", [])),
                    "autopilot": data.get("autopilot", "on"),
                }
    except Exception:
        pass
    return {"revoked": [], "autopilot": "on"}


def save_revoked_state(state: Dict[str, Any], cfg: Optional[Dict[str, Any]] = None) -> None:
    rev_path = get_revoked_file_path(cfg)
    parent = os.path.dirname(rev_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass
    atomic_write(rev_path, json.dumps(state, indent=2) + "\n", mode=0o644, gid=neutrino_gid)


def load_revoked_classes(cfg: Optional[Dict[str, Any]] = None) -> Set[str]:
    if isinstance(cfg, dict) and "revoked" in cfg:
        val = cfg["revoked"]
        if isinstance(val, (list, set, tuple)):
            return set(val)
    st = load_revoked_state(cfg)
    return set(st.get("revoked", []))


def add_revoked_class(feature_class: str, cfg: Optional[Dict[str, Any]] = None) -> None:
    norm_class = str(feature_class or "").strip().lower()
    st = load_revoked_state(cfg)
    rev_set = set(st.get("revoked", []))
    rev_set.add(norm_class)
    st["revoked"] = sorted(list(rev_set))
    save_revoked_state(st, cfg)


def remove_revoked_class(feature_class: str, cfg: Optional[Dict[str, Any]] = None) -> None:
    norm_class = str(feature_class or "").strip().lower()
    st = load_revoked_state(cfg)
    rev_set = set(st.get("revoked", []))
    rev_set.discard(norm_class)
    st["revoked"] = sorted(list(rev_set))
    save_revoked_state(st, cfg)


def ensure_autopilot(
    license: Optional[Dict[str, Any]] = None,
    cfg: Optional[Dict[str, Any]] = None,
    force_on: bool = False,
) -> Dict[str, Any]:
    """
    Arms default Autopilot classes if license paper is valid with claims.apply=true.
    Respects revoked classes in /var/lib/neutrino/apply/revoked.json.
    Calls existing apply_approve() so backups, history events, and TOUCH_LIST are real.
    No-op for classes already armed (.enabled exists).
    Observe-only (zero writes) if license is invalid, expired, or apply=false.
    """
    cfg = cfg or {}
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)

    eff = license
    if eff is None:
        eff = cfg.get("_license")
    if eff is None:
        from neutrino.crypto.desk_license import load_effective_license
        eff = load_effective_license(cfg, read_only=True, bind_nonce=False)

    if not isinstance(eff, dict):
        return {"ok": False, "armed": [], "skipped": list(DEFAULT_AUTOPILOT_CLASSES), "reason": "no license"}

    is_valid = eff.get("valid") is True
    is_desk = eff.get("source") == "desk"
    is_sku = eff.get("sku") == "NEUTRINO"
    claims = eff.get("claims", {})
    has_apply = (eff.get("apply") is True or claims.get("apply") is True)

    # Fail closed: No paper / expired / apply=false -> no apply.d writes; observe only
    if not (is_valid and is_desk and is_sku and has_apply):
        return {
            "ok": False,
            "armed": [],
            "skipped": list(DEFAULT_AUTOPILOT_CLASSES),
            "reason": "license invalid, expired, or apply=false; observe only",
        }

    cfg_with_lic = dict(cfg)
    cfg_with_lic["_license"] = eff

    st = load_revoked_state(cfg)
    if force_on:
        st["autopilot"] = "on"
        save_revoked_state(st, cfg)
    elif st.get("autopilot") == "off":
        return {
            "ok": True,
            "armed": [],
            "skipped": list(DEFAULT_AUTOPILOT_CLASSES),
            "reason": "autopilot explicitly off",
        }

    revoked = set(st.get("revoked", []))
    armed = []
    already_armed = []
    skipped = []

    os.makedirs(apply_dir, exist_ok=True)

    recipe_classes = eff.get("recipe_classes")
    if not recipe_classes:
        rec_obj = eff.get("recipe")
        if isinstance(rec_obj, dict):
            recipe_classes = rec_obj.get("classes")
    if not recipe_classes or len(recipe_classes) == 0:
        from neutrino.recipes import DEFAULT_AUTOPILOT_RECIPE_CLASSES
        recipe_classes = DEFAULT_AUTOPILOT_RECIPE_CLASSES

    has_auto_apply = bool(
        claims.get("auto_apply") is True
        or eff.get("auto_apply") is True
        or cfg.get("auto_apply") is True
        or (eff.get("recipe_valid") and has_apply and "infer-gpu" in eff.get("recipe", {}).get("classes", {}))
    )

    if has_auto_apply:
        target_classes = list(DEFAULT_RECIPE_CLASSES)
    else:
        target_classes = list(DEFAULT_AUTOPILOT_CLASSES)

    for cls_name in target_classes:
        if cls_name == "decode_cap":
            continue
        if cls_name in revoked:
            skipped.append(cls_name)
            continue

        if recipe_classes is not None and not has_auto_apply:
            if isinstance(recipe_classes, (list, tuple, set)) and cls_name not in recipe_classes:
                skipped.append(cls_name)
                continue
            elif isinstance(recipe_classes, dict) and cls_name not in recipe_classes:
                skipped.append(cls_name)
                continue

        en_path = os.path.join(apply_dir, f"{cls_name}.enabled")
        if os.path.isfile(en_path):
            already_armed.append(cls_name)
            continue

        try:
            apply_approve(cls_name, cfg_with_lic)
            conf_p = os.path.join(apply_dir, f"{cls_name}.conf")
            if not os.path.isfile(conf_p):
                with open(conf_p, "w", encoding="utf-8") as cf:
                    cf.write(f"class={cls_name}\nlever=occupancy\nversion_id=autopilot\n")
            state_p = os.path.join(cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR), f"{cls_name}.state")
            if not os.path.isfile(state_p):
                os.makedirs(os.path.dirname(state_p), exist_ok=True)
                with open(state_p, "w", encoding="utf-8") as sf:
                    sf.write(json.dumps({"class": cls_name, "version_id": "autopilot"}))
            armed.append(cls_name)
        except Exception:
            skipped.append(cls_name)

    autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
    if (armed or already_armed) and not os.path.isfile(autopilot_flag):
        neutrino_gid = None
        try:
            import grp
            neutrino_gid = grp.getgrnam("neutrino").gr_gid
        except Exception:
            pass
            flag_data = json.dumps({"enabled": True, "ts": now, "source": "apply_approve"}, indent=2) + chr(10)
            atomic_write(autopilot_flag, flag_data, mode=0o640, gid=neutrino_gid)

    return {
        "ok": True,
        "armed": armed,
        "already_armed": already_armed,
        "skipped": skipped,
        "revoked": list(revoked),
    }


def apply_status(feature_class: Optional[str] = None, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = cfg or {}
    norm_class = str(feature_class or "").strip().lower() if feature_class is not None else None

    # Recipe-wide status across all 11 classes when feature_class is omitted or "all"
    if norm_class is None or norm_class in ("all", ""):
        apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
        auto_enabled = os.path.isfile(os.path.join(apply_dir, "autopilot.enabled"))
        from neutrino.crypto.desk_license import load_effective_license
        lic = load_effective_license(cfg, read_only=True, bind_nonce=False)
        is_licensed = bool(
            lic.get("valid") is True
            and lic.get("source") == "desk"
            and lic.get("sku") == "NEUTRINO"
            and (lic.get("apply", False) or lic.get("claims", {}).get("apply", False))
            and lic.get("recipe_valid", False) is True
        )
        classes_status = {}
        for cls in ALL_CLASSES:
            classes_status[cls] = apply_status(cls, cfg)
        root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
        from neutrino.capture.systemd import get_target_status
        targets = get_effective_targets(cfg)
        target_ids = [t["id"] for t in targets if isinstance(t, dict) and "id" in t]

        targets_info = []
        targets_status = {}
        for t in targets:
            if isinstance(t, dict) and "id" in t:
                tid = t["id"]
                st = get_target_status(t, root=root)
                targets_status[tid] = st
                targets_info.append({
                    "id": tid,
                    "class": t.get("class"),
                    "kind": t.get("kind"),
                    "status": st,
                })

        return {
            "ok": True,
            "autopilot": "on" if auto_enabled else "off",
            "licensed": is_licensed,
            "targets_count": len(target_ids),
            "target_ids": target_ids,
            "targets": targets_info,
            "targets_status": targets_status,
            "classes": classes_status,
        }

    # Meter-only single-class status
    if norm_class in METER_ONLY_CLASSES:
        root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
        from neutrino.capture.systemd import get_target_status
        cls_targets = get_effective_targets(cfg, norm_class=norm_class)
        cls_target_ids = [t["id"] for t in cls_targets if "id" in t]
        cls_targets_info = []
        cls_targets_status = {}
        for t in cls_targets:
            if isinstance(t, dict) and "id" in t:
                tid = t["id"]
                st = get_target_status(t, root=root)
                cls_targets_status[tid] = st
                cls_targets_info.append({
                    "id": tid,
                    "class": t.get("class"),
                    "kind": t.get("kind"),
                    "status": st,
                })
        return {
            "class": norm_class,
            "licensed": False,
            "enabled": False,
            "effective_applied": False,
            "lever": "none",
            "version_id": None,
            "t_start": None,
            "targets_count": len(cls_target_ids),
            "target_ids": cls_target_ids,
            "targets": cls_targets_info,
            "targets_status": cls_targets_status,
            "license_message": f"Class '{norm_class}' cannot be applied or approved (meter-only class)",
        }

    if norm_class not in CLASS_LEVERS:
        raise ValueError(
            f"Unknown feature class '{feature_class}'. "
            f"Supported: {', '.join(sorted(CLASS_LEVERS.keys()))}"
        )

    cfg = cfg or {}
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    lic_ok, lic_msg = verify_apply_license(cfg, feature_class=norm_class)
    enable_path = os.path.join(apply_dir, f"{feature_class}.enabled")

    enabled = False
    details = {}
    if os.path.isfile(enable_path):
        try:
            with open(enable_path, "r", encoding="utf-8") as f:
                details = json.loads(f.read())
                enabled = details.get("enabled", False)
        except Exception:
            enabled = True
    else:
        from neutrino.apply.autopilot import licensed_and_armed
        from neutrino.recipes.registry import get_recipes_for_class
        if licensed_and_armed(cfg):
            recs = get_recipes_for_class(norm_class)
            if any(r.get("auto", True) for r in recs):
                enabled = True
                details = {"lever": recs[0]["lever"] if recs else "occupancy", "version_id": "autopilot"}

    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
    from neutrino.capture.systemd import get_target_status
    cls_targets = get_effective_targets(cfg, norm_class=norm_class)
    cls_target_ids = [t["id"] for t in cls_targets if "id" in t]
    cls_targets_info = []
    cls_targets_status = {}
    for t in cls_targets:
        if isinstance(t, dict) and "id" in t:
            tid = t["id"]
            st = get_target_status(t, root=root)
            cls_targets_status[tid] = st
            cls_targets_info.append({
                "id": tid,
                "class": t.get("class"),
                "kind": t.get("kind"),
                "status": st,
            })

    if norm_class in load_revoked_classes(cfg):
        enabled = False
    effective = bool(enabled and lic_ok)
    return {
        "class": feature_class,
        "licensed": lic_ok,
        "enabled": enabled,
        "effective_applied": effective,
        "lever": details.get("lever", CLASS_LEVERS.get(feature_class, "unspecified")),
        "version_id": details.get("version_id"),
        "t_start": details.get("t_start"),
        "targets_count": len(cls_target_ids),
        "target_ids": cls_target_ids,
        "targets": cls_targets_info,
        "targets_status": cls_targets_status,
        "license_message": lic_msg,
    }


def apply_restore(
    feature_class: str,
    version_id: Optional[str] = None,
    list_versions: bool = False,
    cfg: Optional[Dict[str, Any]] = None,
    list_snapshots: bool = False,
    **kwargs: Any,
) -> Dict[str, Any]:
    list_versions = list_versions or list_snapshots
    cfg = cfg or {}
    backup_base = cfg.get("apply_backup_dir", DEFAULT_APPLY_BACKUP_DIR)
    history_file = cfg.get("apply_history_file", DEFAULT_APPLY_HISTORY_FILE)
    feature_backup_dir = os.path.join(backup_base, feature_class)

    if list_versions:
        versions = []
        if os.path.isdir(feature_backup_dir):
            for v_name in os.listdir(feature_backup_dir):
                v_path = os.path.join(feature_backup_dir, v_name)
                m_file = os.path.join(v_path, "manifest.json")
                if os.path.isfile(m_file):
                    try:
                        with open(m_file, "r", encoding="utf-8") as f:
                            m_data = json.loads(f.read())
                            versions.append({
                                "version_id": v_name,
                                "t_start": m_data.get("t_start") or 0.0,
                                "paths": [p.get("path") for p in m_data.get("paths", [])],
                            })
                    except Exception:
                        pass
            versions.sort(key=lambda x: (x.get("t_start") or 0.0, x.get("version_id")))
        return {"ok": True, "versions": versions}

    if not version_id:
        v_res = apply_restore(feature_class, list_versions=True, cfg=cfg)
        versions = v_res.get("versions", [])
        if versions:
            version_id = versions[-1]["version_id"]
        else:
            raise ValueError("Must specify --version VERSION_ID or --list")

    target_v_dir = os.path.join(feature_backup_dir, version_id)
    manifest_file = os.path.join(target_v_dir, "manifest.json")
    if not os.path.isfile(manifest_file):
        raise FileNotFoundError(f"Unknown version '{version_id}' for class '{feature_class}'")

    with open(manifest_file, "r", encoding="utf-8") as f:
        manifest = json.loads(f.read())

    now = time.time()
    restored_paths = []
    for entry in manifest.get("paths", []):
        path = entry["path"]
        if entry.get("absent"):
            if os.path.exists(path) and not os.path.isdir(path):
                os.unlink(path)
            restored_paths.append(path)
        elif entry.get("is_dir"):
            os.makedirs(path, mode=0o750, exist_ok=True)
            restored_paths.append(path)
        else:
            backup_file = entry.get("backup_file") or os.path.basename(path)
            backup_src = os.path.join(target_v_dir, backup_file)
            parent = os.path.dirname(path)
            os.makedirs(parent, exist_ok=True)
            with open(backup_src, "rb") as s, open(path, "wb") as d:
                d.write(s.read())
            mode = entry.get("mode", 0o640)
            os.chmod(path, mode)
            restored_paths.append(path)

    new_v_id = generate_version_id()
    append_history_event(
        history_file,
        feature_class,
        new_v_id,
        "restore",
        now,
        restored_paths,
        target_v_dir,
        restored_from=version_id,
    )

    remove_revoked_class(feature_class, cfg)
    return {
        "ok": True,
        "class": feature_class,
        "restored_from": version_id,
        "new_version_id": new_v_id,
        "restored_paths": restored_paths,
    }


def apply_revoke(feature_class: Optional[str] = None, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = cfg or {}
    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)

    # If feature_class is omitted or "all", unwrap all auto-attached state across all classes
    if not feature_class or str(feature_class).strip().lower() in ("all", ""):
        results = {}
        revoke_classes = list(DEFAULT_RECIPE_CLASSES)
        for c in SAVINGS_ELIGIBLE_CLASSES:
            if c not in revoke_classes:
                revoke_classes.append(c)
        for cls in revoke_classes:
            try:
                results[cls] = apply_revoke(cls, cfg)
            except Exception as e:
                results[cls] = {"ok": False, "error": str(e)}

        # Clear autopilot.enabled
        autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
        if os.path.isfile(autopilot_flag):
            try:
                os.unlink(autopilot_flag)
            except OSError:
                pass

        # Also detach any remaining attached targets (including unspecified)
        from neutrino.apply.targets import load_accepted_targets
        from neutrino.capture.systemd import detach_target, get_target_status
        targets_data = load_accepted_targets(root=root, apply_dir=apply_dir)
        for u in targets_data.get("units", []):
            u_name = u.get("unit") or u.get("id")
            if not u_name:
                continue
            tspec = {"id": u_name, "unit": u_name, "class": u.get("class", "unspecified"), "kind": "systemd"}
            try:
                detach_target(tspec, root=root)
            except Exception:
                pass

        return {
            "ok": True,
            "revoked": True,
            "class": "all",
            "results": results,
        }

    # Single-class revoke follows
    # def apply_revoke(feature_class: str, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = cfg or {}
    norm_cls = feature_class.strip().lower()
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    backup_base = cfg.get("apply_backup_dir", DEFAULT_APPLY_BACKUP_DIR)
    history_file = cfg.get("apply_history_file", DEFAULT_APPLY_HISTORY_FILE)
    touch_list = get_touch_list(feature_class, apply_dir, state_dir)

    new_v_id = generate_version_id()
    extra_paths = []
    if norm_cls == "compile":
        from neutrino.attach.shims import get_shim_paths
        from neutrino.config import ATTACH_BIN_DIR, ATTACH_PROFILE_D
        bin_dir = cfg.get("attach_bin_dir", ATTACH_BIN_DIR)
        profile_d = cfg.get("attach_profile_d", ATTACH_PROFILE_D)
        extra_paths = get_shim_paths("compile", bin_dir=bin_dir, profile_d_path=profile_d)
    backup_dir = create_backup(feature_class, new_v_id, backup_base, apply_dir, state_dir, extra_paths=extra_paths)

    now = time.time()
    removed = []
    for path in touch_list:
        if os.path.exists(path):
            if os.path.isdir(path):
                # Energy-irrelevant cache: revoke does not delete CCACHE_DIR contents
                continue
            try:
                os.unlink(path)
                removed.append(path)
            except OSError:
                pass

    append_history_event(history_file, feature_class, new_v_id, "revoke", now, removed, backup_dir)

    if norm_cls == "compile":
        try:
            from neutrino.attach.shims import remove_shims
            from neutrino.config import ATTACH_BIN_DIR, ATTACH_PROFILE_D
            bin_dir = cfg.get("attach_bin_dir", ATTACH_BIN_DIR)
            profile_d = cfg.get("attach_profile_d", ATTACH_PROFILE_D)
            remove_shims(["compile"], bin_dir=bin_dir, profile_d_path=profile_d)
        except Exception:
            pass

    # Detach any attached targets for this class
    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
    from neutrino.apply.targets import load_accepted_targets
    from neutrino.capture.systemd import detach_target, get_target_status
    apply_dir = cfg.get("apply_dir")
    targets_data = load_accepted_targets(root=root, apply_dir=apply_dir)
    norm_cls = feature_class.strip().lower()
    for u in targets_data.get("units", []):
        if str(u.get("class") or "").strip().lower() == norm_cls:
            u_name = u["unit"]
            tspec = {"id": u_name, "unit": u_name, "class": norm_cls, "kind": "systemd"}
            if get_target_status(tspec, root=root) == "attached":
                try:
                    detach_target(tspec, root=root)
                except Exception:
                    pass

    # Restore cron and runparts files wrapped for this class
    restored_cron = []
    restored_runparts = []
    try:
        from neutrino.capture.cron import undeploy_cron_target
        from neutrino.capture.runparts import undeploy_runparts_target
        cap_base = os.path.join(root, "var", "lib", "neutrino", "apply", "capture")
        if os.path.isdir(cap_base):
            for entry in os.listdir(cap_base):
                entry_dir = os.path.join(cap_base, entry)
                if not os.path.isdir(entry_dir):
                    continue
                manifests = []
                m_direct = os.path.join(entry_dir, "manifest.json")
                if os.path.isfile(m_direct):
                    manifests.append(m_direct)
                else:
                    try:
                        for sub in os.listdir(entry_dir):
                            m_sub = os.path.join(entry_dir, sub, "manifest.json")
                            if os.path.isfile(m_sub):
                                manifests.append(m_sub)
                    except OSError:
                        pass

                for mpath in manifests:
                    try:
                        with open(mpath, "r", encoding="utf-8") as f:
                            m = json.load(f)
                        if m.get("class") == norm_cls:
                            kind = m.get("kind")
                            if kind == "cron":
                                undeploy_cron_target(m.get("path") or m.get("id") or m.get("key"), root=root)
                                restored_cron.append(m.get("path") or m.get("id") or m.get("key"))
                            elif kind == "runparts":
                                undeploy_runparts_target(m.get("name") or m.get("path"), root=root)
                                restored_runparts.append(m.get("name") or m.get("path"))
                    except Exception:
                        pass
    except Exception:
        pass

    # Undeploy PATH shims for this class
    restored_path = []
    try:
        from neutrino.apply.path_targets import load_path_targets, save_path_targets
        from neutrino.capture.path_shim import undeploy_path_shim, sync_path_environment
        pdata = load_path_targets(root=root)
        changed = False
        for cmd in pdata.get("commands", []):
            if isinstance(cmd, dict) and cmd.get("class") == norm_cls:
                bname = cmd.get("basename")
                if bname:
                    undeploy_path_shim(bname, root=root)
                    restored_path.append(bname)
                    if cmd.get("accepted") is True:
                        cmd["accepted"] = False
                        changed = True
        if changed:
            save_path_targets(pdata, root=root)
        sync_path_environment(root=root)
    except Exception:
        pass

    if norm_cls and cfg.get("record_revoke", True): add_revoked_class(norm_cls, cfg)
    return {
        "ok": True,
        "class": feature_class,
        "revoked": True,
        "backup_dir": backup_dir,
        "removed_paths": removed,
        "restored_cron": restored_cron,
        "restored_runparts": restored_runparts,
        "restored_path": restored_path,
    }


def apply_history(feature_class: str, cfg: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    cfg = cfg or {}
    history_file = cfg.get("apply_history_file", DEFAULT_APPLY_HISTORY_FILE)
    jobs_file = cfg.get("jobs_file", DEFAULT_JOBS_FILE)

    events = []
    if os.path.isfile(history_file):
        with open(history_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        ev = json.loads(line)
                        if ev.get("feature") == feature_class:
                            events.append(ev)
                    except Exception:
                        pass

    all_jobs = []
    if os.path.isfile(jobs_file):
        with open(jobs_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        j = json.loads(line)
                        if j.get("class") == feature_class or j.get("policy", {}).get("class") == feature_class:
                            all_jobs.append(j)
                    except Exception:
                        pass

    periods = []
    prev_energy = None
    now = time.time()

    for ev in events:
        t_start = float(ev.get("t_start", 0))
        t_end = float(ev.get("t_end")) if ev.get("t_end") is not None else now

        period_jobs = [
            j for j in all_jobs
            if t_start <= float(j.get("t_start", 0)) < t_end
        ]

        total_energy = round(sum(float(j.get("energy_j", 0.0)) for j in period_jobs), 3)
        count = len(period_jobs)
        ge_1s_jobs = [j for j in period_jobs if float(j.get("t_elapsed_s", 0.0)) >= 1.0]
        mean_power = 0.0
        if ge_1s_jobs:
            mean_power = round(sum(float(j.get("p_mean_w", 0.0)) for j in ge_1s_jobs) / len(ge_1s_jobs), 3)

        delta_e_desc = None
        if prev_energy is not None:
            delta_e_desc = round(total_energy - prev_energy, 3)

        periods.append({
            "feature": feature_class,
            "version_id": ev.get("version_id"),
            "event": ev.get("event"),
            "t_start": t_start,
            "t_end": ev.get("t_end"),
            "duration_s": round(t_end - t_start, 2),
            "job_count": count,
            "total_energy_j": total_energy,
            "mean_power_w": mean_power,
            "delta_energy_prev_j": delta_e_desc,
            "restored_from": ev.get("restored_from"),
        })
        prev_energy = total_energy

    return periods


def get_active_policy(feature_class: str, cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    norm_class = str(feature_class or "").strip().lower()
    if not norm_class or norm_class == "unspecified":
        return {
            "applied": False,
            "class": "unspecified",
            "lever": None,
            "version_id": None,
        }
    st = apply_status(feature_class, cfg)
    if st.get("effective_applied"):
        return {
            "applied": True,
            "class": feature_class,
            "lever": st.get("lever"),
            "version_id": st.get("version_id"),
        }
    return {
        "applied": False,
        "class": feature_class,
        "lever": None,
        "version_id": None,
    }


def apply_auto_if_permitted(
    feature_class: str,
    cfg: Optional[Dict[str, Any]] = None,
    now: Optional[float] = None,
) -> Dict[str, Any]:
    """
    N2 Auto-Apply Execution:
    1. Verify feature_class is supported and not in EXCLUDED_CLASSES (heartbeat, idle).
    2. Verify cryptographic license authorization (claims.auto_apply).
    3. Evaluate statistical drift across eligible jobs (t >= 1.0s).
    4. If drift tripped and hold active -> queue, mark prescription stale=True without mutation.
    5. If drift tripped, hold elapsed, and authorized -> create touch-list backup, generate
       new version_id, rewrite apply.d (SAME lever), append history row (reason=drift),
       and increment rx_id.
    6. If drift tripped and not authorized -> record stale=True only (N1 behavior).
    """
    cfg = cfg or {}
    now = now if now is not None else time.time()
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    backup_base = cfg.get("apply_backup_dir", DEFAULT_APPLY_BACKUP_DIR)
    history_file = cfg.get("apply_history_file", DEFAULT_APPLY_HISTORY_FILE)
    jobs_file = cfg.get("jobs_file", DEFAULT_JOBS_FILE)

    if feature_class in CLASS_LEVERS:
        lever = CLASS_LEVERS[feature_class]
    else:
        return {"ok": False, "reason": f"unsupported_class_{feature_class}", "class": feature_class}

    from neutrino.drift import (
        evaluate_workload_drift,
        load_drift_state,
        save_drift_state,
        EXCLUDED_CLASSES,
    )
    if feature_class in EXCLUDED_CLASSES:
        return {"ok": False, "reason": "excluded_class", "class": feature_class}

    from neutrino.crypto.desk_license import load_effective_license, is_auto_apply_permitted
    lic = load_effective_license(cfg)
    auto_apply_allowed = is_auto_apply_permitted(lic, feature_class)

    from neutrino.jobs.tracker import load_jobs
    jobs = load_jobs(jobs_file)
    drift_res = evaluate_workload_drift(feature_class, jobs, state_dir=state_dir, now=now)

    drift_state = load_drift_state(feature_class, state_dir)

    if not drift_res.get("tripped"):
        return {
            "ok": True,
            "action": "none",
            "reason": "no_drift",
            "class": feature_class,
            "drift": drift_res,
        }

    # Drift tripped
    if not auto_apply_allowed:
        drift_state["stale"] = True
        drift_state["last_trip_time"] = now
        save_drift_state(feature_class, drift_state, state_dir)
        return {
            "ok": False,
            "action": "prescription_only",
            "reason": "auto_apply_not_authorized",
            "stale": True,
            "class": feature_class,
            "drift": drift_res,
        }

    if drift_res.get("hold_active"):
        drift_state["stale"] = True
        drift_state["last_trip_time"] = now
        save_drift_state(feature_class, drift_state, state_dir)
        return {
            "ok": False,
            "action": "hold_blocked",
            "reason": "hold_active",
            "stale": True,
            "hold_active": True,
            "class": feature_class,
            "drift": drift_res,
        }

    # MUTATION AUTHORIZED AND HOLD ELAPSED: refresh with SAME lever
    version_id = generate_version_id()
    backup_dir = create_backup(feature_class, version_id, backup_base, apply_dir, state_dir)

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    # 1. Enable file (SAME lever)
    enable_path = os.path.join(apply_dir, f"{feature_class}.enabled")
    enable_content = json.dumps({
        "class": feature_class,
        "lever": lever,
        "version_id": version_id,
        "enabled": True,
        "t_start": now,
        "reason": "drift",
    }, indent=2) + "\n"
    atomic_write(enable_path, enable_content, mode=0o640, gid=neutrino_gid)

    # 2. Conf file (SAME lever)
    conf_path = os.path.join(apply_dir, f"{feature_class}.conf")
    conf_content = f"# Neutrino apply configuration for {feature_class}\nclass={feature_class}\nlever={lever}\nversion_id={version_id}\nreason=drift\n"
    atomic_write(conf_path, conf_content, mode=0o640, gid=neutrino_gid)

    # 3. State file (reason=drift)
    state_path = os.path.join(state_dir, f"{feature_class}.state")
    state_content = json.dumps({
        "class": feature_class,
        "status": "auto_approved",
        "reason": "drift",
        "version_id": version_id,
        "t_start": now,
    }, indent=2) + "\n"
    atomic_write(state_path, state_content, mode=0o640, gid=neutrino_gid)

    # 4. History event with reason=drift
    touch_list = get_touch_list(feature_class, apply_dir, state_dir)
    append_history_event(
        history_file,
        feature_class,
        version_id,
        "auto_apply",
        now,
        touch_list,
        backup_dir,
    )

    # 5. Update drift state
    drift_state["mutations_count"] = drift_state.get("mutations_count", 0) + 1
    drift_state["last_mutation_time"] = now
    drift_state["last_mutation_job_count"] = drift_res.get("eligible_count", 0)
    drift_state["rx_id"] = drift_state.get("rx_id", 0) + 1
    drift_state["stale"] = False
    drift_state["last_version_id"] = version_id
    drift_state["baseline_p_w"] = drift_res.get("p_mean_recent")
    drift_state["baseline_t_s"] = drift_res.get("t_mean_recent")
    save_drift_state(feature_class, drift_state, state_dir)

    return {
        "ok": True,
        "action": "mutated",
        "class": feature_class,
        "lever": lever,
        "version_id": version_id,
        "backup_dir": backup_dir,
        "rx_id": drift_state["rx_id"],
        "mutations": drift_state["mutations_count"],
        "t_start": now,
    }


def apply_auto_status(
    feature_class: str,
    cfg: Optional[Dict[str, Any]] = None,
    now: Optional[float] = None,
) -> Dict[str, Any]:
    """Returns structured drift and auto-apply status for feature_class."""
    cfg = cfg or {}
    now = now if now is not None else time.time()
    state_dir = cfg.get("apply_state_dir", DEFAULT_APPLY_STATE_DIR)
    jobs_file = cfg.get("jobs_file", DEFAULT_JOBS_FILE)

    from neutrino.crypto.desk_license import load_effective_license, is_auto_apply_permitted
    lic = load_effective_license(cfg)
    licensed_apply = bool(lic.get("apply", False))
    auto_apply_allowed = is_auto_apply_permitted(lic, feature_class)

    from neutrino.drift import (
        load_drift_state,
        evaluate_workload_drift,
    )
    from neutrino.jobs.tracker import load_jobs

    drift_state = load_drift_state(feature_class, state_dir)
    jobs = load_jobs(jobs_file)
    drift_res = evaluate_workload_drift(feature_class, jobs, state_dir=state_dir, now=now)

    current_status = apply_status(feature_class, cfg)
    active_version = current_status.get("version_id") or drift_state.get("last_version_id")

    return {
        "class": feature_class,
        "licensed_apply": licensed_apply,
        "auto_apply": auto_apply_allowed,
        "last_trip": drift_state.get("last_trip_time"),
        "mutations": drift_state.get("mutations_count", 0),
        "hold_active": drift_res.get("hold_active", False),
        "stale": drift_state.get("stale", False) or drift_res.get("stale", False),
        "need_observe": drift_res.get("need_observe", True),
        "eligible_jobs": drift_res.get("eligible_count", 0),
        "active_version": active_version,
        "lever": current_status.get("lever") or CLASS_LEVERS.get(feature_class, "unspecified"),
    }


def evaluate_drift_for_job(
    job_record: Dict[str, Any],
    cfg: Optional[Dict[str, Any]] = None,
    now: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Hook called after job stop from both CLI (neutrino-run) and agent daemon (/v1/job/stop).
    Evaluates drift and applies auto-apply if authorized and hold elapsed.
    """
    if not isinstance(job_record, dict):
        return {"ok": False, "reason": "invalid_record"}

    job_class = job_record.get("class", "unspecified")
    if job_class in ("heartbeat", "idle", "unspecified"):
        return {"ok": False, "reason": "excluded_class"}

    return apply_auto_if_permitted(job_class, cfg=cfg, now=now)


apply_savings = calculate_apply_savings


def autopilot_sync(root: str = "/", cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Autopilot synchronization hook:
    1. Checks licensed_apply(root=root, cfg=cfg).
       If False: observe only. Do not create .enabled. Do not wrap.
    2. If True:
       a. Write default class enable files for all 8 savings classes:
          batch, compile, etl, oltp, mq, infer-cpu, hpc, render
          (TOUCH_LIST: .enabled, .conf, .state).
       b. Write autopilot.enabled to mark autopilot active.
       c. Run attach_operator_safe(root=root, cfg=cfg).
    Idempotent. Second run does not overwrite active version_id or duplicate drop-ins.
    """
    cfg = cfg or {}
    from neutrino.crypto.desk_license import licensed_apply

    if not licensed_apply(root=root, cfg=cfg):
        return {"ok": False, "licensed_apply": False, "reason": "not_licensed"}

    apply_dir = cfg.get("apply_dir", os.path.join(root, "etc/neutrino/apply.d"))
    state_dir = cfg.get("apply_state_dir", os.path.join(root, "var/lib/neutrino/apply"))
    history_file = cfg.get("apply_history_file", os.path.join(root, "var/lib/neutrino/apply/history.jsonl"))

    os.makedirs(apply_dir, exist_ok=True)
    os.makedirs(state_dir, exist_ok=True)

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    now = time.time()
    enabled_classes = []

    # 1. Ensure default recipe classes exist on licensed host
    revoked = load_revoked_classes(cfg)
    sync_classes = list(DEFAULT_RECIPE_CLASSES)
    for c in SAVINGS_ELIGIBLE_CLASSES:
        if c not in sync_classes:
            sync_classes.append(c)

    for cls in sync_classes:
        if cls == "decode_cap":
            continue
        if cls in revoked:
            continue
        lever = CLASS_LEVERS.get(cls, "occupancy")
        enable_path = os.path.join(apply_dir, f"{cls}.enabled")
        conf_path = os.path.join(apply_dir, f"{cls}.conf")
        state_path = os.path.join(state_dir, f"{cls}.state")

        version_id = None
        if os.path.isfile(enable_path):
            try:
                with open(enable_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if data.get("enabled"):
                        version_id = data.get("version_id")
            except Exception:
                pass

        if not version_id:
            version_id = generate_version_id()
            enable_content = json.dumps({
                "class": cls,
                "lever": lever,
                "version_id": version_id,
                "enabled": True,
                "t_start": now,
                "reason": "autopilot_sync",
            }, indent=2) + "\n"
            atomic_write(enable_path, enable_content, mode=0o640, gid=neutrino_gid)

            if cls == "dump_guard":
                conf_content = (
                    f"# Neutrino apply configuration for dump_guard\n"
                    f"class=dump_guard\n"
                    f"lever=dump_guard\n"
                    f"version_id={version_id}\n"
                    f"reason=autopilot_sync\n"
                )
            elif cls == "compile_handoff":
                conf_content = (
                    f"# Neutrino apply configuration for compile_handoff\n"
                    f"class=compile_handoff\n"
                    f"lever=compile_handoff\n"
                    f"spawn=false\n"
                    f"version_id={version_id}\n"
                    f"reason=autopilot_sync\n"
                )
            else:
                conf_content = f"# Neutrino apply configuration for {cls}\nclass={cls}\nlever={lever}\nversion_id={version_id}\nreason=autopilot_sync\n"
            atomic_write(conf_path, conf_content, mode=0o640, gid=neutrino_gid)

            state_content = json.dumps({
                "class": cls,
                "status": "approved",
                "reason": "autopilot_sync",
                "version_id": version_id,
                "t_start": now,
            }, indent=2) + "\n"
            atomic_write(state_path, state_content, mode=0o640, gid=neutrino_gid)

            touch_list = get_touch_list(cls, apply_dir, state_dir)
            try:
                append_history_event(history_file, cls, version_id, "autopilot_sync", now, touch_list, backup_dir=None)
            except Exception:
                pass

        enabled_classes.append(cls)

    # 2. Mark autopilot.enabled (result of sync, never a predicate)
    autopilot_flag = os.path.join(apply_dir, "autopilot.enabled")
    if not os.path.isfile(autopilot_flag):
            flag_data = json.dumps({"enabled": True, "ts": now, "source": "apply_approve"}, indent=2) + chr(10)
            atomic_write(autopilot_flag, flag_data, mode=0o640, gid=neutrino_gid)

    # 3. Attach operator-safe candidates
    from neutrino.capture import attach_operator_safe
    cap_res = attach_operator_safe(root=root, default_class="unspecified", cfg=cfg)

    # 4. Install attach shims for all enabled classes
    try:
        from neutrino.attach.shims import install_shims
        from neutrino.config import ATTACH_BIN_DIR, ATTACH_PROFILE_D
        bin_dir = cfg.get("attach_bin_dir", ATTACH_BIN_DIR)
        profile_d = cfg.get("attach_profile_d", ATTACH_PROFILE_D)
        install_shims(enabled_classes, bin_dir=bin_dir, profile_d_path=profile_d)
    except Exception:
        pass

    return {
        "ok": True,
        "licensed_apply": True,
        "enabled_classes": enabled_classes,
        "capture": cap_res,
    }

reconcile = autopilot_sync
