"""
substrate.py - Senses local hardware and upstream inference server substrate.
Senses NVML device telemetry (read-only, tolerates missing NVML).
Probes upstream dialect (llama-server, openai, unknown) with 1s timeout.
Zero external dependencies. Zero host literals. Zero hostname in file.
"""

import os
import json
import ctypes
import urllib.request
import urllib.error
from typing import Dict, Any, Optional

DEFAULT_SUBSTRATE_FILE = "/var/lib/neutrino/autopilot/substrate.json"


def sense_nvml() -> Dict[str, Any]:
    """
    Senses NVML GPU device substrate details using ctypes.
    Tolerates any field being absent or NVML not present.
    Never modifies hardware state.
    Records name; does not branch on it.
    """
    info: Dict[str, Any] = {"device_count": 0}
    try:
        from neutrino.hardware.nvml import _find_libnvml
        lib_path = _find_libnvml()
        if not lib_path:
            return info
        lib = ctypes.CDLL(lib_path)
        init_fn = getattr(lib, "nvmlInit_v2", getattr(lib, "nvmlInit", None))
        if not init_fn or init_fn() != 0:
            return info

        count = ctypes.c_uint()
        get_count = getattr(lib, "nvmlDeviceGetCount_v2", getattr(lib, "nvmlDeviceGetCount", None))
        if not get_count or get_count(ctypes.byref(count)) != 0:
            return info
        cnt = int(count.value)
        info["device_count"] = cnt
        if cnt == 0:
            return info

        get_handle = getattr(lib, "nvmlDeviceGetHandleByIndex_v2", getattr(lib, "nvmlDeviceGetHandleByIndex", None))
        if not get_handle:
            return info

        dev = ctypes.c_void_p()
        if get_handle(ctypes.c_uint(0), ctypes.byref(dev)) != 0:
            return info

        # Device name
        get_name = getattr(lib, "nvmlDeviceGetName", None)
        if get_name:
            buf = ctypes.create_string_buffer(96)
            if get_name(dev, buf, ctypes.c_uint(96)) == 0:
                name_str = buf.value.decode("utf-8", errors="replace").strip()
                if name_str:
                    info["name"] = name_str

        # Device UUID
        get_uuid = getattr(lib, "nvmlDeviceGetUUID", None)
        if get_uuid:
            buf = ctypes.create_string_buffer(96)
            if get_uuid(dev, buf, ctypes.c_uint(96)) == 0:
                uuid_str = buf.value.decode("utf-8", errors="replace").strip()
                if uuid_str:
                    info["uuid"] = uuid_str

        # Memory total and free bytes
        get_mem = getattr(lib, "nvmlDeviceGetMemoryInfo", None)
        if get_mem:
            class nvmlMemory_t(ctypes.Structure):
                _fields_ = [
                    ("total", ctypes.c_ulonglong),
                    ("free", ctypes.c_ulonglong),
                    ("used", ctypes.c_ulonglong),
                ]
            mem = nvmlMemory_t()
            if get_mem(dev, ctypes.byref(mem)) == 0:
                info["mem_total_bytes"] = int(mem.total)
                info["mem_free_bytes"] = int(mem.free)

        # Power management limit in mW
        get_pwr_limit = getattr(lib, "nvmlDeviceGetPowerManagementLimit", None)
        if get_pwr_limit:
            pwr = ctypes.c_uint()
            if get_pwr_limit(dev, ctypes.byref(pwr)) == 0:
                info["power_limit_mw"] = int(pwr.value)

    except Exception:
        pass
    return info


def sense_upstream(upstream_url: str = "http://127.0.0.1:8080", timeout: float = 1.0) -> Dict[str, Any]:
    """
    Probes upstream server dialect and capacity with a 1.0s timeout.
    - llama-server dialect if /props or /health returns n_ctx, n_slot, or model
    - OpenAI dialect if /v1/models returns an id list
    - otherwise dialect = unknown
    Tolerates any field being absent.
    """
    upstream_url = upstream_url.rstrip("/")
    dialect = "unknown"
    n_ctx = None
    n_slot = None
    model_id = None
    model_path = None

    # 1. Probe /props
    try:
        req = urllib.request.Request(f"{upstream_url}/props", headers={"User-Agent": "Neutrino-Substrate/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status == 200:
                data = json.loads(resp.read().decode("utf-8"))
                if isinstance(data, dict):
                    def_gen = data.get("default_generation_settings", {})
                    if isinstance(def_gen, dict) and "n_ctx" in def_gen:
                        n_ctx = def_gen["n_ctx"]
                    elif "n_ctx" in data:
                        n_ctx = data["n_ctx"]

                    if "total_slots" in data:
                        n_slot = data["total_slots"]
                    elif "n_slot" in data:
                        n_slot = data["n_slot"]

                    if "model_alias" in data:
                        model_id = data["model_alias"]
                    elif "model" in data:
                        model_id = data["model"]

                    if "model_path" in data and data["model_path"]:
                        model_path = str(data["model_path"])

                    if n_ctx is not None or n_slot is not None or model_id is not None:
                        dialect = "llama-server"
    except Exception:
        pass

    # 2. Probe /health if not yet identified
    if dialect == "unknown":
        try:
            req = urllib.request.Request(f"{upstream_url}/health", headers={"User-Agent": "Neutrino-Substrate/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode("utf-8"))
                    if isinstance(data, dict):
                        if "n_ctx" in data:
                            n_ctx = data["n_ctx"]
                        if "total_slots" in data:
                            n_slot = data["total_slots"]
                        elif "n_slot" in data:
                            n_slot = data["n_slot"]
                        elif "slots_idle" in data or "slots_processing" in data:
                            n_slot = data.get("slots_idle", 0) + data.get("slots_processing", 0)

                        if "model" in data:
                            model_id = data["model"]
                        elif "model_alias" in data:
                            model_id = data["model_alias"]

                        if n_ctx is not None or n_slot is not None or model_id is not None:
                            dialect = "llama-server"
        except Exception:
            pass

    # 3. Probe /v1/models (OpenAI dialect) if still unknown
    if dialect == "unknown":
        try:
            req = urllib.request.Request(f"{upstream_url}/v1/models", headers={"User-Agent": "Neutrino-Substrate/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode("utf-8"))
                    if isinstance(data, dict) and "data" in data and isinstance(data["data"], list) and len(data["data"]) > 0:
                        first = data["data"][0]
                        if isinstance(first, dict) and "id" in first:
                            dialect = "openai"
                            model_id = first["id"]
                    elif isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict) and "id" in data[0]:
                        dialect = "openai"
                        model_id = data[0]["id"]
        except Exception:
            pass

    return {
        "dialect": dialect,
        "n_ctx": n_ctx,
        "n_slot": n_slot,
        "model_id": model_id,
        "model_path": model_path,
    }


def sense_substrate(upstream_url: str = "http://127.0.0.1:8080", timeout: float = 1.0) -> Dict[str, Any]:
    """
    Reads substrate environment across upstream inference server and local NVML.
    Stores: dialect, n_ctx, n_slot, model_id, device_count, mem_total_bytes.
    Tolerates any field being absent.
    CRITICAL: Never includes hostname in output.
    """
    up = sense_upstream(upstream_url=upstream_url, timeout=timeout)
    nv = sense_nvml()

    substrate = {
        "dialect": up.get("dialect", "unknown"),
        "n_ctx": up.get("n_ctx"),
        "n_slot": up.get("n_slot"),
        "model_id": up.get("model_id"),
        "model_path": up.get("model_path"),
        "device_count": nv.get("device_count", 0),
        "mem_total_bytes": nv.get("mem_total_bytes"),
    }
    for k in ("name", "uuid", "mem_free_bytes", "power_limit_mw"):
        if k in nv:
            substrate[k] = nv[k]
    return substrate


def write_substrate_file(
    substrate_data: Dict[str, Any],
    path: str = DEFAULT_SUBSTRATE_FILE,
) -> str:
    """
    Atomically writes substrate.json to disk.
    Ensures directory exists. Zero hostname in file. Mode 0644.
    """
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp_path = f"{path}.tmp.{os.getpid()}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(substrate_data, f, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    try:
        os.chmod(tmp_path, 0o644)
    except OSError:
        pass
    try:
        import grp
        gid = grp.getgrnam("neutrino").gr_gid
        os.chown(tmp_path, -1, gid)
    except Exception:
        pass
    os.replace(tmp_path, path)
    return path
