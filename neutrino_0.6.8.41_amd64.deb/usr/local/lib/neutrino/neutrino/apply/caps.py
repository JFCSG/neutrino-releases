"""
caps.py - Dynamic generation cap calculation and application from substrate and ledger.
Zero hardcoded profiles. Caps derived purely from sensed substrate and empirical ledger.
Standard library only. Zero external dependencies.
"""

import math
from typing import Dict, Any, List, Optional, Tuple


def fnv1a_32(data: str) -> int:
    """Computes standard 32-bit FNV-1a hash."""
    h = 0x811C9DC5
    for b in data.encode("utf-8"):
        h = ((h ^ b) * 0x01000193) & 0xFFFFFFFF
    return h


def compute_p95(values: List[float]) -> float:
    """
    Computes 95th percentile with linear interpolation.
    """
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    if n == 1:
        return float(s[0])
    idx = 0.95 * (n - 1)
    low = int(math.floor(idx))
    high = int(math.ceil(idx))
    weight = idx - low
    return (1.0 - weight) * s[low] + weight * s[high]


GPU_CHILD_CLASSES = ("infer-gpu-chat", "infer-gpu-copy", "infer-gpu-repeat")


CAP_LIMITED_STOP_TYPES = {"limit", "length", "max_tokens", "n_predict"}


def is_cap_limited(job: Dict[str, Any], tokens_out: float) -> bool:
    """
    Checks if a GPU job was truncated / capped by a generation limit:
    Cap-limited means any of:
    - stop_type / finish_reason / stopped_on in {limit, length, max_tokens, n_predict}
    - cap_applied is an int/numeric and tokens_out >= cap_applied
    - policy.working_cap is an int/numeric and tokens_out >= policy.working_cap
    Natural EOS (stop, eos, stop_word, or tokens_out < cap when a cap was set) still votes.
    """
    stop_fields = [
        job.get("stop_type"),
        job.get("finish_reason"),
        job.get("stopped_on"),
    ]
    pol = job.get("policy")
    if isinstance(pol, dict):
        stop_fields.extend([
            pol.get("stop_type"),
            pol.get("finish_reason"),
            pol.get("stopped_on"),
        ])
    for sf in stop_fields:
        if sf is not None and str(sf).strip().lower() in CAP_LIMITED_STOP_TYPES:
            return True

    cap_applied = job.get("cap_applied")
    if cap_applied is not None:
        try:
            cap_val = float(cap_applied)
            if math.isfinite(cap_val) and tokens_out >= cap_val:
                return True
        except (ValueError, TypeError):
            pass

    if isinstance(pol, dict):
        working_cap = pol.get("working_cap")
        if working_cap is not None:
            try:
                wc_val = float(working_cap)
                if math.isfinite(wc_val) and tokens_out >= wc_val:
                    return True
            except (ValueError, TypeError):
                pass

    return False


def is_gpu_job_eligible(job: Dict[str, Any], target_class: str) -> Tuple[bool, Optional[float]]:
    """
    Predicate for GPU child classes:
    - class matches target_class
    - tokens_out (or completion_tokens) is an int/float >= 1
    - energy_gpu_j is present and finite
    - method is nvml_delta, or rail_status is ok
    - wall-clock time (t_elapsed_s) is NOT a gate (e.g. 0.5s / 18 token wrap votes)
    - NOT cap-limited (cap-limited jobs do not vote)
    """
    cls_name = str(job.get("class", "")).strip().lower()
    if cls_name != target_class.strip().lower():
        return False, None

    tok = job.get("tokens_out")
    if tok is None:
        tok = job.get("completion_tokens")
    if tok is None:
        pol = job.get("policy")
        if isinstance(pol, dict) and "tokens_out" in pol:
            tok = pol["tokens_out"]
    if tok is None:
        return False, None
    try:
        tok_val = float(tok)
        if tok_val < 1.0 or not math.isfinite(tok_val):
            return False, None
    except (ValueError, TypeError):
        return False, None

    energy = job.get("energy_gpu_j")
    if energy is None:
        return False, None
    try:
        energy_val = float(energy)
        if not math.isfinite(energy_val):
            return False, None
    except (ValueError, TypeError):
        return False, None

    method = str(job.get("method", "")).strip().lower()
    rail_status = str(job.get("rail_status", "")).strip().lower()
    if method != "nvml_delta" and rail_status != "ok":
        return False, None

    # Exclude cap-limited jobs from voting
    if is_cap_limited(job, tok_val):
        return False, None

    return True, tok_val


def is_cpu_job_eligible(job: Dict[str, Any], target_class: str) -> Tuple[bool, Optional[float]]:
    """
    Predicate for CPU classes:
    - class matches target_class
    - t_elapsed_s >= 1.0 s
    - tokens_out / completion_tokens is present
    """
    cls_name = str(job.get("class", "")).strip().lower()
    if cls_name != target_class.strip().lower():
        return False, None

    t_el = job.get("t_elapsed_s")
    if t_el is None:
        t_el = job.get("duration_s")
    if t_el is None:
        t_start = job.get("t_start")
        t_stop = job.get("t_stop")
        if t_start is not None and t_stop is not None:
            try:
                t_el = float(t_stop) - float(t_start)
            except (ValueError, TypeError):
                t_el = 0.0
    try:
        if t_el is None or float(t_el) < 1.0:
            return False, None
    except (ValueError, TypeError):
        return False, None

    tok = job.get("tokens_out")
    if tok is None:
        tok = job.get("completion_tokens")
    if tok is None:
        pol = job.get("policy")
        if isinstance(pol, dict) and "tokens_out" in pol:
            tok = pol["tokens_out"]
    if tok is not None:
        try:
            return True, float(tok)
        except (ValueError, TypeError):
            pass
    return False, None


def compute_working_cap(child_class: str, jobs: List[Dict[str, Any]]) -> Optional[int]:
    """
    Computes dynamic working cap for a child class:
    Per child class, after at least 5 voting jobs on that class:
        working_cap = ceil(p95 of tokens_out)
    For GPU child classes:
        votes if class matches, tokens_out >= 1, energy_gpu_j is finite, and method==nvml_delta or rail_status==ok.
        Wall-clock time (t_elapsed_s) is NOT a GPU gate (e.g. 0.5s / 18 token wrap votes).
    For CPU classes:
        votes if class matches and t_elapsed_s >= 1.0 s.
    If fewer than 5 eligible jobs, p95 is not ready: returns None.
    Never invents 128 or any static default.
    """
    norm_cls = str(child_class or "").strip().lower()
    is_gpu = norm_cls in GPU_CHILD_CLASSES or norm_cls.startswith("infer-gpu")
    matched: List[float] = []

    for j in jobs:
        if is_gpu:
            ok, tok_val = is_gpu_job_eligible(j, norm_cls)
        else:
            ok, tok_val = is_cpu_job_eligible(j, norm_cls)
        if ok and tok_val is not None:
            matched.append(tok_val)

    if len(matched) < 5:
        return None

    p95 = compute_p95(matched)
    return int(math.ceil(p95))


def apply_dynamic_cap(
    body: Dict[str, Any],
    dialect: str = "llama-server",
    working_cap: Optional[int] = None,
    n_ctx: Optional[int] = None,
    is_holdout: bool = False,
) -> Dict[str, Any]:
    """
    Pass-through: generation cap injection is permanently disabled.
    Neutrino must not clip user content. Do not inject n_predict, max_tokens,
    or working_cap into any outbound body unless the caller already set that field.
    If the caller set it, forward it unchanged without clamping.
    If omitted, leave it omitted.
    """
    return dict(body)
