"""
gpu_rail.py - GPU rail classification, holdout, request rewriting, and NVML energy stamping.
Zero hardcoded profiles. Compares tok/s to node's own holdout.
Standard library only. Zero host literals.
"""

import json
import hashlib
from typing import Dict, Any, List, Optional, Tuple, Set

from neutrino.apply.caps import fnv1a_32, apply_dynamic_cap

FORBIDDEN_KEYS = {
    "spec_type", "draft", "speculative", "speculative_model",
    "draft_model", "model2", "second_model", "--spec-type",
    "id_slot", "slot_id",
}


def extract_prompt_text(body: Dict[str, Any]) -> str:
    """Extracts raw prompt string from either completion or chat body."""
    if "prompt" in body:
        p = body["prompt"]
        if isinstance(p, str):
            return p
        elif isinstance(p, list):
            return " ".join(str(x) for x in p)
    if "messages" in body and isinstance(body["messages"], list):
        parts = []
        for m in body["messages"]:
            if isinstance(m, dict) and "content" in m:
                parts.append(str(m["content"]))
        return "\n".join(parts)
    return ""


def classify_gpu_request(body: Dict[str, Any], seen_prompt_hashes: Set[str]) -> Tuple[str, str]:
    """
    Classify request in order:
    1. Agent wire shape (tools, tool roles, search-replace fences, XML tags) -> infer-gpu-agent
    2. JSON schema, response_format, grammar, or a verbatim/copy instruction -> infer-gpu-copy
    3. prompt SHA-256 already seen in this version window -> infer-gpu-repeat
    4. else -> infer-gpu-chat
    Returns (child_class, prompt_hash).
    """
    prompt_text = extract_prompt_text(body)
    prompt_hash = hashlib.sha256(prompt_text.encode("utf-8")).hexdigest()

    # 1. Check agent wire-shape first
    from neutrino.levers.agent_shape import classify_agent_request
    agent_class, _, _, _ = classify_agent_request(body, prefix_hash=prompt_hash)
    if agent_class == "infer-gpu-agent":
        seen_prompt_hashes.add(prompt_hash)
        return "infer-gpu-agent", prompt_hash

    lower_prompt = prompt_text.lower()
    is_copy = bool(
        "json_schema" in body
        or "response_format" in body
        or "grammar" in body
        or "verbatim" in lower_prompt
        or "copy" in lower_prompt
    )

    if is_copy:
        child_class = "infer-gpu-copy"
    elif prompt_hash in seen_prompt_hashes:
        child_class = "infer-gpu-repeat"
    else:
        child_class = "infer-gpu-chat"

    seen_prompt_hashes.add(prompt_hash)
    return child_class, prompt_hash


def is_agent_holdout(
    session_key: Optional[str] = None,
    prefix_hash: Optional[str] = None,
    turn_index: Optional[int] = None,
    force_holdout: Optional[bool] = None,
) -> bool:
    """FNV-1a of (session_key or prefix_hash or 'none')|(prefix_hash or 'none')|str(turn_index) -> 1-in-20 AGENT turns."""
    if force_holdout is not None:
        return force_holdout
    s_part = session_key or prefix_hash or "none"
    p_part = prefix_hash or "none"
    t_part = str(turn_index if turn_index is not None else 0)
    key = f"{s_part}|{p_part}|{t_part}"
    bucket = fnv1a_32(key)
    return (bucket % 20) == 0


def is_gpu_holdout(
    child_class: str,
    job_id: str,
    session_key: Optional[str] = None,
    prefix_hash: Optional[str] = None,
    turn_index: Optional[int] = None,
    headers: Optional[Dict[str, Any]] = None,
    force_holdout: Optional[bool] = None,
) -> bool:
    """
    Holdout: chat, copy 1 in 20, repeat 1 in 10.
    For infer-gpu-agent: FNV-1a (1 in 20) of:
      key = (session_key or prefix_hash or "none") + "|" + (prefix_hash or "none") + "|" + str(turn_index)
    Existing infer-gpu-chat / copy / repeat holdout behavior unchanged:
      key = f"gpu:{child_class}:{job_id}"
    If force_holdout is provided, returns it directly.
    If headers contains X-Neutrino-Holdout or X-Holdout ("1"/"true"/"yes"/"on"), forces holdout True.
    If headers contains "0"/"false"/"no"/"off", forces holdout False.
    """
    if force_holdout is not None:
        return force_holdout
    if headers:
        for k, v in headers.items():
            if str(k).lower() in ("x-neutrino-holdout", "x-holdout"):
                v_str = str(v).strip().lower()
                if v_str in ("1", "true", "yes", "on"):
                    return True
                elif v_str in ("0", "false", "no", "off"):
                    return False

    if child_class == "infer-gpu-agent":
        return is_agent_holdout(session_key=session_key, prefix_hash=prefix_hash, turn_index=turn_index)

    key = f"gpu:{child_class}:{job_id}"
    bucket = fnv1a_32(key)
    if child_class == "infer-gpu-repeat":
        return (bucket % 10) == 0
    return (bucket % 20) == 0


def propose_decode_cap(
    body: Dict[str, Any],
    turn_class: Optional[str] = None,
    n_ctx: Optional[int] = None,
) -> Optional[int]:
    """
    Observe-only decode cap preview for infer-gpu-agent turns.
    Never mutates wire request.
    - If caller set max_tokens / n_predict / max_completion_tokens: proposed = that value (do not lower it).
    - Else defaults: T1/T2=256, T3/T4=512, T5=128, else None.
    - Never exceed n_ctx // 4 if n_ctx is known and positive.
    """
    val = None
    for k in ("max_tokens", "n_predict", "max_completion_tokens"):
        if k in body and body[k] is not None:
            try:
                val = int(body[k])
                break
            except (ValueError, TypeError):
                pass

    if val is None:
        tc = (turn_class or "").upper()
        if tc in ("T1", "T2"):
            val = 256
        elif tc in ("T3", "T4"):
            val = 512
        elif tc == "T5":
            val = 128
        else:
            val = None

    if val is not None and n_ctx is not None and n_ctx > 0:
        limit = n_ctx // 4
        if val > limit:
            val = limit

    return val


def rewrite_gpu_request(
    body: Dict[str, Any],
    child_class: Any = "infer-gpu",
    is_holdout: bool = False,
    dialect: str = "llama-server",
    working_cap: Optional[int] = None,
    n_ctx: Optional[int] = None,
    session_key: Optional[str] = None,
    cfg: Optional[Dict[str, Any]] = None,
    preview: bool = False,
    armed: Optional[bool] = None,
) -> Any:
    """
    Rewrites inference request according to child class policy.
    Never sends spec_type, draft, speculative model, or a second model id.
    Supports rewrite_gpu_request(body, armed: bool) -> body.
    """
    # Detect if caller is calling single-return API: rewrite_gpu_request(body, armed: bool) -> body
    is_simple = False
    if isinstance(child_class, bool):
        is_simple = True
        eff_armed = child_class
    elif armed is not None and not isinstance(child_class, str):
        is_simple = True
        eff_armed = bool(armed)
    elif armed is not None and child_class == "infer-gpu" and is_holdout is False and dialect == "llama-server" and working_cap is None and n_ctx is None and session_key is None and cfg is None and preview is False:
        is_simple = True
        eff_armed = bool(armed)

    if is_simple:
        if not eff_armed:
            return body
        out = {k: v for k, v in body.items() if str(k).lower() not in FORBIDDEN_KEYS}
        out["cache_prompt"] = True
        out.pop("skip_reading_prefix_cache", None)
        current_stop = out.get("stop", [])
        if isinstance(current_stop, str):
            current_stop = [current_stop]
        elif isinstance(current_stop, (list, tuple)):
            current_stop = list(current_stop)
        else:
            current_stop = []
        if "</think>" not in current_stop:
            current_stop.append("</think>")
        out["stop"] = current_stop
        from neutrino.levers.dump_guard import rewrite_dump_guard
        out, _ = rewrite_dump_guard(body=out, cfg=cfg, is_holdout=False, preview=preview)
        # NEVER set n_predict or max_tokens; caller n_predict preserved if present, omitted if absent
        return out
    # Clone and strip forbidden speculative/draft/slot keys
    out = {k: v for k, v in body.items() if str(k).lower() not in FORBIDDEN_KEYS}

    meta = {
        "child_class": child_class,
        "holdout": is_holdout,
        "dialect": dialect,
        "working_cap": working_cap,
        "n_ctx": n_ctx,
        "session_key": session_key,
        "revoked": False,
    }

    if dialect == "unknown":
        meta["applied"] = False
        meta["reason"] = "unknown-dialect"
        return out, meta

    from neutrino.apply.manager import load_revoked_classes
    revoked_classes = load_revoked_classes(cfg)
    norm_child = str(child_class or "").strip().lower()
    if norm_child in revoked_classes or child_class in revoked_classes:
        meta["applied"] = False
        meta["revoked"] = True
        meta["reason"] = "revoked"
        for forbidden in ("outbound_body", "messages", "tools", "system", "prompt"):
            meta.pop(forbidden, None)
        return out, meta

    if is_holdout and child_class != "infer-gpu-agent":
        # Holdout for chat/copy/repeat: force cache_prompt false for llama/openai dialect
        if dialect in ("llama", "llama-server", "openai"):
            out["cache_prompt"] = False
        meta["applied"] = False
        meta["reason"] = "holdout"
        meta["cache_prompt_injected"] = False
        return out, meta

    # Set initial applied/reason
    if is_holdout:
        meta["applied"] = False
        meta["reason"] = "holdout"
    else:
        meta["applied"] = True
        meta["reason"] = "always"

    if child_class == "infer-gpu-agent":
        from neutrino.levers.prefix_lint import lint_prefix
        from neutrino.levers.agent_shape import classify_agent_request
        from neutrino.levers.dialect import rewrite_agent_dialect

        prefix_break_reason, tools_hash = lint_prefix(body)
        meta["prefix_break_reason"] = prefix_break_reason
        meta["tools_hash"] = tools_hash
        _, compile_handoff, turn_class, agent_meta = classify_agent_request(body)
        meta["compile_handoff"] = compile_handoff
        meta["turn_class"] = turn_class
        meta["agent_detected"] = True
        meta["session_key"] = session_key

        proposed_cap = propose_decode_cap(body=body, turn_class=turn_class, n_ctx=n_ctx)
        meta["proposed_cap"] = proposed_cap
        meta["cap_mutated"] = False

        from neutrino.levers.dump_guard import rewrite_dump_guard
        out, dump_meta = rewrite_dump_guard(body=out, cfg=cfg, is_holdout=is_holdout, preview=preview)
        dump_mut = bool(dump_meta.get("dump_mutated", False))
        dump_sus = True if dump_mut else bool(dump_meta.get("dump_suspect", False))
        if not dump_sus:
            dump_mut = False
        meta["dump_suspect"] = dump_sus
        meta["dump_reason"] = dump_meta.get("dump_reason")
        meta["proposed_action"] = dump_meta.get("proposed_action", "noop")
        meta["dump_mutated"] = dump_mut
        meta["dump_bytes_in"] = dump_meta.get("dump_bytes_in")
        meta["dump_bytes_out"] = dump_meta.get("dump_bytes_out")

        from neutrino.levers.compile_handoff import detect_compile_handoff
        compile_suspect, compile_reason, comp_action, compile_mutated = detect_compile_handoff(body=body)
        meta["compile_suspect"] = compile_suspect
        meta["compile_reason"] = compile_reason
        if compile_suspect:
            meta["proposed_action"] = comp_action
        meta["compile_mutated"] = False

        out, dialect_telem = rewrite_agent_dialect(
            body=out,
            dialect=dialect,
            session_key=session_key,
            is_holdout=is_holdout,
        )
        meta.update(dialect_telem)
        meta["cache_prompt_injected"] = dialect_telem.get("cache_prompt_injected", False)
        meta["cache_control_injected"] = dialect_telem.get("cache_control_injected", False)
        meta["dump_flag"] = dialect_telem.get("dump_flag", False)
        meta["dump_tok"] = dialect_telem.get("dump_tok")
        meta["dump_repeats"] = dialect_telem.get("dump_repeats", 0)
        meta["proposed_cap"] = proposed_cap
        meta["cap_mutated"] = False
        for forbidden in ("outbound_body", "messages", "tools", "system", "prompt"):
            meta.pop(forbidden, None)
        return out, meta

    elif child_class in ("infer-gpu", "infer-gpu-chat", "infer-gpu-repeat", "infer-gpu-copy", "think", "llama-server"):
        # Autopilot GPU wrap: cache_prompt=true, dump_guard, commit-stop when armed.
        # NEVER inject n_predict or max_tokens.
        if dialect in ("llama", "llama-server", "openai"):
            out["cache_prompt"] = True
            out.pop("skip_reading_prefix_cache", None)
            meta["cache_prompt_injected"] = True
            # Commit-stop: stop on first scored letter / commit token without mutating template or n_predict
            current_stop = out.get("stop", [])
            if isinstance(current_stop, str):
                current_stop = [current_stop]
            elif not isinstance(current_stop, list):
                current_stop = []
            if "</think>" not in current_stop:
                current_stop.append("</think>")
            out["stop"] = current_stop
            meta["commit_stop"] = True

        # Stacking dump_guard
        from neutrino.levers.dump_guard import rewrite_dump_guard
        out, dump_meta = rewrite_dump_guard(body=out, cfg=cfg, is_holdout=is_holdout, preview=preview)
        meta["dump_mutated"] = dump_meta.get("dump_mutated", False)
        if not is_holdout:
            meta["version_id"] = "autopilot"
            meta["recipes"] = ["r-prefix-kv", "r-dump-guard", "r-commit-stop"]

    elif child_class == "infer-gpu-copy":
        # copy: cache on, grammar/JSON only if caller already asked,
        # thinking off only if caller did not ask for a trace
        if dialect == "llama-server":
            out["cache_prompt"] = True
            out.pop("skip_reading_prefix_cache", None)
            meta["cache_prompt_injected"] = True

        prompt_text = extract_prompt_text(body).lower()
        has_trace = any(term in prompt_text for term in ("trace", "reasoning", "step-by-step", "think"))
        has_reasoning_setting = ("reasoning_format" in body or "thinking" in body)
        if not has_trace and not has_reasoning_setting:
            if dialect == "llama-server":
                out["reasoning_format"] = "none"

    elif child_class == "infer-gpu-repeat":
        # repeat: cache on only
        if dialect == "llama-server":
            out["cache_prompt"] = True
            out.pop("skip_reading_prefix_cache", None)
            meta["cache_prompt_injected"] = True

    for forbidden in ("outbound_body", "messages", "tools", "system", "prompt"):
        meta.pop(forbidden, None)
    return out, meta


def extract_engine_response_tokens(
    resp_bytes: bytes,
    resp_content_type: str = "",
) -> Tuple[Optional[int], Optional[int], Optional[float], Optional[str]]:
    """
    Extracts (prompt_tokens, completion_tokens, ttft_s, stop_type) from engine response.
    Handles both non-streaming JSON and streaming SSE (text/event-stream).
    Never invents tokens. If usage/timings missing, returns None.
    Preserves exact 4-tuple return for all callers.
    """
    prompt_tokens = None
    completion_tokens = None
    ttft_s = None
    stop_type = None

    if not resp_bytes:
        return None, None, None, None

    text = resp_bytes.decode("utf-8", errors="replace").strip()
    if not text:
        return None, None, None, None

    # 1. Try standard JSON
    if text.startswith("{") and text.endswith("}"):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                usage = data.get("usage")
                if isinstance(usage, dict):
                    if "prompt_tokens" in usage and usage["prompt_tokens"] is not None:
                        try:
                            prompt_tokens = int(usage["prompt_tokens"])
                        except (ValueError, TypeError):
                            pass
                    if "completion_tokens" in usage and usage["completion_tokens"] is not None:
                        try:
                            completion_tokens = int(usage["completion_tokens"])
                        except (ValueError, TypeError):
                            pass

                if completion_tokens is None and "tokens_predicted" in data and data["tokens_predicted"] is not None:
                    try:
                        completion_tokens = int(data["tokens_predicted"])
                    except (ValueError, TypeError):
                        pass

                if prompt_tokens is None and "tokens_evaluated" in data and data["tokens_evaluated"] is not None:
                    try:
                        prompt_tokens = int(data["tokens_evaluated"])
                    except (ValueError, TypeError):
                        pass

                timings = data.get("timings")
                if isinstance(timings, dict):
                    if completion_tokens is None and "predicted_n" in timings and timings["predicted_n"] is not None:
                        try:
                            completion_tokens = int(timings["predicted_n"])
                        except (ValueError, TypeError):
                            pass
                    if prompt_tokens is None and "prompt_n" in timings and timings["prompt_n"] is not None:
                        try:
                            prompt_tokens = int(timings["prompt_n"])
                        except (ValueError, TypeError):
                            pass

                    if "prompt_ms" in timings and timings["prompt_ms"] is not None:
                        try:
                            ttft_s = round(float(timings["prompt_ms"]) / 1000.0, 3)
                        except (ValueError, TypeError):
                            pass
                    elif "t_prompt_processing_ms" in timings and timings["t_prompt_processing_ms"] is not None:
                        try:
                            ttft_s = round(float(timings["t_prompt_processing_ms"]) / 1000.0, 3)
                        except (ValueError, TypeError):
                            pass

                stop_type = data.get("stop_type")
                if not stop_type and "choices" in data and isinstance(data["choices"], list) and len(data["choices"]) > 0:
                    first_choice = data["choices"][0]
                    if isinstance(first_choice, dict):
                        stop_type = first_choice.get("finish_reason")

        except Exception:
            pass

    # 2. Try streaming SSE (text/event-stream)
    elif "data:" in text:
        try:
            for line in text.splitlines():
                line = line.strip()
                if line.startswith("data: ") and not line.endswith("[DONE]"):
                    payload = line[6:].strip()
                    try:
                        chunk = json.loads(payload)
                        if isinstance(chunk, dict):
                            usage = chunk.get("usage")
                            if isinstance(usage, dict):
                                if "prompt_tokens" in usage and usage["prompt_tokens"] is not None:
                                    prompt_tokens = int(usage["prompt_tokens"])
                                if "completion_tokens" in usage and usage["completion_tokens"] is not None:
                                    completion_tokens = int(usage["completion_tokens"])

                            timings = chunk.get("timings")
                            if isinstance(timings, dict):
                                if "predicted_n" in timings and timings["predicted_n"] is not None:
                                    completion_tokens = int(timings["predicted_n"])
                                if "prompt_n" in timings and timings["prompt_n"] is not None:
                                    prompt_tokens = int(timings["prompt_n"])
                                if "prompt_ms" in timings and timings["prompt_ms"] is not None:
                                    ttft_s = round(float(timings["prompt_ms"]) / 1000.0, 3)

                            choices = chunk.get("choices")
                            if isinstance(choices, list) and choices:
                                c0 = choices[0]
                                if isinstance(c0, dict) and c0.get("finish_reason"):
                                    stop_type = c0.get("finish_reason")
                    except Exception:
                        continue
        except Exception:
            pass

    return prompt_tokens, completion_tokens, ttft_s, stop_type


def extract_engine_cache_tokens(
    resp_bytes: bytes,
    resp_content_type: str = "",
    prompt_tokens: Optional[int] = None,
) -> Tuple[Optional[int], Optional[int], Optional[bool]]:
    """
    Extracts (cached_tok, cache_miss_tok, prefix_hit) from engine response.
    First non-null of:
      usage.prompt_tokens_details.cached_tokens
      usage.cached_tokens
      timings.cache_n
    prefix_hit = (cached_tok > 0) only when cached_tok is not None; else None.
    cache_miss_tok = prompt_tok - cached_tok only when both finite; else None.
    Never invents tokens. If usage/timings missing, returns (None, None, None).
    """
    if not resp_bytes:
        return None, None, None

    text = resp_bytes.decode("utf-8", errors="replace").strip()
    if not text:
        return None, None, None

    cached_tokens = None
    p_tok = prompt_tokens

    # 1. Try standard JSON
    if text.startswith("{") and text.endswith("}"):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                usage = data.get("usage")
                if isinstance(usage, dict):
                    details = usage.get("prompt_tokens_details")
                    if isinstance(details, dict) and "cached_tokens" in details and details["cached_tokens"] is not None:
                        cached_tokens = details["cached_tokens"]
                    elif "cached_tokens" in usage and usage["cached_tokens"] is not None:
                        cached_tokens = usage["cached_tokens"]

                    if p_tok is None and "prompt_tokens" in usage and usage["prompt_tokens"] is not None:
                        p_tok = usage["prompt_tokens"]

                if cached_tokens is None:
                    timings = data.get("timings")
                    if isinstance(timings, dict):
                        if "cache_n" in timings and timings["cache_n"] is not None:
                            cached_tokens = timings["cache_n"]
                        if p_tok is None and "prompt_n" in timings and timings["prompt_n"] is not None:
                            p_tok = timings["prompt_n"]

                if p_tok is None and "tokens_evaluated" in data and data["tokens_evaluated"] is not None:
                    p_tok = data["tokens_evaluated"]

        except Exception:
            pass

    # 2. Try streaming SSE (text/event-stream)
    elif "data:" in text:
        try:
            for line in text.splitlines():
                line = line.strip()
                if line.startswith("data: ") and not line.endswith("[DONE]"):
                    payload = line[6:].strip()
                    try:
                        chunk = json.loads(payload)
                        if isinstance(chunk, dict):
                            usage = chunk.get("usage")
                            if isinstance(usage, dict):
                                details = usage.get("prompt_tokens_details")
                                if isinstance(details, dict) and "cached_tokens" in details and details["cached_tokens"] is not None:
                                    cached_tokens = details["cached_tokens"]
                                elif "cached_tokens" in usage and usage["cached_tokens"] is not None:
                                    cached_tokens = usage["cached_tokens"]
                                if p_tok is None and "prompt_tokens" in usage and usage["prompt_tokens"] is not None:
                                    p_tok = usage["prompt_tokens"]

                            timings = chunk.get("timings")
                            if isinstance(timings, dict):
                                if cached_tokens is None and "cache_n" in timings and timings["cache_n"] is not None:
                                    cached_tokens = timings["cache_n"]
                                if p_tok is None and "prompt_n" in timings and timings["prompt_n"] is not None:
                                    p_tok = timings["prompt_n"]
                    except Exception:
                        continue
        except Exception:
            pass

    cached_tok_int = None
    if cached_tokens is not None:
        try:
            cached_tok_int = int(cached_tokens)
        except (ValueError, TypeError):
            cached_tok_int = None

    p_tok_int = None
    if p_tok is not None:
        try:
            p_tok_int = int(p_tok)
        except (ValueError, TypeError):
            p_tok_int = None

    if cached_tok_int is not None:
        prefix_hit = bool(cached_tok_int > 0)
    else:
        prefix_hit = None

    if p_tok_int is not None and cached_tok_int is not None:
        cache_miss_tok = max(0, p_tok_int - cached_tok_int)
    else:
        cache_miss_tok = None

    return cached_tok_int, cache_miss_tok, prefix_hit


def stamp_gpu_telemetry(
    start_mj: Optional[int],
    stop_mj: Optional[int],
    device_count: int,
    t_start: float,
    t_stop: float,
    ttft_s: Optional[float] = None,
    tokens_out: Optional[int] = None,
    cap_applied: Optional[int] = None,
    n_ctx_sensed: Optional[int] = None,
    prompt_tokens: Optional[int] = None,
    completion_tokens: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Stamps NVML total-energy delta, wrap-aware, method nvml_delta,
    summed across devices in the call window.
    If NVML is missing, stamps rail_status no_gpu and does not invent joules.
    """
    from neutrino.hardware.nvml import compute_gpu_counter_delta_j, is_nvml_readable

    t_elapsed_s = round(t_stop - t_start, 3)
    if completion_tokens is None and tokens_out is not None:
        completion_tokens = tokens_out
    if tokens_out is None and completion_tokens is not None:
        tokens_out = completion_tokens

    if not is_nvml_readable() or start_mj is None or stop_mj is None or device_count == 0:
        return {
            "rail_status": "no_gpu",
            "energy_gpu_j": None,
            "j_per_tok": None,
            "tok_s": None,
            "ttft_s": ttft_s,
            "tokens_out": tokens_out,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "t_elapsed_s": t_elapsed_s,
            "cap_applied": cap_applied,
            "n_ctx_sensed": n_ctx_sensed,
            "device_count": device_count,
            "method": "none",
        }

    energy_gpu_j = compute_gpu_counter_delta_j(start_mj, stop_mj)

    j_per_tok = None
    if energy_gpu_j is not None and completion_tokens and completion_tokens > 0:
        j_per_tok = round(float(energy_gpu_j) / float(completion_tokens), 3)

    tok_s = None
    if completion_tokens and completion_tokens > 0 and t_elapsed_s > 0.001:
        tok_s = round(float(completion_tokens) / float(t_elapsed_s), 2)

    return {
        "rail_status": "ok",
        "energy_gpu_j": energy_gpu_j,
        "j_per_tok": j_per_tok,
        "tok_s": tok_s,
        "ttft_s": ttft_s,
        "tokens_out": tokens_out,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "t_elapsed_s": t_elapsed_s,
        "cap_applied": cap_applied,
        "n_ctx_sensed": n_ctx_sensed,
        "device_count": device_count,
        "method": "nvml_delta",
    }


def extract_engine_timings(
    resp_bytes: bytes,
    resp_content_type: str = "",
) -> Tuple[Optional[float], Optional[float]]:
    """
    Extracts (prompt_ms, predicted_ms) from engine response timings object.
    Never invents timings. If timings missing, returns (None, None).
    """
    prompt_ms = None
    predicted_ms = None

    if not resp_bytes:
        return None, None

    text = resp_bytes.decode("utf-8", errors="replace").strip()
    if not text:
        return None, None

    if text.startswith("{") and text.endswith("}"):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                timings = data.get("timings")
                if isinstance(timings, dict):
                    if "prompt_ms" in timings and timings["prompt_ms"] is not None:
                        try:
                            prompt_ms = round(float(timings["prompt_ms"]), 3)
                        except (ValueError, TypeError):
                            pass
                    elif "t_prompt_processing_ms" in timings and timings["t_prompt_processing_ms"] is not None:
                        try:
                            prompt_ms = round(float(timings["t_prompt_processing_ms"]), 3)
                        except (ValueError, TypeError):
                            pass

                    if "predicted_ms" in timings and timings["predicted_ms"] is not None:
                        try:
                            predicted_ms = round(float(timings["predicted_ms"]), 3)
                        except (ValueError, TypeError):
                            pass
                    elif "t_token_generation_ms" in timings and timings["t_token_generation_ms"] is not None:
                        try:
                            predicted_ms = round(float(timings["t_token_generation_ms"]), 3)
                        except (ValueError, TypeError):
                            pass
        except Exception:
            pass
    elif "data:" in text:
        try:
            for line in text.splitlines():
                line = line.strip()
                if line.startswith("data: ") and not line.endswith("[DONE]"):
                    payload = line[6:].strip()
                    try:
                        chunk = json.loads(payload)
                        if isinstance(chunk, dict):
                            timings = chunk.get("timings")
                            if isinstance(timings, dict):
                                if "prompt_ms" in timings and timings["prompt_ms"] is not None:
                                    prompt_ms = round(float(timings["prompt_ms"]), 3)
                                if "predicted_ms" in timings and timings["predicted_ms"] is not None:
                                    predicted_ms = round(float(timings["predicted_ms"]), 3)
                    except Exception:
                        pass
        except Exception:
            pass

    return prompt_ms, predicted_ms
