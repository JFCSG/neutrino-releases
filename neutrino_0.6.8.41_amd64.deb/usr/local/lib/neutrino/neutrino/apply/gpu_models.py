"""
gpu_models.py - Depth 3 model inspection and sibling classification for GPU workloads.
Inspects loaded model path via substrate.json, loopback engine /props, or proc arguments.
Lists and classifies sibling .gguf files in the model directory.
STD_LIB ONLY. Read-only inspection only. Never writes or bounces engine.
"""

import os
import re
import json
import urllib.request
import urllib.error
from typing import Dict, Any, List, Optional, Tuple

DEFAULT_SUBSTRATE_FILE = "/var/lib/neutrino/autopilot/substrate.json"


def extract_param_size(s: str) -> Optional[float]:
    """Extracts parameter size in billions (e.g. 27B -> 27.0, 1.5B -> 1.5)."""
    m = re.search(r"[-_.]([0-9]+(?:\.[0-9]+)?)b[-_.]", s.lower())
    if m:
        try:
            return float(m.group(1))
        except ValueError:
            return None
    return None


def find_loaded_model_path(cfg: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """
    Attempts to locate the loaded GGUF model path without restarting the engine:
    1. cfg['model_path'] if explicitly provided (e.g. tests)
    2. substrate.json if already sensed (cfg['autopilot_substrate_file'] or default)
    3. Loopback engine GET http://127.0.0.1:8080/props
    4. /proc inspection on local Linux host for llama-server cmdline
    """
    cfg = cfg or {}

    # 1. Explicit in cfg
    if cfg.get("model_path"):
        return str(cfg["model_path"])

    # 2. Check substrate.json
    root = cfg.get("root", os.environ.get("NU_ROOT", "/"))
    sub_file = cfg.get("autopilot_substrate_file")
    if not sub_file:
        sub_file = os.path.join(root, "var/lib/neutrino/autopilot/substrate.json")
    if os.path.exists(sub_file):
        try:
            with open(sub_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and data.get("model_path"):
                    return str(data["model_path"])
        except Exception:
            pass

    # 3. Query loopback engine /props (127.0.0.1 only)
    upstream = cfg.get("upstream_url", "http://127.0.0.1:8080").rstrip("/")
    if "127.0.0.1" in upstream or "localhost" in upstream:
        try:
            req = urllib.request.Request(
                f"{upstream}/props",
                headers={"User-Agent": "Neutrino-Depth3-Preview/1.0"},
            )
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                if resp.status == 200:
                    props_data = json.loads(resp.read().decode("utf-8"))
                    if isinstance(props_data, dict) and props_data.get("model_path"):
                        return str(props_data["model_path"])
        except Exception:
            pass

    # 4. Fallback: inspect local /proc for llama-server cmdline
    proc_dir = os.path.join(root, "proc")
    if os.path.isdir(proc_dir):
        try:
            for pid_entry in os.listdir(proc_dir):
                if not pid_entry.isdigit():
                    continue
                cmdline_path = os.path.join(proc_dir, pid_entry, "cmdline")
                try:
                    with open(cmdline_path, "rb") as f:
                        cmd_bytes = f.read()
                    parts = cmd_bytes.split(b"\x00")
                    if any(b"llama-server" in p for p in parts[:2]):
                        for i, p in enumerate(parts):
                            if p in (b"-m", b"--model") and i + 1 < len(parts):
                                m_path = parts[i + 1].decode("utf-8", errors="replace")
                                if m_path.endswith(".gguf"):
                                    return m_path
                except Exception:
                    continue
        except Exception:
            pass

    return None


def classify_sibling(loaded_basename: str, sibling_basename: str) -> Tuple[str, str]:
    """
    Classifies a sibling .gguf file relative to the loaded model.
    Returns (kind, use).
    - kind: "quant_sibling" | "draft" | "unknown"
    - use: "path_switch_not_spec_decode" | "spec_decode" | "not_draft_until_named"
    """
    l_lower = loaded_basename.lower()
    s_lower = sibling_basename.lower()

    # 1. Explicit draft markers in filename
    if "draft" in s_lower or "spec" in s_lower:
        return "draft", "spec_decode"

    # 2. Check parameter size comparison
    l_param = extract_param_size(loaded_basename)
    s_param = extract_param_size(sibling_basename)
    if l_param and s_param and s_param < l_param * 0.5:
        return "draft", "spec_decode"

    # 3. Quant sibling detection:
    # Same stem, different quant tag (PQ2 vs PTQ1)
    quant_pattern = r"[-_.](?:p[tqp][0-9]+(?:_[0-9]+)?|q[0-9]+(?:_[a-z0-9_]+)?|iq[0-9]+(?:_[a-z0-9_]+)?|f16|f32|bf16)\.gguf$"
    l_stem = re.sub(quant_pattern, "", l_lower, flags=re.IGNORECASE)
    s_stem = re.sub(quant_pattern, "", s_lower, flags=re.IGNORECASE)

    if l_stem and s_stem and l_stem == s_stem:
        return "quant_sibling", "path_switch_not_spec_decode"

    if l_param and s_param and l_param == s_param:
        if "bonsai" in l_lower and "bonsai" in s_lower:
            return "quant_sibling", "path_switch_not_spec_decode"

    return "unknown", "not_draft_until_named"


def get_depth3_preview(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Constructs the Depth 3 preview dictionary for infer-gpu classes.
    Read-only inspection only. Does not touch or bounce the engine.
    """
    cfg = cfg or {}
    loaded_path = find_loaded_model_path(cfg)

    model_dir = cfg.get("model_dir")
    if not model_dir and loaded_path:
        model_dir = os.path.dirname(loaded_path)

    loaded_basename = os.path.basename(loaded_path) if loaded_path else None
    siblings: List[Dict[str, Any]] = []

    if model_dir and os.path.isdir(model_dir):
        try:
            for fname in sorted(os.listdir(model_dir)):
                if not fname.endswith(".gguf"):
                    continue
                if loaded_basename and fname == loaded_basename:
                    continue
                fpath = os.path.join(model_dir, fname)
                if not os.path.isfile(fpath):
                    continue
                try:
                    fsize = os.path.getsize(fpath)
                except Exception:
                    fsize = 0
                kind, use = classify_sibling(loaded_basename or "", fname)
                siblings.append({
                    "basename": fname,
                    "bytes": fsize,
                    "kind": kind,
                    "use": use,
                })
        except Exception:
            pass

    n_siblings = len(siblings)
    draft_siblings = [s for s in siblings if s["use"] == "spec_decode"]
    quant_siblings = [s for s in siblings if s["kind"] == "quant_sibling"]

    if draft_siblings:
        spec_decode = {
            "possible": True,
            "candidate": draft_siblings[0]["basename"],
            "reason": None,
        }
        need_draft_file = False
    elif quant_siblings:
        spec_decode = {
            "possible": False,
            "reason": "no draft GGUF; sibling is same 27B quant",
        }
        need_draft_file = True
    else:
        spec_decode = {
            "possible": False,
            "reason": "no draft GGUF found",
        }
        need_draft_file = True

    if quant_siblings:
        path_switch = {
            "possible": True,
            "candidate": quant_siblings[0]["basename"],
            "warning": "different quant; not matched-work; needs engine bounce on a later ticket",
        }
    else:
        path_switch = {
            "possible": False,
            "candidate": None,
            "warning": "no quant sibling found",
        }

    need_model_file = (n_siblings == 0)

    return {
        "loaded_basename": loaded_basename,
        "n_siblings": n_siblings,
        "siblings": siblings,
        "spec_decode": spec_decode,
        "path_switch": path_switch,
        "need_draft_file": need_draft_file,
        "need_model_file": need_model_file,
    }
