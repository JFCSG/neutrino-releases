"""
occupancy.py - CPU core occupancy and affinity execution helper for Neutrino.
Applies child-process CPU core affinity when occupancy lever is active.
Standard library only. Zero external dependencies.
"""

import os
import sys
from typing import Dict, Any, Optional, Tuple, Callable

from neutrino.apply.manager import get_active_policy

DEFAULT_APPLY_DIR = "/etc/neutrino/apply.d"
EXCLUDED_CLASSES = {"heartbeat", "idle", "unspecified"}


def resolve_occupancy_affinity(
    job_class: str,
    cfg: Optional[Dict[str, Any]] = None,
    explicit_cpus: Optional[int] = None,
) -> Tuple[bool, Optional[int], Optional[Callable[[], None]], str]:
    """
    Evaluates whether CPU core occupancy (affinity) should be applied to the child workload.

    Rules:
    1. If class is in {heartbeat, idle}: do not set affinity.
    2. If NEUTRINO_NO_AFFINITY=1 (clinic/debug test escape, default off): do not set affinity.
       Note: NEUTRINO_NO_AFFINITY is strictly an environment variable for debugging and
       comparative benchmark arms (e.g. Arm A vs Arm B). It is NOT a configuration knob
       and cannot be enabled by auto_apply or license claims.
    3. If apply.d/<class>.enabled and lever == occupancy (or default batch occupancy):
       - Default n = os.cpu_count() (or len of current affinity mask). NOT capped at 2.
       - If apply.d/<class>.conf explicitly sets cpus: K (K >= 1), use min(K, cpu_count).
       - If explicit_cpus passed (e.g. CLI --cpus), use min(explicit_cpus, cpu_count).
       Returns (True, n, preexec_fn, "affinity")
    4. Otherwise:
       Returns (False, None, None, "default")
    """
    cfg = cfg or {}
    norm_class = str(job_class or "unspecified").strip().lower()

    if norm_class in EXCLUDED_CLASSES:
        return False, None, None, "excluded_class"

    # Clinic/debug test escape (default off)
    if os.environ.get("NEUTRINO_NO_AFFINITY") == "1":
        return False, None, None, "debug_no_affinity"

    policy = get_active_policy(norm_class, cfg)
    lever = policy.get("lever")
    # Also handle default batch occupancy if applied or if lever is occupancy
    if not lever and norm_class == "batch":
        lever = "occupancy"

    is_applied = bool(policy.get("applied"))
    if not (is_applied and lever == "occupancy"):
        return False, None, None, "not_applied"

    cpu_count = os.cpu_count() or 2
    current_affinity_len = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else cpu_count

    # Check for explicit cpus override in apply.d/<class>.conf
    conf_override_cpus = None
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    conf_file = os.path.join(apply_dir, f"{norm_class}.conf")
    if os.path.isfile(conf_file):
        try:
            with open(conf_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        if "=" in line:
                            k, v = line.split("=", 1)
                        elif ":" in line:
                            k, v = line.split(":", 1)
                        else:
                            continue
                        if k.strip().lower() == "cpus":
                            val = int(v.strip())
                            if val >= 1:
                                conf_override_cpus = val
        except Exception:
            pass

    target_override = explicit_cpus if explicit_cpus is not None else (cfg.get("cpus") or conf_override_cpus)
    if target_override is not None:
        try:
            n = min(int(target_override), cpu_count)
        except (ValueError, TypeError):
            n = current_affinity_len
    else:
        # Default for batch race-to-idle: full socket / current affinity width
        n = current_affinity_len

    n = max(1, min(n, cpu_count))

    def preexec_fn():
        if hasattr(os, "sched_setaffinity"):
            os.sched_setaffinity(0, set(range(n)))

    return True, n, preexec_fn, "affinity"
