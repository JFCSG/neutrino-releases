"""
oltp_load.py - Neutrino OLTP workload durability helper for SQLite.
Executes OLTP record inserts with path-jailed database file and durability policy gating.
When class == "oltp" AND apply.d/oltp.enabled AND claims.apply AND not baseline:
  one connection, BEGIN, N inserts, one COMMIT.
  stamps lever=group-commit execution=one_txn
Otherwise:
  one connection, commit per insert (N commits).
  stamps lever=none execution=commit_each
PRAGMA synchronous=FULL on both arms (honest durability, F4 family).
Path jail: TOUCH_LIST ∪ /var/tmp ∪ /var/lib/neutrino/oltp/.
File mode 0600.
Counts real COMMIT statements. Standard library only.
"""

import argparse
import os
import sqlite3
import sys
from typing import Dict, Any, Optional, Tuple

from neutrino.config import (
    DEFAULT_APPLY_DIR,
    TOUCH_LIST,
    DEFAULT_CONFIG_PATH,
    load_config,
)
from neutrino.apply.manager import get_active_policy

DEFAULT_OLTP_PATH = "/var/lib/neutrino/oltp/x5.db"
ALLOWED_PREFIXES = [
    "/var/tmp/",
    "/var/lib/neutrino/oltp/",
]


def check_path_jail(path: str, cfg: Optional[Dict[str, Any]] = None) -> str:
    """
    Confines target path to TOUCH_LIST ∪ /var/tmp ∪ /var/lib/neutrino/oltp/.
    Refuses paths outside the approved jail (e.g. /etc/passwd, /usr/bin).
    """
    if not path or not isinstance(path, str):
        raise ValueError("Invalid target path specified")

    abs_path = os.path.abspath(path)
    real_path = os.path.realpath(abs_path)

    valid_prefixes = list(ALLOWED_PREFIXES)
    touch_prefixes = cfg.get("touch_list", TOUCH_LIST) if cfg else TOUCH_LIST
    for p in touch_prefixes:
        valid_prefixes.append(p)

    matched = False
    for prefix in valid_prefixes:
        p_clean = os.path.realpath(prefix) if os.path.exists(prefix) else os.path.abspath(prefix)
        if not p_clean.endswith(os.sep) and not prefix.endswith(os.sep):
            p_clean += os.sep

        if abs_path == prefix.rstrip(os.sep) or abs_path.startswith(p_clean) or real_path.startswith(p_clean):
            matched = True
            break

    if not matched:
        raise PermissionError(f"Path jail violation: '{path}' is outside approved directories")

    return abs_path


def resolve_oltp_policy(
    job_class: str,
    cfg: Optional[Dict[str, Any]] = None,
    baseline: bool = False,
) -> Tuple[bool, str, str]:
    """
    Evaluates whether group-commit should be applied to the OLTP workload.
    Rules:
    1. If baseline or NEUTRINO_LEVER_OFF==1: returns (False, "commit_each", "none").
    2. Active only when job_class == "oltp" AND apply.d/oltp.enabled AND claims.apply.
       Returns (True, "one_txn", "group-commit")
    3. Disabled or other class:
       Returns (False, "commit_each", "none")
    """
    cfg = cfg or {}
    norm_class = str(job_class or "unspecified").strip().lower()

    if norm_class != "oltp" or baseline or os.environ.get("NEUTRINO_LEVER_OFF") == "1":
        return False, "commit_each", "none"

    policy = get_active_policy("oltp", cfg)
    is_applied = bool(policy.get("applied"))
    if not is_applied:
        env_group = os.environ.get("NEUTRINO_OLTP_GROUP")
        if env_group == "1":
            is_applied = True

    if is_applied:
        return True, "one_txn", "group-commit"

    return False, "commit_each", "none"


def run_oltp_load(
    path: str = DEFAULT_OLTP_PATH,
    n: int = 1000,
    job_class: str = "oltp",
    cfg: Optional[Dict[str, Any]] = None,
    baseline: bool = False,
) -> Dict[str, Any]:
    """
    Executes N record inserts into target SQLite database using a single connection.
    Unlinks DB beforehand so COUNT/SUM are from this run only.
    Honest durability: PRAGMA synchronous = FULL on both arms.
    Counts real COMMIT executions.
    """
    if n <= 0:
        raise ValueError("Record count n must be positive")

    target_path = check_path_jail(path, cfg)
    parent_dir = os.path.dirname(target_path)
    if parent_dir:
        os.makedirs(parent_dir, mode=0o750, exist_ok=True)
        try:
            import grp
            gid = grp.getgrnam("neutrino").gr_gid
            os.chown(parent_dir, -1, gid)
        except Exception:
            pass

    for extra in ("", "-journal", "-wal", "-shm"):
        p = target_path + extra
        if os.path.exists(p):
            try:
                os.unlink(p)
            except OSError:
                pass

    fd = os.open(target_path, os.O_CREAT | os.O_RDWR, 0o600)
    os.close(fd)
    os.chmod(target_path, 0o600)

    applied, execution, lever = resolve_oltp_policy(job_class, cfg, baseline=baseline)

    if applied:
        os.environ["NEUTRINO_ATTACH_INJECT"] = "group-commit"
        os.environ["NEUTRINO_ATTACH_CLASS"] = "oltp"
    else:
        os.environ.pop("NEUTRINO_ATTACH_INJECT", None)

    real_commits = 0

    conn = sqlite3.connect(target_path, isolation_level=None)
    try:
        cursor = conn.cursor()
        cursor.execute("PRAGMA synchronous = FULL;")
        cursor.execute("PRAGMA journal_mode = DELETE;")

        cursor.execute("CREATE TABLE records (id INTEGER PRIMARY KEY, val INTEGER, payload TEXT);")

        if applied:
            cursor.execute("BEGIN IMMEDIATE;")
            for i in range(n):
                cursor.execute(
                    "INSERT INTO records (id, val, payload) VALUES (?, ?, ?);",
                    (i, i * 2, f"rec-{i}"),
                )
            cursor.execute("COMMIT;")
            real_commits += 1
        else:
            for i in range(n):
                cursor.execute("BEGIN IMMEDIATE;")
                cursor.execute(
                    "INSERT INTO records (id, val, payload) VALUES (?, ?, ?);",
                    (i, i * 2, f"rec-{i}"),
                )
                cursor.execute("COMMIT;")
                real_commits += 1

        cursor.execute("SELECT COUNT(*), SUM(val) FROM records;")
        row = cursor.fetchone()
        count = row[0] if row else 0
        sum_val = row[1] if (row and row[1] is not None) else 0

    finally:
        conn.close()

    if os.path.exists(target_path):
        os.chmod(target_path, 0o600)

    print(
        f"records={count} checksum={sum_val} commits={real_commits} "
        f"lever={lever} execution={execution}",
        flush=True,
    )

    return {
        "path": target_path,
        "records": count,
        "checksum": sum_val,
        "commits": real_commits,
        "lever": lever,
        "execution": execution,
        "applied": applied,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Neutrino OLTP workload durability helper")
    parser.add_argument("--path", default=DEFAULT_OLTP_PATH, help="Target SQLite database path")
    parser.add_argument("--n", type=int, default=1000, help="Number of records to insert")
    parser.add_argument("--class", dest="job_class", default="oltp", help="Workload class")
    parser.add_argument("--config", default=DEFAULT_CONFIG_PATH, help="Path to neutrino.toml")
    parser.add_argument("--baseline", action="store_true", help="Force baseline (Arm A) autocommit mode")

    args = parser.parse_args(argv)
    cfg = load_config(args.config) if os.path.isfile(args.config) else {}

    try:
        run_oltp_load(
            path=args.path,
            n=args.n,
            job_class=args.job_class,
            cfg=cfg,
            baseline=args.baseline,
        )
    except (PermissionError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
