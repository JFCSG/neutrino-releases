"""
neutrino.apply package initialization.
"""

from neutrino.apply.manager import (
    CLASS_LEVERS,
    get_touch_list,
    get_effective_targets,
    apply_preview,
    apply_approve,
    apply_status,
    apply_restore,
    apply_revoke,
    apply_history,
    apply_auto_if_permitted,
    apply_auto_status,
    evaluate_drift_for_job,
    get_active_policy,
    autopilot_sync,
    licensed_apply,
)

from neutrino.apply.occupancy import resolve_occupancy_affinity

from neutrino.apply.materialize import resolve_compile_materialize

from neutrino.apply.mq_append import run_mq_append, resolve_mq_batch_policy

from neutrino.apply.oltp_load import run_oltp_load, resolve_oltp_policy

from neutrino.apply.autopilot import (
    PRIOR_ON,
    PRIOR_OFF,
    DELTA_E_GATE,
    MIN_N,
    MIN_T,
    HOLDOUT_EVERY,
    qualify,
    check_and_advance_holdout,
    get_class_report_label,
    autopilot_pass,
    autopilot_on,
    autopilot_off,
    pass_,
    is_rail_armed,
    rail_autopilot_on,
    rail_autopilot_off,
)

from neutrino.apply.recipe import (
    ALL_CLASSES,
    MANDATORY_METER_ONLY,
    DEFAULT_METER_ONLY,
    DENY_BASENAMES,
    VALID_TARGET_KINDS,
    validate_recipe,
    validate_target,
    load_recipe,
    get_recipe_targets,
    get_meter_only_classes,
    save_recipe,
)

from neutrino.apply.targets import (
    DEFAULT_TARGETS_JSON_PATH,
    get_targets_path,
    load_accepted_targets,
    save_accepted_targets,
    find_target_unit,
    accept_unit_entry,
    remove_target_unit,
)

from neutrino.apply.substrate import (
    sense_substrate,
    sense_nvml,
    sense_upstream,
    write_substrate_file,
)

from neutrino.apply.caps import (
    fnv1a_32,
    compute_p95,
    compute_working_cap,
    apply_dynamic_cap,
    is_gpu_job_eligible,
    is_cpu_job_eligible,
    is_cap_limited,
)

from neutrino.apply.cpu_rail import (
    CPU_CLASS_LEVERS,
    evaluate_cpu_qualification,
    decide_cpu_job,
)

from neutrino.apply.gpu_rail import (
    classify_gpu_request,
    is_gpu_holdout,
    is_agent_holdout,
    rewrite_gpu_request,
    stamp_gpu_telemetry,
    extract_engine_response_tokens,
    extract_engine_cache_tokens,
    propose_decode_cap,
    extract_engine_timings,
)
