"""
targets.py - Local target unit accept and management for Neutrino Apply.
Controls /etc/neutrino/apply.d/targets.json:
1. Local accept registry for systemd service units.
2. Discovery integration: auto-propose operator units, note vendor units.
3. Accept logic: enforce class mapping, require dummy verification, prevent deny-list.
4. Schema version 1:
   {
     "version": 1,
     "units": [
       {
         "unit": "foo.service",
         "class": "batch",
         "accepted": true
       }
     ]
   }
Standard library only. Zero external dependencies.
"""

import json
import os
import secrets
from typing import Dict, Any, List, Optional, Set

from neutrino.capture.recipe import DENY_BASENAMES, check_deny_match, ALL_CLASSES
from neutrino.capture.systemd import (
    find_unit_file,
    dummy_target,
    dummy_status,
    attach_target,
    detach_target,
    get_target_status,
)

DEFAULT_TARGETS_JSON_PATH = "/etc/neutrino/apply.d/targets.json"


def get_targets_path(root: str = "/", apply_dir: Optional[str] = None) -> str:
    """Returns absolute path to targets.json under root or apply_dir."""
    if apply_dir:
        return os.path.join(apply_dir, "targets.json")
    return os.path.join(root, "etc", "neutrino", "apply.d", "targets.json")


def load_accepted_targets(root: str = "/", apply_dir: Optional[str] = None) -> Dict[str, Any]:
    """
    Loads targets.json under root.
    Returns {"version": 1, "units": []} if missing or invalid.
    """
    path = get_targets_path(root, apply_dir=apply_dir)
    if not os.path.isfile(path):
        return {"version": 1, "units": []}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if (
                isinstance(data, dict)
                and data.get("version") == 1
                and isinstance(data.get("units"), list)
            ):
                return data
    except Exception:
        pass
    return {"version": 1, "units": []}


def save_accepted_targets(targets_data: Dict[str, Any], root: str = "/", apply_dir: Optional[str] = None) -> str:
    """
    Atomically writes targets.json under root with mode 0640.
    Attempts group chown to 'neutrino' if running as root.
    """
    if (
        not isinstance(targets_data, dict)
        or targets_data.get("version") != 1
        or not isinstance(targets_data.get("units"), list)
    ):
        raise ValueError("Invalid targets_data: must be dict with version=1 and list 'units'")

    path = get_targets_path(root, apply_dir=apply_dir)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    neutrino_gid = None
    try:
        import grp
        neutrino_gid = grp.getgrnam("neutrino").gr_gid
    except Exception:
        pass

    tmp_path = f"{path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(targets_data, f, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())

    if neutrino_gid is not None and os.geteuid() == 0:
        try:
            os.chown(tmp_path, -1, neutrino_gid)
        except OSError:
            pass

    os.chmod(tmp_path, 0o640)
    os.replace(tmp_path, path)
    return path


def find_target_unit(unit_name: str, targets_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Finds unit entry in targets_data by unit name (case-insensitive)."""
    norm = unit_name.strip().lower()
    for u in targets_data.get("units", []):
        if isinstance(u, dict):
            u_name = str(u.get("unit") or u.get("id") or "").strip().lower()
            if u_name == norm:
                return u
    return None


def accept_unit_entry(
    unit_name: str,
    feature_class: Optional[str] = None,
    root: str = "/",
    overlay: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Accepts a single unit into targets.json.
    Enforces:
    1. Unit must end in .service; refuses .timer.
    2. Refuses neutrino.service.
    3. Refuses host-survival deny list.
    4. Enforces class mapping: if feature_class is None, uses existing class on row or returns need_class.
    5. Runs dummy verification before accept.
    """
    unit_clean = unit_name.strip()
    if unit_clean.endswith(".timer"):
        service_equiv = unit_clean[:-6] + ".service"
        raise ValueError(
            f"Cannot wrap timer unit '{unit_clean}'. A timer has no ExecStart; wrap '{service_equiv}' instead."
        )
    if not unit_clean.endswith(".service"):
        raise ValueError(f"Systemd unit must end in .service, got '{unit_clean}'")
    if unit_clean == "neutrino.service":
        raise ValueError("Cannot wrap neutrino.service")

    deny_hit = check_deny_match(unit_clean, set(DENY_BASENAMES))
    if deny_hit:
        raise ValueError(f"Unit '{unit_clean}' matches denied basename '{deny_hit}'")

    targets_data = load_accepted_targets(root=root)
    existing = find_target_unit(unit_clean, targets_data)

    target_class = None
    if feature_class:
        target_class = str(feature_class).strip().lower()
    elif existing and existing.get("class"):
        target_class = str(existing.get("class")).strip().lower()

    if not target_class:
        return {
            "ok": False,
            "status": "need_class",
            "unit": unit_clean,
            "message": f"Unit '{unit_clean}' has no class mapping. Pass --class <class> to accept.",
        }

    all_set = set(ALL_CLASSES)
    if target_class not in all_set:
        raise ValueError(f"Unknown class '{target_class}'. Allowed: {sorted(all_set)}")

    # Verify unit exists and run dummy check
    target_spec = {
        "id": unit_clean,
        "unit": unit_clean,
        "class": target_class,
        "kind": "systemd",
    }
    dummy_res = dummy_target(target_spec, root=root, overlay=overlay)
    if not dummy_res.get("ok"):
        raise RuntimeError(f"Dummy verification failed for '{unit_clean}'")

    # Update or append in targets_data
    if existing:
        existing["class"] = target_class
        existing["accepted"] = True
    else:
        targets_data["units"].append({
            "unit": unit_clean,
            "class": target_class,
            "accepted": True,
        })

    save_accepted_targets(targets_data, root=root)
    return {
        "ok": True,
        "status": "accepted",
        "unit": unit_clean,
        "class": target_class,
        "accepted": True,
    }


def remove_target_unit(unit_name: str, root: str = "/") -> bool:
    """Removes a unit entry from targets.json."""
    data = load_accepted_targets(root=root)
    norm = unit_name.strip().lower()
    orig_len = len(data.get("units", []))
    data["units"] = [
        u for u in data.get("units", [])
        if str(u.get("unit") or u.get("id") or "").strip().lower() != norm
    ]
    if len(data["units"]) != orig_len:
        save_accepted_targets(data, root=root)
        return True
    return False
