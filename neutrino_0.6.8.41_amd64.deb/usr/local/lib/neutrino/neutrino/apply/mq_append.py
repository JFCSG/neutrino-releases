"""
mq_append.py - MQ append workload durability helper for Neutrino.
Executes append workloads with path-jailed file writes and durability policy gating.
When class == "mq" AND apply.d/mq.enabled AND claims.apply:
  batches fsyncs every K records (default 50) + final fsync.
Otherwise:
  executes write + os.fsync per record.
Counts real os.fsync calls directly. Standard library only.
"""

import argparse
import os
import sys
from typing import Dict, Any, Optional, Tuple

from neutrino.config import (
    DEFAULT_APPLY_DIR,
    TOUCH_LIST,
    DEFAULT_CONFIG_PATH,
    load_config,
)
from neutrino.apply.manager import get_active_policy

DEFAULT_MQ_PATH = "/var/lib/neutrino/mq/x4.log"
ALLOWED_PREFIXES = [
    "/var/tmp/",
    "/var/lib/neutrino/mq/",
]


def check_path_jail(path: str, cfg: Optional[Dict[str, Any]] = None) -> str:
    """
    Confines target path to TOUCH_LIST ∪ /var/tmp ∪ /var/lib/neutrino/mq/.
    Refuses paths outside the approved jail (e.g. /etc/passwd, /usr/bin).
    """
    if not path or not isinstance(path, str):
        raise ValueError("Invalid target path specified")

    # Canonicalize target directory and path
    abs_path = os.path.abspath(path)
    real_path = os.path.realpath(abs_path)

    # Allowed roots: TOUCH_LIST + ALLOWED_PREFIXES
    valid_prefixes = list(ALLOWED_PREFIXES)
    touch_prefixes = cfg.get("touch_list", TOUCH_LIST) if cfg else TOUCH_LIST
    for p in touch_prefixes:
        valid_prefixes.append(p)

    matched = False
    for prefix in valid_prefixes:
        # Check against both abs_path and real_path
        p_clean = os.path.realpath(prefix) if os.path.exists(prefix) else os.path.abspath(prefix)
        if not p_clean.endswith(os.sep) and not prefix.endswith(os.sep):
            p_clean += os.sep

        if abs_path == prefix.rstrip(os.sep) or abs_path.startswith(p_clean) or real_path.startswith(p_clean):
            matched = True
            break

    if not matched:
        raise PermissionError(f"Path jail violation: '{path}' is outside approved directories")

    return abs_path


def resolve_mq_batch_policy(
    job_class: str,
    cfg: Optional[Dict[str, Any]] = None,
    explicit_k: Optional[int] = None,
    baseline: bool = False,
) -> Tuple[bool, int, str, str]:
    """
    Evaluates whether batched fsync should be applied to the MQ append workload.
    Rules:
    1. Active only when job_class == "mq" AND apply.d/mq.enabled AND claims.apply.
    2. Batch size K:
       - explicit_k argument or --batch K
       - OR conf file apply.d/mq.conf (batch_k = ...)
       - OR env NEUTRINO_MQ_BATCH
       - OR default 50
       Returns (True, K, "batched_fsync", "batched-fsync")
    3. Disabled or other class:
       Returns (False, 1, "fsync_each", "none")
    """
    cfg = cfg or {}
    norm_class = str(job_class or "unspecified").strip().lower()

    if norm_class != "mq" or baseline or os.environ.get("NEUTRINO_LEVER_OFF") == "1":
        return False, 1, "fsync_each", "none"

    policy = get_active_policy("mq", cfg)
    if not policy.get("applied"):
        return False, 1, "fsync_each", "none"

    # Resolve batch size K
    k = 50
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    conf_file = os.path.join(apply_dir, "mq.conf")
    if os.path.isfile(conf_file):
        try:
            with open(conf_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        if "=" in line:
                            key, val = line.split("=", 1)
                        elif ":" in line:
                            key, val = line.split(":", 1)
                        else:
                            continue
                        if key.strip().lower() in ("batch_k", "batch", "k"):
                            k = int(val.strip())
        except Exception:
            pass

    if "batch_k" in cfg:
        try:
            k = int(cfg["batch_k"])
        except (ValueError, TypeError):
            pass

    env_k = os.environ.get("NEUTRINO_MQ_BATCH")
    if env_k is not None:
        try:
            k = int(env_k)
        except (ValueError, TypeError):
            pass

    if explicit_k is not None:
        try:
            k = int(explicit_k)
        except (ValueError, TypeError):
            pass

    k = max(1, k)
    return True, k, "batched_fsync", "batched-fsync"


def run_mq_append(
    path: str = DEFAULT_MQ_PATH,
    n: int = 1000,
    payload_bytes: int = 256,
    batch_k: Optional[int] = None,
    cfg: Optional[Dict[str, Any]] = None,
    job_class: str = "mq",
    baseline: bool = False,
    k: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Executes N record writes to target file.
    Tracks real fsync calls directly.
    """
    if n <= 0:
        raise ValueError("Record count n must be positive")
    if payload_bytes < 16:
        payload_bytes = 16

    target_path = check_path_jail(path, cfg)
    parent_dir = os.path.dirname(target_path)
    if parent_dir:
        os.makedirs(parent_dir, mode=0o750, exist_ok=True)
        try:
            import grp
            gid = grp.getgrnam("neutrino").gr_gid
            os.chown(parent_dir, -1, gid)
        except Exception:
            pass

    if k is not None:
        batch_k = k
    applied, k, execution, lever = resolve_mq_batch_policy(job_class, cfg, explicit_k=batch_k, baseline=baseline)
    if applied:
        os.environ["NEUTRINO_ATTACH_INJECT"] = "batch_fsync"
        os.environ["NEUTRINO_ATTACH_CLASS"] = "mq"
    else:
        os.environ.pop("NEUTRINO_ATTACH_INJECT", None)

    # Clean target file if exists
    try:
        if os.path.exists(target_path):
            os.unlink(target_path)
    except OSError:
        pass

    # Open unbuffered POSIX fd
    fd = os.open(target_path, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    real_fsync_count = 0
    total_bytes = 0
    id_checksum = 0

    # Payload template: sequential ID formatted to 8 digits, padded with 'x'
    # e.g. "00000001 xxxxxxxxx...\n"
    pad_len = payload_bytes - 10
    pad_bytes = b"x" * max(0, pad_len) + b"\n"

    try:
        for i in range(n):
            record = f"{i:08d} ".encode("ascii") + pad_bytes
            rec_len = len(record)
            written = 0
            while written < rec_len:
                w = os.write(fd, record[written:])
                written += w
            total_bytes += written
            id_checksum += i

            if applied:
                if (i + 1) % k == 0:
                    os.fsync(fd)
                    real_fsync_count += 1
            else:
                os.fsync(fd)
                real_fsync_count += 1

        # Final durability fsync
        os.fsync(fd)
        real_fsync_count += 1
    finally:
        os.close(fd)

    # Print machine-parseable output
    print(
        f"records={n} bytes={total_bytes} fsyncs={real_fsync_count} checksum={id_checksum} "
        f"lever={lever} execution={execution} batch_k={k if applied else 1}",
        flush=True,
    )

    return {
        "path": target_path,
        "records": n,
        "bytes": total_bytes,
        "fsyncs": real_fsync_count,
        "checksum": id_checksum,
        "lever": lever,
        "execution": execution,
        "batch_k": k if applied else 1,
        "applied": applied,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Neutrino MQ append workload durability helper")
    parser.add_argument("--path", default=DEFAULT_MQ_PATH, help="Target append log path")
    parser.add_argument("--n", type=int, default=1000, help="Number of records to append")
    parser.add_argument("--payload-bytes", type=int, default=256, help="Byte size per record")
    parser.add_argument("--batch", type=int, default=None, help="Explicit batch flush size override K")
    parser.add_argument("--k", type=int, default=None, help="Explicit batch flush size override K")
    parser.add_argument("--baseline", action="store_true", help="Force baseline (Arm A) mode")
    parser.add_argument("--class", dest="job_class", default="mq", help="Workload class")
    parser.add_argument("--config", default=DEFAULT_CONFIG_PATH, help="Path to neutrino.toml")

    args = parser.parse_args(argv)
    cfg = load_config(args.config) if os.path.isfile(args.config) else {}

    try:
        run_mq_append(
            path=args.path,
            n=args.n,
            payload_bytes=args.payload_bytes,
            batch_k=args.batch or args.k,
            cfg=cfg,
            job_class=args.job_class,
            baseline=args.baseline,
        )
    except (PermissionError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
