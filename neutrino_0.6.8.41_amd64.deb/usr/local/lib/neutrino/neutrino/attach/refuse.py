"""neutrino/attach/refuse.py - Process refusal list for attach daemon."""

REFUSE_COMM = frozenset({
    "sshd", "systemd", "systemd-udevd", "neutrino", "neutrino-setup",
    "oracle", "postgres", "postmaster", "mariadbd", "mysqld", "mysqld_safe",
})
