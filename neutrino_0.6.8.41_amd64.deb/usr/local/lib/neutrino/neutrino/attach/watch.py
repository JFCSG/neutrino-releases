"""neutrino/attach/watch.py - Kernel Netlink & Proc attach process monitor."""
import json
import os
import socket
import struct
import sys
import threading
import time
from typing import Dict, Any, Optional, List

from neutrino.attach.classify import classify_process
from neutrino.attach.refuse import REFUSE_COMM
from neutrino.attach.jobs import (
    record_attach_job,
    next_slot,
    is_coverage_experiment_enabled,
)
from neutrino.config import DEFAULT_JOBS_FILE, DEFAULT_ATTACH_POLL_SEC
from neutrino.hardware.rapl import read_package_rapl_energy, compute_counter_delta_j

_WATCH_THREAD: Optional[threading.Thread] = None
_NETLINK_ACTIVE: bool = False

CLASSIFIED_COUNTS: Dict[str, int] = {
    "compile": 0,
    "render": 0,
    "batch": 0,
    "oltp": 0,
    "mq": 0,
    "hpc": 0,
    "etl": 0,
    "infer-cpu": 0,
    "idle": 0,
    "heartbeat": 0,
}
_COUNTS_LOCK = threading.Lock()

RECIPE_LEVERS: Dict[str, str] = {
    "batch": "occupancy",
    "hpc": "occupancy",
    "render": "occupancy",
    "oltp": "group-commit",
    "mq": "batch_fsync",
    "etl": "residency",
    "infer-cpu": "materialize",
}


def is_watch_alive() -> bool:
    """Returns True if the background attach watcher thread is running."""
    global _WATCH_THREAD
    return _WATCH_THREAD is not None and _WATCH_THREAD.is_alive()


def get_watch_status() -> Dict[str, Any]:

    """Returns runtime telemetry for GET /v1/attach."""
    from neutrino.attach.jobs import get_coverage_state
    cov_state = get_coverage_state()
    cov_slots = {k: v.get("slot", 0) for k, v in cov_state.items()}

    with _COUNTS_LOCK:
        counts = dict(CLASSIFIED_COUNTS)

    apply_dir = "/etc/neutrino/apply.d"
    approved = set()
    if os.path.isdir(apply_dir):
        try:
            for f in os.listdir(apply_dir):
                if f.endswith(".enabled"):
                    approved.add(f[:-8])
        except Exception:
            pass

    return {
        "status": "active",
        "netlink_active": _NETLINK_ACTIVE,
        "classified_counts": counts,
        "coverage_slots": cov_slots,
        "approved_classes": sorted(approved),
    }


def try_create_netlink_socket() -> Optional[socket.socket]:
    """Attempts to bind and subscribe to Netlink proc connector."""
    try:
        s = socket.socket(socket.AF_NETLINK, socket.SOCK_DGRAM, 11)
        s.bind((os.getpid(), 1))
        nlmsg = struct.pack("=IHHII", 40, 3, 0, 0, os.getpid())
        cnmsg = struct.pack("=IIIIHH", 1, 1, 0, 0, 4, 0)
        op = struct.pack("=I", 1)
        s.send(nlmsg + cnmsg + op)
        return s
    except Exception:
        return None


def _is_class_approved(job_class: str, cfg: Dict[str, Any]) -> bool:
    apply_dir = cfg.get("apply_dir", "/etc/neutrino/apply.d")
    return os.path.isfile(os.path.join(apply_dir, f"{job_class}.enabled"))


def _jobs_n(argv: List[str]) -> Optional[int]:
    """Extracts job count N from make/gmake/ninja argv.

    Returns:
      1 for -j1 / --jobs=1 / -j 1 / --jobs 1
      N for -jN / --jobs=N with N >= 2
      999 for bare -j
      None if no jobs flag is present
    """
    if not argv or len(argv) <= 1:
        return None
    for i, a in enumerate(argv[1:], 1):
        if a in ("-j", "--jobs"):
            if i + 1 < len(argv) and argv[i+1].isdigit():
                return int(argv[i+1])
            return 999  # bare -j is parallel
        if a.startswith("-j") and a[2:].isdigit():
            return int(a[2:])
        if a.startswith("--jobs="):
            try:
                return int(a.split("=", 1)[1])
            except ValueError:
                return None
    return None


def _handle_exec_event(pid: int, active_jobs: Dict[int, Any], cfg: Dict[str, Any]):
    comm_path = f"/proc/{pid}/comm"
    try:
        with open(comm_path, "r", encoding="utf-8") as f:
            comm = f.read().strip()
    except Exception:
        return

    if comm in REFUSE_COMM:
        return

    cmdline = []
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = [x.decode("utf-8", "replace") for x in f.read().split(b"\x00") if x]
    except Exception:
        pass

    environ = {}
    try:
        with open(f"/proc/{pid}/environ", "rb") as f:
            for item in f.read().split(b"\x00"):
                if b"=" in item:
                    k, v = item.split(b"=", 1)
                    environ[k.decode("utf-8", "replace")] = v.decode("utf-8", "replace")
    except Exception:
        pass

    cls = classify_process(comm, cmdline=cmdline, environ=environ)
    if not cls:
        return

    with _COUNTS_LOCK:
        if cls in CLASSIFIED_COUNTS:
            CLASSIFIED_COUNTS[cls] += 1

    approved = _is_class_approved(cls, cfg)
    injected_lever = None
    jobs_n = _jobs_n(cmdline)

    env_inject = environ.get("NEUTRINO_ATTACH_INJECT")
    if cls == "compile" and comm in ("make", "gmake", "ninja"):
        if jobs_n == 1:
            injected_lever = None  # serial: never occupancy
        elif jobs_n is not None and jobs_n >= 2:
            injected_lever = "occupancy"  # buyer parallel: stamp only
        elif env_inject == "occupancy":
            injected_lever = "occupancy"  # shim injected
        else:
            injected_lever = None
    elif cls in RECIPE_LEVERS:
        if approved and env_inject and env_inject == RECIPE_LEVERS[cls]:
            injected_lever = env_inject
        elif cls == "batch" and comm in ("pigz", "lbzip2") and approved:
            injected_lever = "occupancy"
        else:
            injected_lever = None

    uj_start, max_r = read_package_rapl_energy()
    active_jobs[pid] = {
        "class": cls,
        "comm": comm,
        "cmdline": cmdline,
        "jobs_n": jobs_n,
        "t_start": time.time(),
        "uj_start": uj_start,
        "max_range": max_r,
        "injected": injected_lever,
        "approved": approved,
    }


def _handle_exit_event(pid: int, active_jobs: Dict[int, Any], cfg: Dict[str, Any]):
    if pid not in active_jobs:
        return

    info = active_jobs.pop(pid)
    cls = info["class"]
    comm = info.get("comm", "")
    jobs_n = info.get("jobs_n")
    t_start = info["t_start"]
    t_stop = time.time()
    uj_start = info["uj_start"]
    max_r = info["max_range"]
    injected = info.get("injected")
    approved = info.get("approved", False)

    t_elapsed = round(max(0.001, t_stop - t_start), 3)

    energy_j = 0.0
    if uj_start is not None:
        uj_stop, _ = read_package_rapl_energy()
        if uj_stop is not None:
            energy_j = compute_counter_delta_j(uj_start, uj_stop, max_r)

    is_experiment = is_coverage_experiment_enabled(cls, cfg)
    slot_info = next_slot(cls, t_elapsed, experiment=is_experiment)

    if cls in ("idle", "heartbeat"):
        policy = {"applied": False}
    elif not approved:
        policy = {"applied": False}
    elif cls == "compile":
        if comm in ("make", "gmake", "ninja") or injected == "occupancy":
            if jobs_n == 1:
                policy = {"applied": False}  # -j1 serial: never occupancy
            elif injected == "occupancy":
                policy = {"applied": True, "lever": "occupancy"}
            else:
                policy = {"applied": False}
        else:
            # Compiler drivers (gcc, clang, cc1, etc.): meter only, no occupancy, no materialize
            policy = {"applied": False}
    elif cls in RECIPE_LEVERS and injected == RECIPE_LEVERS[cls]:
        policy = {"applied": True, "lever": injected}
    else:
        policy = {"applied": False}

    if slot_info is not None:
        if slot_info.get("unwrap"):
            policy["applied"] = False
            policy["slot"] = "unwrap"
        else:
            policy["slot"] = slot_info["slot"]

    jobs_file = cfg.get("jobs_file", DEFAULT_JOBS_FILE)
    record_attach_job(
        job_class=cls,
        pid=pid,
        t_start=t_start,
        t_stop=t_stop,
        energy_j=energy_j,
        policy=policy,
        jobs_file=jobs_file,
    )


def run_netlink_watch(s: socket.socket, cfg: Dict[str, Any]):
    global _NETLINK_ACTIVE
    _NETLINK_ACTIVE = True
    active_jobs: Dict[int, Any] = {}
    s.settimeout(1.0)

    while True:
        try:
            data = s.recv(1024)
            if len(data) >= 56:
                what, cpu, ts = struct.unpack_from("=IIQ", data, 36)
                if what == 2:  # PROC_EVENT_EXEC
                    pid, tgid = struct.unpack_from("=ii", data, 52)
                    _handle_exec_event(pid, active_jobs, cfg)
                elif what == 0x80000000:  # PROC_EVENT_EXIT
                    pid, tgid, exit_code, exit_signal = struct.unpack_from("=iiII", data, 52)
                    _handle_exit_event(pid, active_jobs, cfg)
        except socket.timeout:
            dead_pids = [p for p in active_jobs if not os.path.exists(f"/proc/{p}")]
            for dp in dead_pids:
                _handle_exit_event(dp, active_jobs, cfg)
        except Exception:
            break

    _NETLINK_ACTIVE = False


def run_proc_poll_watch(cfg: Dict[str, Any]):
    poll_sec = float(cfg.get("attach_poll_sec", DEFAULT_ATTACH_POLL_SEC))
    active_jobs: Dict[int, Any] = {}
    seen_pids = set()

    while True:
        try:
            current_pids = set()
            try:
                for entry in os.listdir("/proc"):
                    if entry.isdigit():
                        current_pids.add(int(entry))
            except Exception:
                pass

            new_pids = current_pids - seen_pids
            for np in new_pids:
                _handle_exec_event(np, active_jobs, cfg)

            dead_jobs = [p for p in active_jobs if p not in current_pids]
            for dp in dead_jobs:
                _handle_exit_event(dp, active_jobs, cfg)

            seen_pids = current_pids
        except Exception:
            pass
        time.sleep(poll_sec)


def start_background_watch(cfg: Dict[str, Any]) -> threading.Thread:
    """Spawns the background attach watch thread (daemon=True)."""
    global _WATCH_THREAD

    def loop():
        time.sleep(1.0)
        s = try_create_netlink_socket()
        if s:
            try:
                run_netlink_watch(s, cfg)
            except Exception:
                pass
        run_proc_poll_watch(cfg)

    t = threading.Thread(target=loop, name="neutrino-attach-watch", daemon=True)
    t.start()
    _WATCH_THREAD = t
    return t

get_attach_status = get_watch_status
