"""neutrino/attach/classify.py - Process classification for daemon attach."""
import os
from typing import Optional, List, Dict, Any
from neutrino.attach.refuse import REFUSE_COMM

COMPILE_COMMS = frozenset({
    "make", "gmake", "ninja", "gcc", "g++", "cc", "c++",
    "clang", "clang++", "cc1", "cc1plus", "rustc", "javac",
})

RENDER_COMMS = frozenset({
    "blender", "ffmpeg", "povray", "magick", "convert",
})

OLTP_COMMS = frozenset({
    "sqlite", "sqlite3", "psql", "mysql", "mariadb", "redis-cli", "neutrino-oltp-load", "neutrino-oltp-l",
})

MQ_COMMS = frozenset({
    "kafka", "kafka-server-start", "mosquitto", "rabbitmq-server", "neutrino-mq-append", "neutrino-mq-ap",
})

HPC_COMMS = frozenset({
    "srun", "neutrino-srun", "mpirun", "mpiexec",
})

BATCH_COMMS = frozenset({
    "spark-submit", "pigz", "gzip", "bzip2", "xz",
})

ETL_COMMS = frozenset({
    "neutrino-etl", "etl",
})

IDLE_COMMS = frozenset({
    "sleep", "true",
})


def classify_process(
    comm: str,
    cmdline: Optional[List[str]] = None,
    environ: Optional[Dict[str, str]] = None,
    exe: Optional[str] = None,
) -> Optional[str]:
    """Classifies a process into an eligible class slug or None.

    Rules:
    - Never classify generic python as infer-cpu (infer-cpu ONLY on explicit markers).
    - Exclude refusal list.
    - HPC scheduler steps via env or comm.
    """
    comm_clean = os.path.basename(comm or "").strip().lower()
    if not comm_clean and exe:
        comm_clean = os.path.basename(exe).strip().lower()

    if comm_clean in REFUSE_COMM:
        return None

    # Environment heuristics (HPC scheduler steps)
    if environ:
        if "SLURM_JOB_ID" in environ or "LSB_JOBID" in environ:
            return "hpc"
        attach_cls = environ.get("NEUTRINO_ATTACH_CLASS")
        if attach_cls in ("compile", "render", "hpc", "batch", "oltp", "mq", "etl", "infer-cpu"):
            return attach_cls

    # Idle / Heartbeat
    if comm_clean in IDLE_COMMS:
        return "idle"
    if comm_clean == "heartbeat":
        return "heartbeat"

    # Product tool cmdline matching
    if cmdline:
        joined_cmd = " ".join(cmdline).lower()
        if "neutrino-oltp-load" in joined_cmd:
            return "oltp"
        if "neutrino-mq-append" in joined_cmd:
            return "mq"
        if "neutrino-etl" in joined_cmd:
            return "etl"

    # Exact comm matching
    if comm_clean in COMPILE_COMMS:
        return "compile"
    if comm_clean in RENDER_COMMS:
        return "render"
    if comm_clean in OLTP_COMMS:
        return "oltp"
    if comm_clean in MQ_COMMS:
        return "mq"
    if comm_clean in HPC_COMMS:
        return "hpc"
    if comm_clean in BATCH_COMMS:
        return "batch"
    if comm_clean in ETL_COMMS:
        return "etl"

    # Explicit infer-cpu markers ONLY (never generic python)
    joined_cmd = " ".join(cmdline or []).lower()
    if any(marker in joined_cmd for marker in ("infer-cpu", "infer_bench", "neutrino-infer")):
        return "infer-cpu"

    return None
