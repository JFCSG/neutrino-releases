"""
proxy_rewrite.py - Attach layer HTTP request rewriter and agent telemetry integration.
Coordinates agent wire classification, prefix linter, and dialect-specific cache injection.
Standard library only. Zero host literals. Zero external dependencies.
"""

import hashlib
from typing import Any, Dict, Optional, Tuple, Set

from neutrino.levers.agent_shape import classify_agent_request
from neutrino.levers.prefix_lint import lint_prefix
from neutrino.levers.dialect import rewrite_agent_dialect


def rewrite_attach_inference_request(
    body: Dict[str, Any],
    child_class: str,
    is_holdout: bool,
    dialect: str = "llama-server",
    session_key: Optional[str] = None,
    prompt_tokens: Optional[int] = None,
    completion_tokens: Optional[int] = None,
    prefix_hash: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Entrypoint for attach proxy HTTP request rewriting.
    Applies agent shape detection, prefix linter, and dialect cache injection.
    """
    telemetry: Dict[str, Any] = {
        "child_class": child_class,
        "holdout": is_holdout,
        "session_key": session_key,
        "prefix_hash": prefix_hash,
    }

    # 1. Prefix lint (observe-only)
    prefix_break_reason, tools_hash = lint_prefix(body, session_key=session_key)
    telemetry["prefix_break_reason"] = prefix_break_reason
    telemetry["tools_hash"] = tools_hash

    # 2. Dialect rewrite
    outbound_body, dialect_telem = rewrite_agent_dialect(
        body=body,
        dialect=dialect,
        session_key=session_key,
        is_holdout=is_holdout,
    )

    telemetry.update(dialect_telem)
    return outbound_body, telemetry
