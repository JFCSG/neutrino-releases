"""neutrino/attach/jobs.py - Attach job recording, honest slots, and durability."""
import json
import os
import secrets
import time
from typing import Dict, Any, Tuple, Optional

from neutrino.config import DEFAULT_JOBS_FILE, ATTACH_COVERAGE_FILE


def get_coverage_state(state_file: str = ATTACH_COVERAGE_FILE) -> Dict[str, Any]:
    """Loads current coverage slot state per class from JSON."""
    if os.path.isfile(state_file):
        try:
            with open(state_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
    return {}


def save_coverage_state(state: Dict[str, Any], state_file: str = ATTACH_COVERAGE_FILE):
    """Atomically saves coverage state (mode 0640)."""
    parent = os.path.dirname(state_file)
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp_file = f"{state_file}.tmp.{secrets.token_hex(4)}"
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp_file, 0o640)
    try:
        import grp
        gid = grp.getgrnam("neutrino").gr_gid
        if os.geteuid() == 0:
            os.chown(tmp_file, 0, gid)
    except Exception:
        pass
    os.replace(tmp_file, state_file)


def is_coverage_experiment_enabled(cls: str, cfg: Optional[Dict[str, Any]] = None) -> bool:
    """Checks whether coverage_experiment is opted into in apply.d/<cls>.conf."""
    cfg = cfg or {}
    apply_dir = cfg.get("apply_dir", "/etc/neutrino/apply.d")
    conf_path = os.path.join(apply_dir, f"{cls}.conf")
    if not os.path.isfile(conf_path):
        return False
    try:
        with open(conf_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("#"):
                    continue
                if "coverage_experiment" in line:
                    k, v = line.split("=", 1)
                    if k.strip() == "coverage_experiment" and v.strip().lower() in ("true", "1", "yes"):
                        return True
    except Exception:
        pass
    return False


def increment_slot(class_name: str, state_file: str = ATTACH_COVERAGE_FILE) -> int:
    """Increments and persists slot counter 1..N forever."""
    state = get_coverage_state(state_file)
    cls_data = state.get(class_name, {})
    curr_slot = int(cls_data.get("slot", 0))
    next_s = curr_slot + 1
    cls_data["slot"] = next_s
    cls_data["total_jobs"] = int(cls_data.get("total_jobs", 0)) + 1
    state[class_name] = cls_data

    try:
        save_coverage_state(state, state_file)
    except Exception:
        pass
    return next_s


def next_slot(
    cls: str,
    t_elapsed_s: float,
    experiment: bool = False,
    state_file: str = ATTACH_COVERAGE_FILE,
) -> Optional[Dict[str, Any]]:
    """Advances slot accounting if t >= 1.0s.

    CRITICAL: slot != policy.applied.
    next_slot MUST NOT set applied=True.
    Unwrap occurs ONLY when experiment=True and slot % 20 == 0.
    """
    if t_elapsed_s < 1.0:
        return None  # metered, no slot increment

    slot = increment_slot(cls, state_file=state_file)
    if experiment and slot % 20 == 0:
        return {"slot": slot, "unwrap": True}
    return {"slot": slot, "unwrap": False}


def advance_coverage_slot(
    class_name: str,
    state_file: str = ATTACH_COVERAGE_FILE,
    experiment: bool = False,
) -> Tuple[bool, int]:
    """Advances 19+1 coverage slot for class_name (1..20 wrapping for legacy tests)."""
    state = get_coverage_state(state_file)
    cls_data = state.get(class_name, {})
    curr_slot = int(cls_data.get("slot", 0))
    next_s = curr_slot + 1
    if next_s > 20:
        next_s = 1

    is_wrap = (next_s != 20) if experiment else True
    cls_data["slot"] = next_s
    cls_data["total_jobs"] = int(cls_data.get("total_jobs", 0)) + 1
    state[class_name] = cls_data

    try:
        save_coverage_state(state, state_file)
    except Exception:
        pass

    return is_wrap, next_s


def get_coverage_slot(class_name: str, state_file: str = ATTACH_COVERAGE_FILE) -> Tuple[bool, int]:
    """Reads whether the next slot would be wrap without advancing."""
    state = get_coverage_state(state_file)
    cls_data = state.get(class_name, {})
    curr_slot = int(cls_data.get("slot", 0))
    next_s = curr_slot + 1
    is_wrap = (next_s % 20 != 0)
    return is_wrap, next_s


def record_attach_job(
    job_class: str,
    pid: int,
    t_start: float,
    t_stop: float,
    energy_j: float,
    policy: Optional[Dict[str, Any]] = None,
    jobs_file: str = DEFAULT_JOBS_FILE,
    host_fingerprint: Optional[str] = None,
) -> Dict[str, Any]:
    """Appends an attach job record to jobs.jsonl.

    n_samples=1 represents a single counter delta pair (uj_stop - uj_start),
    not a continuous polling sample count.
    """
    parent = os.path.dirname(jobs_file)
    if parent:
        os.makedirs(parent, exist_ok=True)

    t_elapsed = round(max(0.001, t_stop - t_start), 3)
    primary_energy = round(energy_j, 3)
    p_mean = round(primary_energy / t_elapsed, 3) if t_elapsed > 0 else 0.0

    job_id = f"att-{int(t_start)}-{pid}"
    rec = {
        "id": job_id,
        "class": job_class,
        "rail": "rapl-pkg",
        "t_start": round(t_start, 3),
        "t_stop": round(t_stop, 3),
        "t_elapsed_s": t_elapsed,
        "energy_j": primary_energy,
        "energy_pkg_j": primary_energy,
        "energy_dram_j": None,
        "energy_gpu_j": None,
        "p_mean_w": p_mean,
        "n_samples": 1,
        "method": "uj_delta",
        "attach": True,
        "policy": policy or {"applied": False},
        "execution": None,
        "host_fingerprint": host_fingerprint,
        "scheduler": None,
        "sched_job_id": None,
        "cpus": None,
        "energy_per_core_hour_j": None,
        "unit_name": None,
        "unit_count": None,
        "energy_per_unit_j": None,
    }

    line = json.dumps(rec, separators=(",", ":")) + chr(10)
    with open(jobs_file, "a", encoding="utf-8") as f:
        f.write(line)
        f.flush()

    return rec
