"""neutrino/attach/shims.py - Make/Ninja/Batch/OLTP/MQ/ETL shims."""
import os
import shutil
import sys
from typing import List, Optional

from neutrino.config import ATTACH_BIN_DIR, ATTACH_PROFILE_D

COMPILE_TARGETS = ("make", "gmake", "ninja")
COMPILER_TARGETS = ("gcc", "g++")
PYTHON_TARGETS = ("python3",)
GO_TARGETS = ("go",)
CARGO_TARGETS = ("cargo",)
GRADLE_TARGETS = ("gradle",)
BATCH_TARGETS = ("gzip", "xz", "bzip2")
OLTP_TARGETS = ("sqlite3",)

MAKE_SHIM_TEMPLATE = '''#!/usr/bin/env python3
"""Neutrino attach shim for {bin_name}."""
import os
import sys

def _parse_jobs(argv):
    for i, a in enumerate(argv):
        if a in ("-j", "--jobs"):
            if i + 1 < len(argv) and argv[i+1].isdigit():
                return int(argv[i+1])
            return 999
        if a.startswith("-j") and a[2:].isdigit():
            return int(a[2:])
        if a.startswith("--jobs="):
            try:
                return int(a.split("=", 1)[1])
            except ValueError:
                return None
    return None

def main():
    bin_name = "{bin_name}"
    own_dir = os.path.dirname(os.path.abspath(__file__))
    own_real = os.path.realpath(own_dir)

    real_bin = None
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    for p in path_dirs:
        if not p:
            continue
        try:
            if os.path.realpath(p) == own_real:
                continue
            cand = os.path.join(p, bin_name)
            if os.path.isfile(cand) and os.access(cand, os.X_OK):
                if os.path.realpath(cand) != os.path.realpath(__file__):
                    real_bin = cand
                    break
        except Exception:
            continue

    if not real_bin:
        for fallback in ("/usr/bin", "/bin"):
            if os.path.realpath(fallback) != own_real:
                cand = os.path.join(fallback, bin_name)
                if os.path.isfile(cand) and os.access(cand, os.X_OK):
                    real_bin = cand
                    break

    if not real_bin:
        sys.stderr.write(f"neutrino-attach: error: could not locate real {bin_name}\\n")
        sys.exit(127)

    os.environ["NEUTRINO_ATTACH_CLASS"] = "compile"

    jobs_n = _parse_jobs(sys.argv[1:])
    if jobs_n is not None:
        if jobs_n >= 2:
            os.environ["NEUTRINO_ATTACH_INJECT"] = "occupancy"
        else:
            os.environ.pop("NEUTRINO_ATTACH_INJECT", None)
        new_argv = [real_bin] + sys.argv[1:]
    else:
        nproc = os.cpu_count() or 1
        new_argv = [real_bin, f"-j{nproc}"] + sys.argv[1:]
        os.environ["NEUTRINO_ATTACH_INJECT"] = "occupancy"

    try:
        os.execv(real_bin, new_argv)
    except OSError as e:
        sys.stderr.write(f"neutrino-attach: execv failed: {e}\\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''

GCC_SHIM_TEMPLATE = '''#!/bin/sh
# Neutrino attach shim for {bin_name}
_check_cache_allowed() {
    [ -f "${NEUTRINO_APPLY_DIR:-/etc/neutrino/apply.d}/autopilot.enabled" ] || return 1
    if [ -f "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" ]; then
        if grep -Eq '"autopilot"[[:space:]]*:[[:space:]]*"off"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
        if grep -Eq '"compile"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
    fi
    /usr/bin/python3 -c 'import sys; sys.path.append("/usr/local/lib/neutrino"); from neutrino.apply.autopilot import licensed_and_armed; sys.exit(0 if licensed_and_armed() else 1)' 2>/dev/null || return 1
    return 0
}
if _check_cache_allowed; then
    if [ -x "/opt/neutrino/libexec/ccache/{bin_name}" ]; then
        exec "/opt/neutrino/libexec/ccache/{bin_name}" "$@"
    fi
fi
exec /usr/bin/{bin_name} "$@"
'''

PYTHON_SHIM_TEMPLATE = '''#!/bin/sh
# Neutrino attach shim for {bin_name}
_check_cache_allowed() {
    [ -f "${NEUTRINO_APPLY_DIR:-/etc/neutrino/apply.d}/autopilot.enabled" ] || return 1
    if [ -f "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" ]; then
        if grep -Eq '"autopilot"[[:space:]]*:[[:space:]]*"off"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
        if grep -Eq '"compile"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
    fi
    /usr/bin/python3 -c 'import sys; sys.path.append("/usr/local/lib/neutrino"); from neutrino.apply.autopilot import licensed_and_armed; sys.exit(0 if licensed_and_armed() else 1)' 2>/dev/null || return 1
    return 0
}
if _check_cache_allowed; then
    if [ -z "${PYTHONPYCACHEPREFIX:-}" ]; then
        export PYTHONPYCACHEPREFIX="/var/tmp/neutrino-pyc"
    fi
fi
exec /usr/bin/{bin_name} "$@"
'''

GO_SHIM_TEMPLATE = '''#!/bin/sh
# Neutrino attach shim for {bin_name}
_check_cache_allowed() {
    [ -f "${NEUTRINO_APPLY_DIR:-/etc/neutrino/apply.d}/autopilot.enabled" ] || return 1
    if [ -f "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" ]; then
        if grep -Eq '"autopilot"[[:space:]]*:[[:space:]]*"off"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
        if grep -Eq '"compile"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
    fi
    /usr/bin/python3 -c 'import sys; sys.path.append("/usr/local/lib/neutrino"); from neutrino.apply.autopilot import licensed_and_armed; sys.exit(0 if licensed_and_armed() else 1)' 2>/dev/null || return 1
    return 0
}
if _check_cache_allowed; then
    if [ -z "${GOCACHE:-}" ]; then
        export GOCACHE="/var/tmp/neutrino-gocache"
    fi
fi
exec /usr/bin/{bin_name} "$@"
'''

CARGO_SHIM_TEMPLATE = '''#!/bin/sh
# Neutrino attach shim for {bin_name}
_check_cache_allowed() {
    [ -f "${NEUTRINO_APPLY_DIR:-/etc/neutrino/apply.d}/autopilot.enabled" ] || return 1
    if [ -f "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" ]; then
        if grep -Eq '"autopilot"[[:space:]]*:[[:space:]]*"off"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
        if grep -Eq '"compile"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
    fi
    /usr/bin/python3 -c 'import sys; sys.path.append("/usr/local/lib/neutrino"); from neutrino.apply.autopilot import licensed_and_armed; sys.exit(0 if licensed_and_armed() else 1)' 2>/dev/null || return 1
    return 0
}
if _check_cache_allowed; then
    if [ -z "${CARGO_TARGET_DIR:-}" ]; then
        export CARGO_TARGET_DIR="/var/tmp/neutrino-rust-target"
    fi
fi
exec /usr/bin/{bin_name} "$@"
'''

GRADLE_SHIM_TEMPLATE = '''#!/bin/sh
# Neutrino attach shim for {bin_name}
_check_cache_allowed() {
    [ -f "${NEUTRINO_APPLY_DIR:-/etc/neutrino/apply.d}/autopilot.enabled" ] || return 1
    if [ -f "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" ]; then
        if grep -Eq '"autopilot"[[:space:]]*:[[:space:]]*"off"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
        if grep -Eq '"compile"' "${NEUTRINO_REVOKED_FILE:-/var/lib/neutrino/apply/revoked.json}" 2>/dev/null; then
            return 1
        fi
    fi
    /usr/bin/python3 -c 'import sys; sys.path.append("/usr/local/lib/neutrino"); from neutrino.apply.autopilot import licensed_and_armed; sys.exit(0 if licensed_and_armed() else 1)' 2>/dev/null || return 1
    return 0
}
if _check_cache_allowed; then
    if [ -z "${GRADLE_USER_HOME:-}" ]; then
        export GRADLE_USER_HOME="/var/tmp/neutrino-gradle"
    fi
fi
exec /usr/bin/{bin_name} "$@"
'''

GZIP_SHIM_TEMPLATE = '''#!/usr/bin/env python3
"""Neutrino attach shim for gzip."""
import os
import shutil
import sys

def main():
    bin_name = "gzip"
    own_dir = os.path.dirname(os.path.abspath(__file__))
    own_real = os.path.realpath(own_dir)

    real_bin = None
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    for p in path_dirs:
        if not p:
            continue
        try:
            if os.path.realpath(p) == own_real:
                continue
            cand = os.path.join(p, bin_name)
            if os.path.isfile(cand) and os.access(cand, os.X_OK):
                if os.path.realpath(cand) != os.path.realpath(__file__):
                    real_bin = cand
                    break
        except Exception:
            continue

    if not real_bin:
        for fallback in ("/usr/bin", "/bin"):
            if os.path.realpath(fallback) != own_real:
                cand = os.path.join(fallback, bin_name)
                if os.path.isfile(cand) and os.access(cand, os.X_OK):
                    real_bin = cand
                    break

    if not real_bin:
        sys.stderr.write("neutrino-attach: error: could not locate real gzip\\n")
        sys.exit(127)

    os.environ["NEUTRINO_ATTACH_CLASS"] = "batch"

    apply_dir = os.environ.get("NEUTRINO_APPLY_DIR", "/etc/neutrino/apply.d")
    approved = os.path.isfile(os.path.join(apply_dir, "batch.enabled"))
    baseline = (os.environ.get("NEUTRINO_LEVER_OFF") == "1")
    pigz = shutil.which("pigz")

    if pigz and approved and not baseline:
        nproc = os.cpu_count() or 1
        os.environ["NEUTRINO_ATTACH_INJECT"] = "occupancy"
        new_argv = [pigz, "-p", str(nproc)] + sys.argv[1:]
        try:
            os.execv(pigz, new_argv)
        except OSError as e:
            sys.stderr.write(f"neutrino-attach: execv pigz failed: {e}\\n")
            sys.exit(1)

    os.environ.pop("NEUTRINO_ATTACH_INJECT", None)
    new_argv = [real_bin] + sys.argv[1:]
    try:
        os.execv(real_bin, new_argv)
    except OSError as e:
        sys.stderr.write(f"neutrino-attach: execv gzip failed: {e}\\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''

XZ_SHIM_TEMPLATE = '''#!/usr/bin/env python3
"""Neutrino attach shim for xz."""
import os
import sys

def main():
    bin_name = "xz"
    own_dir = os.path.dirname(os.path.abspath(__file__))
    own_real = os.path.realpath(own_dir)

    real_bin = None
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    for p in path_dirs:
        if not p:
            continue
        try:
            if os.path.realpath(p) == own_real:
                continue
            cand = os.path.join(p, bin_name)
            if os.path.isfile(cand) and os.access(cand, os.X_OK):
                if os.path.realpath(cand) != os.path.realpath(__file__):
                    real_bin = cand
                    break
        except Exception:
            continue

    if not real_bin:
        for fallback in ("/usr/bin", "/bin"):
            if os.path.realpath(fallback) != own_real:
                cand = os.path.join(fallback, bin_name)
                if os.path.isfile(cand) and os.access(cand, os.X_OK):
                    real_bin = cand
                    break

    if not real_bin:
        sys.stderr.write("neutrino-attach: error: could not locate real xz\\n")
        sys.exit(127)

    os.environ["NEUTRINO_ATTACH_CLASS"] = "batch"

    apply_dir = os.environ.get("NEUTRINO_APPLY_DIR", "/etc/neutrino/apply.d")
    approved = os.path.isfile(os.path.join(apply_dir, "batch.enabled"))
    baseline = (os.environ.get("NEUTRINO_LEVER_OFF") == "1")

    args = list(sys.argv[1:])
    if approved and not baseline:
        has_t = any(a.startswith("-T") or a == "--threads" or a.startswith("--threads=") for a in args)
        if not has_t:
            args = ["-T0"] + args
            os.environ["NEUTRINO_ATTACH_INJECT"] = "occupancy"
    else:
        os.environ.pop("NEUTRINO_ATTACH_INJECT", None)

    new_argv = [real_bin] + args
    try:
        os.execv(real_bin, new_argv)
    except OSError as e:
        sys.stderr.write(f"neutrino-attach: execv xz failed: {e}\\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''

BZIP2_SHIM_TEMPLATE = '''#!/usr/bin/env python3
"""Neutrino attach shim for bzip2."""
import os
import shutil
import sys

def main():
    bin_name = "bzip2"
    own_dir = os.path.dirname(os.path.abspath(__file__))
    own_real = os.path.realpath(own_dir)

    real_bin = None
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    for p in path_dirs:
        if not p:
            continue
        try:
            if os.path.realpath(p) == own_real:
                continue
            cand = os.path.join(p, bin_name)
            if os.path.isfile(cand) and os.access(cand, os.X_OK):
                if os.path.realpath(cand) != os.path.realpath(__file__):
                    real_bin = cand
                    break
        except Exception:
            continue

    if not real_bin:
        for fallback in ("/usr/bin", "/bin"):
            if os.path.realpath(fallback) != own_real:
                cand = os.path.join(fallback, bin_name)
                if os.path.isfile(cand) and os.access(cand, os.X_OK):
                    real_bin = cand
                    break

    if not real_bin:
        sys.stderr.write("neutrino-attach: error: could not locate real bzip2\\n")
        sys.exit(127)

    os.environ["NEUTRINO_ATTACH_CLASS"] = "batch"

    apply_dir = os.environ.get("NEUTRINO_APPLY_DIR", "/etc/neutrino/apply.d")
    approved = os.path.isfile(os.path.join(apply_dir, "batch.enabled"))
    baseline = (os.environ.get("NEUTRINO_LEVER_OFF") == "1")
    lbzip2 = shutil.which("lbzip2")

    if lbzip2 and approved and not baseline:
        os.environ["NEUTRINO_ATTACH_INJECT"] = "occupancy"
        new_argv = [lbzip2] + sys.argv[1:]
        try:
            os.execv(lbzip2, new_argv)
        except OSError as e:
            sys.stderr.write(f"neutrino-attach: execv lbzip2 failed: {e}\\n")
            sys.exit(1)

    os.environ.pop("NEUTRINO_ATTACH_INJECT", None)
    new_argv = [real_bin] + sys.argv[1:]
    try:
        os.execv(real_bin, new_argv)
    except OSError as e:
        sys.stderr.write(f"neutrino-attach: execv bzip2 failed: {e}\\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''

SQLITE3_SHIM_TEMPLATE = '''#!/usr/bin/env python3
"""Neutrino attach shim for sqlite3."""
import os
import sys

def main():
    bin_name = "sqlite3"
    own_dir = os.path.dirname(os.path.abspath(__file__))
    own_real = os.path.realpath(own_dir)

    real_bin = None
    path_dirs = os.environ.get("PATH", "").split(os.pathsep)
    for p in path_dirs:
        if not p:
            continue
        try:
            if os.path.realpath(p) == own_real:
                continue
            cand = os.path.join(p, bin_name)
            if os.path.isfile(cand) and os.access(cand, os.X_OK):
                if os.path.realpath(cand) != os.path.realpath(__file__):
                    real_bin = cand
                    break
        except Exception:
            continue

    if not real_bin:
        for fallback in ("/usr/bin", "/bin"):
            if os.path.realpath(fallback) != own_real:
                cand = os.path.join(fallback, bin_name)
                if os.path.isfile(cand) and os.access(cand, os.X_OK):
                    real_bin = cand
                    break

    if not real_bin:
        sys.stderr.write("neutrino-attach: error: could not locate real sqlite3\\n")
        sys.exit(127)

    os.environ["NEUTRINO_ATTACH_CLASS"] = "oltp"
    os.environ.pop("NEUTRINO_ATTACH_INJECT", None)

    # NEVER REWRITE SQL. Pass argv directly to real sqlite3.
    new_argv = [real_bin] + sys.argv[1:]
    try:
        os.execv(real_bin, new_argv)
    except OSError as e:
        sys.stderr.write(f"neutrino-attach: execv sqlite3 failed: {e}\\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''

TOOL_WRAPPER_TEMPLATE = '''#!/usr/bin/env bash
# Neutrino attach shim for {bin_name}
apply_dir="${NEUTRINO_APPLY_DIR:-/etc/neutrino/apply.d}"
is_baseline=0
for arg in "$@"; do
    if [ "$arg" = "--baseline" ]; then
        is_baseline=1
        break
    fi
done
if [ "$NEUTRINO_LEVER_OFF" = "1" ]; then
    is_baseline=1
fi

case "{bin_name}" in
    neutrino-oltp-load)
        if [ -f "$apply_dir/oltp.enabled" ] && [ "$is_baseline" -eq 0 ]; then
            export NEUTRINO_ATTACH_INJECT="group-commit"
            export NEUTRINO_ATTACH_CLASS="oltp"
        else
            unset NEUTRINO_ATTACH_INJECT
        fi
        ;;
    neutrino-mq-append)
        if [ -f "$apply_dir/mq.enabled" ] && [ "$is_baseline" -eq 0 ]; then
            export NEUTRINO_ATTACH_INJECT="batch_fsync"
            export NEUTRINO_ATTACH_CLASS="mq"
        else
            unset NEUTRINO_ATTACH_INJECT
        fi
        ;;
    neutrino-etl)
        if [ -f "$apply_dir/etl.enabled" ] && [ "$is_baseline" -eq 0 ]; then
            export NEUTRINO_ATTACH_INJECT="residency"
            export NEUTRINO_ATTACH_CLASS="etl"
        else
            unset NEUTRINO_ATTACH_INJECT
        fi
        ;;
esac

if [ -x "/usr/local/bin/{bin_name}" ]; then
    exec "/usr/local/bin/{bin_name}" "$@"
fi
exec "{bin_name}" "$@"
'''

PROFILE_D_CONTENT = f"""# Neutrino Autopilot attach PATH
export PATH={ATTACH_BIN_DIR}:$PATH
"""


def get_shim_paths(
    feature_class: str,
    bin_dir: str = ATTACH_BIN_DIR,
    profile_d_path: str = ATTACH_PROFILE_D,
) -> List[str]:
    """Returns the explicit file paths managed for feature_class shims."""
    if feature_class == "compile":
        paths = [os.path.join(bin_dir, name) for name in COMPILE_TARGETS]
        paths.extend([os.path.join(bin_dir, name) for name in COMPILER_TARGETS])
        paths.extend([os.path.join(bin_dir, name) for name in PYTHON_TARGETS])
        paths.extend([os.path.join(bin_dir, name) for name in GO_TARGETS])
        paths.extend([os.path.join(bin_dir, name) for name in CARGO_TARGETS])
        paths.extend([os.path.join(bin_dir, name) for name in GRADLE_TARGETS])
        paths.append(profile_d_path)
        return paths
    elif feature_class == "batch":
        return [os.path.join(bin_dir, name) for name in BATCH_TARGETS]
    elif feature_class == "oltp":
        return [
            os.path.join(bin_dir, "sqlite3"),
            os.path.join(bin_dir, "neutrino-oltp-load"),
        ]
    elif feature_class == "mq":
        return [os.path.join(bin_dir, "neutrino-mq-append")]
    elif feature_class == "etl":
        return [os.path.join(bin_dir, "neutrino-etl")]
    return []


def install_shims(
    classes: Optional[List[str]] = None,
    bin_dir: str = ATTACH_BIN_DIR,
    profile_d_path: str = ATTACH_PROFILE_D,
    local_bin_dir: str = "/usr/local/bin",
) -> List[str]:
    """Installs shims, profile.d, and tools for approved classes."""
    installed = []
    classes = classes or ["compile"]
    os.makedirs(bin_dir, exist_ok=True)

    if "compile" in classes:
        for name in COMPILE_TARGETS:
            target = os.path.join(bin_dir, name)
            content = MAKE_SHIM_TEMPLATE.replace("{bin_name}", name)
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(target, 0o755)
            installed.append(target)

        for name in COMPILER_TARGETS:
            target = os.path.join(bin_dir, name)
            content = GCC_SHIM_TEMPLATE.replace("{bin_name}", name)
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(target, 0o755)
            installed.append(target)

        for name in PYTHON_TARGETS:
            target = os.path.join(bin_dir, name)
            content = PYTHON_SHIM_TEMPLATE.replace("{bin_name}", name)
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(target, 0o755)
            installed.append(target)

        for name in GO_TARGETS:
            target = os.path.join(bin_dir, name)
            content = GO_SHIM_TEMPLATE.replace("{bin_name}", name)
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(target, 0o755)
            installed.append(target)

        for name in CARGO_TARGETS:
            target = os.path.join(bin_dir, name)
            content = CARGO_SHIM_TEMPLATE.replace("{bin_name}", name)
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(target, 0o755)
            installed.append(target)

        for name in GRADLE_TARGETS:
            target = os.path.join(bin_dir, name)
            content = GRADLE_SHIM_TEMPLATE.replace("{bin_name}", name)
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(target, 0o755)
            installed.append(target)

        # /etc/profile.d/neutrino-attach.sh
        p_parent = os.path.dirname(profile_d_path)
        if p_parent:
            try:
                os.makedirs(p_parent, exist_ok=True)
                with open(profile_d_path, "w", encoding="utf-8") as f:
                    f.write(PROFILE_D_CONTENT)
                os.chmod(profile_d_path, 0o644)
                installed.append(profile_d_path)
            except (PermissionError, OSError):
                pass

        # /usr/local/bin/make: install only if absent or already our shim
        local_make = os.path.join(local_bin_dir, "make")
        try:
            should_install = False
            if not os.path.exists(local_make):
                should_install = True
            else:
                try:
                    with open(local_make, "r", encoding="utf-8", errors="ignore") as f:
                        if "Neutrino attach shim for make" in f.read(200):
                            should_install = True
                except Exception:
                    pass

            if should_install:
                os.makedirs(local_bin_dir, exist_ok=True)
                content = MAKE_SHIM_TEMPLATE.replace("{bin_name}", "make")
                with open(local_make, "w", encoding="utf-8") as f:
                    f.write(content)
                os.chmod(local_make, 0o755)
                installed.append(local_make)
        except (PermissionError, OSError):
            pass

    if "batch" in classes:
        # gzip
        target_gzip = os.path.join(bin_dir, "gzip")
        with open(target_gzip, "w", encoding="utf-8") as f:
            f.write(GZIP_SHIM_TEMPLATE)
        os.chmod(target_gzip, 0o755)
        installed.append(target_gzip)

        # xz
        target_xz = os.path.join(bin_dir, "xz")
        with open(target_xz, "w", encoding="utf-8") as f:
            f.write(XZ_SHIM_TEMPLATE)
        os.chmod(target_xz, 0o755)
        installed.append(target_xz)

        # bzip2
        target_bzip2 = os.path.join(bin_dir, "bzip2")
        with open(target_bzip2, "w", encoding="utf-8") as f:
            f.write(BZIP2_SHIM_TEMPLATE)
        os.chmod(target_bzip2, 0o755)
        installed.append(target_bzip2)

    if "oltp" in classes:
        # sqlite3
        target_sqlite3 = os.path.join(bin_dir, "sqlite3")
        with open(target_sqlite3, "w", encoding="utf-8") as f:
            f.write(SQLITE3_SHIM_TEMPLATE)
        os.chmod(target_sqlite3, 0o755)
        installed.append(target_sqlite3)

        # neutrino-oltp-load
        target_oltp = os.path.join(bin_dir, "neutrino-oltp-load")
        with open(target_oltp, "w", encoding="utf-8") as f:
            f.write(TOOL_WRAPPER_TEMPLATE.replace("{bin_name}", "neutrino-oltp-load"))
        os.chmod(target_oltp, 0o755)
        installed.append(target_oltp)

    if "mq" in classes:
        target_mq = os.path.join(bin_dir, "neutrino-mq-append")
        with open(target_mq, "w", encoding="utf-8") as f:
            f.write(TOOL_WRAPPER_TEMPLATE.replace("{bin_name}", "neutrino-mq-append"))
        os.chmod(target_mq, 0o755)
        installed.append(target_mq)

    if "etl" in classes:
        target_etl = os.path.join(bin_dir, "neutrino-etl")
        with open(target_etl, "w", encoding="utf-8") as f:
            f.write(TOOL_WRAPPER_TEMPLATE.replace("{bin_name}", "neutrino-etl"))
        os.chmod(target_etl, 0o755)
        installed.append(target_etl)

    return installed


def remove_shims(
    classes: Optional[List[str]] = None,
    bin_dir: str = ATTACH_BIN_DIR,
    profile_d_path: str = ATTACH_PROFILE_D,
    local_bin_dir: str = "/usr/local/bin",
) -> List[str]:
    """Removes shims, profile.d, and /usr/local/bin/make if owned."""
    removed = []
    classes = classes or ["compile", "batch", "oltp", "mq", "etl"]

    targets_to_check = []
    if "compile" in classes:
        targets_to_check.extend([os.path.join(bin_dir, name) for name in COMPILE_TARGETS])
        targets_to_check.extend([os.path.join(bin_dir, name) for name in COMPILER_TARGETS])
        targets_to_check.extend([os.path.join(bin_dir, name) for name in PYTHON_TARGETS])
        targets_to_check.extend([os.path.join(bin_dir, name) for name in GO_TARGETS])
        targets_to_check.extend([os.path.join(bin_dir, name) for name in CARGO_TARGETS])
        targets_to_check.extend([os.path.join(bin_dir, name) for name in GRADLE_TARGETS])
        if os.path.exists(profile_d_path):
            try:
                os.unlink(profile_d_path)
                removed.append(profile_d_path)
            except OSError:
                pass
        local_make = os.path.join(local_bin_dir, "make")
        if os.path.exists(local_make):
            try:
                with open(local_make, "r", encoding="utf-8", errors="ignore") as f:
                    if "Neutrino attach shim for make" in f.read(200):
                        os.unlink(local_make)
                        removed.append(local_make)
            except Exception:
                pass

    if "batch" in classes:
        targets_to_check.extend([os.path.join(bin_dir, name) for name in BATCH_TARGETS])

    if "oltp" in classes:
        targets_to_check.extend([
            os.path.join(bin_dir, "sqlite3"),
            os.path.join(bin_dir, "neutrino-oltp-load"),
        ])

    if "mq" in classes:
        targets_to_check.append(os.path.join(bin_dir, "neutrino-mq-append"))

    if "etl" in classes:
        targets_to_check.append(os.path.join(bin_dir, "neutrino-etl"))

    for target in targets_to_check:
        if os.path.exists(target):
            try:
                with open(target, "r", encoding="utf-8", errors="ignore") as f:
                    header = f.read(250)
                    if "Neutrino attach shim" in header:
                        os.unlink(target)
                        removed.append(target)
            except Exception:
                pass

    return removed
