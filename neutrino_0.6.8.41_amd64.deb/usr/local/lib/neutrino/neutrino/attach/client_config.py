"""
client_config.py - Autonomous client configuration rewrite and restore for attach proxy.
Standard library only. Zero host literals. Zero external dependencies.
"""

import glob
import hashlib
import json
import logging
import os
import re
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

DEFAULT_CLIENT_CONFIG_GLOBS = [
    "home/*/.dsh/profiles/*/cordis.patch.yml",
    "home/*/.dsh/profiles/*/cordis.yml",
    "home/*/.config/dsh/*.yml",
    "home/*/.config/dsh/*.yaml",
    "home/*/.config/dsh/*.json",
]

DEFAULT_STATE_FILE = "/var/lib/neutrino/attach/client_rewrites.json"
DEFAULT_LAST_WRITTEN_FILE = "/var/lib/neutrino/attach/last_written.json"


def find_client_configs(globs: Optional[List[str]] = None, root: str = "/") -> List[str]:
    """Find client configuration files matching configured or default globs."""
    if globs is None:
        globs = DEFAULT_CLIENT_CONFIG_GLOBS

    root_clean = root.rstrip("/")
    discovered = set()

    for pattern in globs:
        pat = pattern.strip()
        if not pat:
            continue
        if pat.startswith("/"):
            if root_clean:
                full_pat = f"{root_clean}{pat}"
            else:
                full_pat = pat
        else:
            full_pat = os.path.join(root_clean if root_clean else "/", pat)

        for match_path in glob.glob(full_pat, recursive=True):
            if os.path.isfile(match_path):
                discovered.add(os.path.abspath(match_path))

    return sorted(list(discovered))


def rewrite_config_content(content: str) -> Tuple[str, bool]:
    """Rewrite model base URL from 127.0.0.1:8080 or localhost:8080 to 127.0.0.1:8741.

    Preserves path (e.g. /v1).
    Never rewrites public https:// URLs.
    Returns (new_content, modified_bool).
    """
    pattern = r"http://(?:127\.0\.0\.1|localhost):8080"
    new_content, count = re.subn(pattern, "http://127.0.0.1:8741", content)
    return new_content, (count > 0)


def compute_sha256(path: str) -> Optional[str]:
    """Compute sha256 hex digest of file at path. Returns None if unreadable."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while chunk := f.read(65536):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def get_last_written_path(cfg: Optional[Dict[str, Any]] = None, root: str = "/") -> str:
    """Return path to last_written.json based on configuration and root."""
    cfg = cfg or {}
    last_written_file = cfg.get("last_written_file")
    if not last_written_file:
        state_dir = cfg.get("attach_state_dir") or os.path.join(root, "var/lib/neutrino/attach")
        last_written_file = os.path.join(state_dir, "last_written.json")
    return last_written_file


def _set_mode_and_owner(
    path: str, mode: int = 0o640, user: str = "root", group: str = "neutrino"
) -> None:
    """Helper to set file mode and owner, gracefully failing if non-root."""
    try:
        os.chmod(path, mode)
    except (OSError, PermissionError):
        pass
    if hasattr(os, "chown") and hasattr(os, "geteuid") and os.geteuid() == 0:
        try:
            import grp
            import pwd
            uid = pwd.getpwnam(user).pw_uid
            gid = grp.getgrnam(group).gr_gid
            os.chown(path, uid, gid)
        except Exception:
            pass


def load_last_written(
    path: Optional[str] = None, cfg: Optional[Dict[str, Any]] = None, root: str = "/"
) -> Optional[Dict[str, str]]:
    """Load last_written.json mapping path -> sha256 hex digest.

    Returns None if file does not exist or cannot be parsed (fail closed).
    """
    last_written_file = path or get_last_written_path(cfg, root=root)
    if not os.path.isfile(last_written_file):
        return None
    try:
        with open(last_written_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
        return None
    except Exception:
        return None


def save_last_written(
    data: Dict[str, str],
    path: Optional[str] = None,
    cfg: Optional[Dict[str, Any]] = None,
    root: str = "/",
) -> bool:
    """Save last_written mapping atomically with mode 0640 and root:neutrino."""
    last_written_file = path or get_last_written_path(cfg, root=root)
    dir_path = os.path.dirname(last_written_file)
    try:
        os.makedirs(dir_path, exist_ok=True)
    except OSError:
        pass

    tmp_file = f"{last_written_file}.tmp.{os.getpid()}"
    try:
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, sort_keys=True)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())

        _set_mode_and_owner(tmp_file, mode=0o640, user="root", group="neutrino")
        os.replace(tmp_file, last_written_file)
        _set_mode_and_owner(last_written_file, mode=0o640, user="root", group="neutrino")
        return True
    except OSError:
        if os.path.exists(tmp_file):
            try:
                os.unlink(tmp_file)
            except OSError:
                pass
        return False


def record_last_written(
    path: str,
    cfg: Optional[Dict[str, Any]] = None,
    root: str = "/",
) -> bool:
    """Record sha256(live bytes) for path in last_written.json.

    Atomic write, mode 0640 root:neutrino.
    """
    digest = compute_sha256(path)
    if not digest:
        return False

    last_written_file = get_last_written_path(cfg, root=root)
    current_data = load_last_written(last_written_file, cfg=cfg, root=root)
    if current_data is None:
        current_data = {}

    abs_path = os.path.abspath(path)
    current_data[abs_path] = digest
    return save_last_written(current_data, path=last_written_file, cfg=cfg, root=root)


def snapshot_orig_if_missing(path: str) -> bool:
    """Snapshot live configuration to path.nu-orig if missing.

    Preserves mtime, permissions, and owner.
    Returns True if backup was created or already exists, False on error.
    """
    backup_path = f"{path}.nu-orig"
    if os.path.isfile(backup_path):
        return True
    if not os.path.isfile(path):
        return False

    try:
        st = os.stat(path)
        orig_uid = st.st_uid
        orig_gid = st.st_gid
        orig_mode = st.st_mode
        orig_atime = st.st_atime
        orig_mtime = st.st_mtime

        tmp_bak = f"{backup_path}.tmp.{os.getpid()}"
        with open(path, "rb") as sf, open(tmp_bak, "wb") as df:
            while chunk := sf.read(65536):
                df.write(chunk)
            df.flush()
            os.fsync(df.fileno())

        try:
            os.chmod(tmp_bak, orig_mode)
            if hasattr(os, "chown"):
                os.chown(tmp_bak, orig_uid, orig_gid)
            os.utime(tmp_bak, (orig_atime, orig_mtime))
        except (OSError, PermissionError):
            pass

        os.replace(tmp_bak, backup_path)
        try:
            os.utime(backup_path, (orig_atime, orig_mtime))
            if hasattr(os, "chown"):
                os.chown(backup_path, orig_uid, orig_gid)
        except (OSError, PermissionError):
            pass
        return True
    except OSError:
        tmp_bak = f"{backup_path}.tmp.{os.getpid()}"
        if os.path.exists(tmp_bak):
            try:
                os.unlink(tmp_bak)
            except OSError:
                pass
        return False


def rewrite_client_configs(
    cfg: Optional[Dict[str, Any]] = None, root: str = "/"
) -> Dict[str, Any]:
    """Rewrite all discovered client configuration files to route via Neutrino attach proxy.

    Maintains backups (*.nu-orig) and records touched files in state file.
    Preserves original file owner (uid/gid) and permissions (mode).
    Atomic writes only.
    """
    cfg = cfg or {}
    globs_val = (
        cfg.get("attach.client_config_globs")
        or cfg.get("client_config_globs")
        or (cfg.get("attach", {}).get("client_config_globs") if isinstance(cfg.get("attach"), dict) else None)
    )

    if isinstance(globs_val, str):
        globs = [g.strip() for g in globs_val.split(",") if g.strip()]
    elif isinstance(globs_val, (list, tuple)):
        globs = list(globs_val)
    else:
        globs = DEFAULT_CLIENT_CONFIG_GLOBS

    files = find_client_configs(globs, root=root)
    rewritten = []
    already_rewritten = []
    errors = []

    state_file = cfg.get("client_rewrites_state_file")
    if not state_file:
        state_dir = cfg.get("attach_state_dir") or os.path.join(root, "var/lib/neutrino/attach")
        state_file = os.path.join(state_dir, "client_rewrites.json")

    touched_set = set()
    if os.path.isfile(state_file):
        try:
            with open(state_file, "r", encoding="utf-8") as sf:
                data = json.load(sf)
                touched_set.update(data.get("touched_files", []))
        except Exception:
            pass

    for fpath in files:
        try:
            st = os.stat(fpath)
            orig_uid = st.st_uid
            orig_gid = st.st_gid
            orig_mode = st.st_mode
        except OSError as e:
            errors.append({"path": fpath, "reason": str(e)})
            continue

        try:
            with open(fpath, "r", encoding="utf-8") as f:
                content = f.read()
        except OSError as e:
            errors.append({"path": fpath, "reason": str(e)})
            continue

        new_content, modified = rewrite_config_content(content)
        if not modified:
            if "http://127.0.0.1:8741" in content:
                already_rewritten.append(fpath)
            continue

        backup_path = f"{fpath}.nu-orig"
        if not snapshot_orig_if_missing(fpath):
            errors.append({"path": backup_path, "reason": "failed to snapshot original"})
            continue

        # Atomic write of rewritten content
        tmp_target = f"{fpath}.tmp.{os.getpid()}"
        try:
            with open(tmp_target, "w", encoding="utf-8") as tf:
                tf.write(new_content)
                tf.flush()
                os.fsync(tf.fileno())
            try:
                os.chmod(tmp_target, orig_mode)
                if hasattr(os, "chown"):
                    os.chown(tmp_target, orig_uid, orig_gid)
            except (OSError, PermissionError):
                pass
            os.replace(tmp_target, fpath)
            try:
                if hasattr(os, "chown"):
                    os.chown(fpath, orig_uid, orig_gid)
            except (OSError, PermissionError):
                pass

            record_last_written(fpath, cfg=cfg, root=root)
            rewritten.append(fpath)
            touched_set.add(fpath)
        except OSError as e:
            if os.path.exists(tmp_target):
                try:
                    os.unlink(tmp_target)
                except OSError:
                    pass
            errors.append({"path": fpath, "reason": str(e)})

    if rewritten:
        os.makedirs(os.path.dirname(state_file), exist_ok=True)
        tmp_sf = f"{state_file}.tmp.{os.getpid()}"
        try:
            with open(tmp_sf, "w", encoding="utf-8") as sf:
                json.dump({"touched_files": sorted(list(touched_set))}, sf, indent=2)
                sf.write("\n")
                sf.flush()
                os.fsync(sf.fileno())
            os.replace(tmp_sf, state_file)
        except OSError:
            if os.path.exists(tmp_sf):
                try:
                    os.unlink(tmp_sf)
                except OSError:
                    pass

    return {
        "ok": True,
        "rewritten": rewritten,
        "already_rewritten": already_rewritten,
        "errors": errors,
        "state_file": state_file,
    }


def restore_client_configs(
    cfg: Optional[Dict[str, Any]] = None, root: str = "/"
) -> Dict[str, Any]:
    """Restore client configurations to original state only if live matches last Neutrino write.

    Preserves original file owner and mode.
    Cleans up state and backup files.
    Skips restore if live was edited since last write or if last_written is missing.
    """
    cfg = cfg or {}
    state_file = cfg.get("client_rewrites_state_file")
    if not state_file:
        state_dir = cfg.get("attach_state_dir") or os.path.join(root, "var/lib/neutrino/attach")
        state_file = os.path.join(state_dir, "client_rewrites.json")

    last_written_file = get_last_written_path(cfg, root=root)
    last_written = load_last_written(last_written_file, cfg=cfg, root=root)

    if last_written is None:
        logger.info("attach restore skipped: last_written missing")
        return {
            "ok": True,
            "restored": [],
            "skipped": [{"reason": "last_written missing"}],
            "errors": [],
        }

    touched_set = set()
    if os.path.isfile(state_file):
        try:
            with open(state_file, "r", encoding="utf-8") as sf:
                data = json.load(sf)
                touched_set.update(data.get("touched_files", []))
        except Exception:
            pass

    # Also discover any candidate files
    globs_val = (
        cfg.get("attach.client_config_globs")
        or cfg.get("client_config_globs")
        or (cfg.get("attach", {}).get("client_config_globs") if isinstance(cfg.get("attach"), dict) else None)
    )
    if isinstance(globs_val, str):
        globs = [g.strip() for g in globs_val.split(",") if g.strip()]
    elif isinstance(globs_val, (list, tuple)):
        globs = list(globs_val)
    else:
        globs = DEFAULT_CLIENT_CONFIG_GLOBS

    candidate_files = find_client_configs(globs, root=root)
    touched_set.update(candidate_files)
    touched_set.update(last_written.keys())

    restored = []
    skipped = []
    errors = []

    for fpath in sorted(list(touched_set)):
        backup_path = f"{fpath}.nu-orig"
        if not os.path.isfile(backup_path):
            continue

        abs_path = os.path.abspath(fpath)
        expected_sha = last_written.get(abs_path) or last_written.get(fpath)
        live_sha = compute_sha256(fpath)

        if expected_sha and live_sha is not None and live_sha == expected_sha:
            try:
                b_st = os.stat(backup_path)
                b_uid = b_st.st_uid
                b_gid = b_st.st_gid
                b_mode = b_st.st_mode
                os.replace(backup_path, fpath)
                try:
                    os.chmod(fpath, b_mode)
                    if hasattr(os, "chown"):
                        os.chown(fpath, b_uid, b_gid)
                except (OSError, PermissionError):
                    pass
                restored.append(fpath)
            except OSError as e:
                errors.append({"path": fpath, "reason": str(e)})
        else:
            msg = "attach restore skipped: live edited since last write"
            logger.info(msg)
            print(msg, flush=True)
            skipped.append({"path": fpath, "reason": "live edited since last write"})

    # Update state and last_written files
    for fpath in restored:
        abs_p = os.path.abspath(fpath)
        if abs_p in last_written:
            del last_written[abs_p]
        if fpath in last_written:
            del last_written[fpath]
        if fpath in touched_set:
            touched_set.discard(fpath)
        if abs_p in touched_set:
            touched_set.discard(abs_p)

    if last_written:
        save_last_written(last_written, path=last_written_file, cfg=cfg, root=root)
    elif os.path.isfile(last_written_file):
        try:
            os.unlink(last_written_file)
        except OSError:
            pass

    if touched_set:
        tmp_sf = f"{state_file}.tmp.{os.getpid()}"
        try:
            with open(tmp_sf, "w", encoding="utf-8") as sf:
                json.dump({"touched_files": sorted(list(touched_set))}, sf, indent=2)
                sf.write("\n")
                sf.flush()
                os.fsync(sf.fileno())
            os.replace(tmp_sf, state_file)
        except OSError:
            pass
    elif os.path.isfile(state_file):
        try:
            os.unlink(state_file)
        except OSError:
            pass

    return {
        "ok": True,
        "restored": restored,
        "skipped": skipped,
        "errors": errors,
    }
