"""neutrino/attach/apply_runtime.py - Runtime policy application for attach."""
import os
from typing import List


def inject_make_jobs(argv: List[str]) -> List[str]:
    """If comm is make/ninja and argv has no -j/--jobs/-l, inject -j$(nproc)."""
    if not argv:
        return argv

    comm = os.path.basename(argv[0]).strip().lower()
    if comm not in ("make", "gmake", "ninja"):
        return list(argv)

    # Check if -j, --jobs, or -l is present
    has_jobs = False
    for arg in argv[1:]:
        if arg.startswith("-j") or arg.startswith("--jobs") or arg == "-l" or arg.startswith("-l"):
            has_jobs = True
            break

    if has_jobs:
        return list(argv)

    nproc = os.cpu_count() or 1
    return [argv[0], f"-j{nproc}"] + list(argv[1:])


def pin_all_cpus(pid: int) -> bool:
    """sched_setaffinity all CPUs (race-to-idle), never cap cores.

    Never raises into caller/daemon; catches PermissionError, ProcessLookupError, OSError.
    """
    try:
        if hasattr(os, "sched_setaffinity"):
            cpus = os.cpu_count() or 1
            os.sched_setaffinity(pid, range(cpus))
            return True
    except (PermissionError, ProcessLookupError, OSError):
        pass
    except Exception:
        pass
    return False
