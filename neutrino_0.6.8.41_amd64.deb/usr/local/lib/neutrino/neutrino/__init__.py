"""
Neutrino — Enterprise-grade observe-first energy and performance accounting engine.
Invariant: J(pi, x, rho) = (y, E, t)
"""

__version__ = "0.6.8.41"
__author__ = "Xylonix / Neutrino Authors"
