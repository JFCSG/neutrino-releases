"""
neutrino/levers/compile_handoff.py - Detects and applies build/compilation handoff in infer-gpu-agent.
Standard library only. Zero external dependencies.
"""

import json
import os
import re
import subprocess
import shutil
import secrets
import time
from neutrino.hardware.rapl import read_package_rapl_energy, compute_counter_delta_j
from neutrino.jobs.schema import create_job_record
from typing import Dict, Any, Tuple, Optional, List

from neutrino.config import DEFAULT_APPLY_DIR

# Build / compile command patterns
BUILD_COMMAND_PATTERNS = [
    r"\bmake(?:\s+-[a-zA-Z0-9_-]+)*",
    r"\bcmake\s+--build\b",
    r"\bninja\b",
    r"\bcargo\s+(?:build|test)\b",
    r"\bgo\s+build\b",
    r"\b(?:gcc|g\+\+|clang|clang\+\+)\s+[^\n;]+-o\s+[^\n;]+",
    r"\bmvn\s+package\b",
    r"\bgradle(?:\s+build)?\b",
    r"\bnpm\s+run\s+build\b",
]

BUILD_COMMAND_RE = re.compile("|".join(BUILD_COMMAND_PATTERNS), re.IGNORECASE)

CI_SUITE_PATTERNS = [
    r"\brun\s+(?:the\s+)?(?:full\s+|all\s+)?(?:test\s+)?suite\b",
    r"\brun\s+(?:the\s+)?ci\b",
    r"\bexecute\s+(?:the\s+)?full\s+tests?\b",
]

CI_SUITE_RE = re.compile("|".join(CI_SUITE_PATTERNS), re.IGNORECASE)

EXCLUSION_PATTERNS = [
    r"\bexplain\s+(?:this\s+)?makefile\b",
    r"\b-fsyntax-only\b",
    r"\bpy_compile\b",
]

EXCLUSION_RE = re.compile("|".join(EXCLUSION_PATTERNS), re.IGNORECASE)

PATCH_MARKERS = [
    "<<<<<<< SEARCH",
    "=======",
    ">>>>>>> REPLACE",
    "@@ -",
    "diff --git",
    "*** ",
    "--- ",
]


def _extract_text_from_message(msg: Dict[str, Any]) -> str:
    content = msg.get("content", "")
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, dict):
                if "text" in b:
                    parts.append(str(b["text"]))
                elif "content" in b:
                    parts.append(str(b["content"]))
        return "\n".join(parts)
    return str(content or "")


def _has_patch_markers(text: str) -> bool:
    for marker in PATCH_MARKERS:
        if marker in text:
            return True
    return False


def _is_safe_relpath(path: str) -> bool:
    """
    Ensures path is a relative, non-escaping path without shell special characters.
    """
    if not path or not isinstance(path, str):
        return False
    path = path.strip()
    if not path or path.startswith("/") or path.startswith("\\"):
        return False
    # Check for path traversal
    parts = path.replace("\\", "/").split("/")
    if ".." in parts or "." in parts:
        return False
    # Allowed characters: alphanumeric, _, -, ., /
    if not re.match(r"^[a-zA-Z0-9_\-\./]+$", path):
        return False
    return True


def is_allowlisted_argv(argv: Optional[List[str]]) -> bool:
    """
    Validates argv against the strict allowlist:
    - make, make -B, make -j, make -B -C <relpath>
    - cmake --build .
    - cargo build
    - cargo test
    - ninja
    Never allows shell metacharacters, semicolons, bash -c, or unquoted commands.
    """
    if not argv or not isinstance(argv, list):
        return False

    # Check every token for shell metacharacters
    forbidden_chars = {";", "&", "|", "$", "`", "<", ">", "\n", "\r", "(", ")"}
    for token in argv:
        if not isinstance(token, str):
            return False
        if any(c in token for c in forbidden_chars):
            return False

    first_token = os.path.basename(argv[0]).lower()
    if first_token in ("bash", "sh", "python", "python3", "zsh", "ksh"):
        return False

    if argv == ["make"]:
        return True
    if argv == ["make", "-B"]:
        return True
    if argv == ["make", "-j"]:
        return True
    if len(argv) == 4 and argv[0] == "make" and argv[1] == "-B" and argv[2] == "-C":
        return _is_safe_relpath(argv[3])
    if argv == ["cmake", "--build", "."]:
        return True
    if argv == ["cargo", "build"]:
        return True
    if argv == ["cargo", "test"]:
        return True
    if argv == ["ninja"]:
        return True

    return False


def parse_suggested_argv(text: str) -> Optional[List[str]]:
    """
    Attempts to extract an allowlisted build command from the user prompt text.
    Returns the parsed argv list if allowlisted, otherwise None.
    """
    if not text or not isinstance(text, str):
        return None

    # Check for make -B -C <relpath>
    m_make_c = re.search(r"\bmake\s+-B\s+-C\s+([a-zA-Z0-9_\-\./]+)", text)
    if m_make_c:
        relpath = m_make_c.group(1)
        cand = ["make", "-B", "-C", relpath]
        if is_allowlisted_argv(cand):
            return cand

    # Check for make -B
    if re.search(r"\bmake\s+-B\b", text):
        return ["make", "-B"]

    # Check for make -j
    if re.search(r"\bmake\s+-j\b", text):
        return ["make", "-j"]

    # Check for cmake --build .
    if re.search(r"\bcmake\s+--build\s+\.\b", text):
        return ["cmake", "--build", "."]

    # Check for cargo test
    if re.search(r"\bcargo\s+test\b", text):
        return ["cargo", "test"]

    # Check for cargo build
    if re.search(r"\bcargo\s+build\b", text):
        return ["cargo", "build"]

    # Check for ninja
    if re.search(r"\bninja\b", text):
        return ["ninja"]

    # Check for simple make
    if re.search(r"\bmake\b", text):
        return ["make"]

    return None


def detect_compile_handoff(
    body: Dict[str, Any],
) -> Tuple[bool, Optional[str], str, bool]:
    """
    Evaluates whether an infer-gpu-agent payload contains a compile/build intent.
    Returns:
        (compile_suspect: bool, compile_reason: Optional[str], proposed_action: str, compile_mutated: bool)
    """
    messages = body.get("messages", [])
    if not isinstance(messages, list) or not messages:
        return False, None, "noop", False

    # 1. Aider / unified-diff markers -> immediately false (noop)
    for msg in messages:
        if isinstance(msg, dict):
            text = _extract_text_from_message(msg)
            if _has_patch_markers(text):
                return False, None, "noop", False

    candidate_texts: List[str] = []
    candidate_tool_names: List[str] = []

    for msg in reversed(messages):
        if not isinstance(msg, dict):
            continue
        role = str(msg.get("role", "")).lower()
        if role in ("user", "tool", "function"):
            candidate_texts.append(_extract_text_from_message(msg))
            break
        elif role == "assistant":
            tcs = msg.get("tool_calls")
            if isinstance(tcs, list):
                for tc in tcs:
                    if isinstance(tc, dict):
                        fn = tc.get("function", {})
                        fname = str(fn.get("name", "")).lower()
                        candidate_tool_names.append(fname)
                        args = str(fn.get("arguments", ""))
                        candidate_texts.append(args)

    for t in body.get("tools", []):
        if isinstance(t, dict):
            fname = str(t.get("function", {}).get("name", "")).lower()
            if fname in ("make", "ninja", "cargo_build", "build", "build_tree"):
                candidate_tool_names.append(fname)

    combined_text = "\n".join(candidate_texts)

    # 2. Check exclusions
    if EXCLUSION_RE.search(combined_text):
        return False, None, "noop", False

    # Check for single pytest without CI/full suite
    if "pytest" in combined_text.lower():
        if not CI_SUITE_RE.search(combined_text) and not BUILD_COMMAND_RE.search(combined_text):
            return False, None, "noop", False

    # 3. Check tool names
    for tn in candidate_tool_names:
        if tn in ("make", "cmake", "ninja", "cargo_build", "build", "build_tree"):
            return True, "build_command", "neutrino-run-compile", False

    # 4. Check text matches
    if BUILD_COMMAND_RE.search(combined_text):
        return True, "build_command", "neutrino-run-compile", False

    if CI_SUITE_RE.search(combined_text):
        return True, "ci_suite", "neutrino-run-compile", False

    return False, None, "noop", False


def is_compile_handoff_enabled(cfg: Optional[Dict[str, Any]] = None) -> bool:
    cfg = cfg or {}
    from neutrino.apply.manager import load_revoked_classes
    if "compile_handoff" in load_revoked_classes(cfg):
        return False
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    enabled_file = os.path.join(apply_dir, "compile_handoff.enabled")
    if os.path.isfile(enabled_file):
        try:
            with open(enabled_file, "r", encoding="utf-8") as f:
                data = json.loads(f.read())
                return bool(data.get("enabled", True))
        except Exception:
            return True
    try:
        from neutrino.apply.autopilot import licensed_and_armed
        if licensed_and_armed(cfg):
            return True
    except Exception:
        pass
    return False


def spawn_gate(cfg: Optional[Dict[str, Any]] = None) -> bool:
    """
    Evaluates whether compile subprocess spawn is permitted.
    Requires:
    1. Active apply license (claims.apply == True)
    2. /etc/neutrino/apply.d/compile_handoff.enabled exists and is true
    3. /etc/neutrino/apply.d/compile_handoff.spawn exists
    4. /etc/neutrino/apply.d/compile_handoff.conf contains spawn=true
    """
    cfg = cfg or {}
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)

    # 1. License check
    from neutrino.apply.manager import verify_apply_license
    lic_ok, _ = verify_apply_license(cfg, feature_class="compile_handoff", read_only=True)
    if not lic_ok:
        return False

    # 2. Enabled check
    if not is_compile_handoff_enabled(cfg):
        return False

    # 3. Spawn file exists
    spawn_file = os.path.join(apply_dir, "compile_handoff.spawn")
    if not os.path.isfile(spawn_file):
        return False

    # 4. Conf file contains spawn=true
    conf_file = os.path.join(apply_dir, "compile_handoff.conf")
    if not os.path.isfile(conf_file):
        return False

    spawn_conf_ok = False
    try:
        with open(conf_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip().lower()
                if line == "spawn=true":
                    spawn_conf_ok = True
                    break
    except Exception:
        pass

    return spawn_conf_ok


def _extract_last_compile_job_id(cfg: Optional[Dict[str, Any]] = None) -> Optional[str]:
    cfg = cfg or {}
    jobs_file = cfg.get("jobs_file", "/var/lib/neutrino/jobs.jsonl")
    if not os.path.isfile(jobs_file):
        return None
    try:
        with open(jobs_file, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            read_size = min(size, 8192)
            f.seek(size - read_size)
            lines = f.read().decode("utf-8", errors="replace").splitlines()
            for l in reversed(lines):
                l = l.strip()
                if not l:
                    continue
                try:
                    rec = json.loads(l)
                    if rec.get("class") == "compile":
                        return rec.get("id")
                except Exception:
                    pass
    except Exception:
        pass
    return None


def maybe_spawn_compile(
    argv: Optional[List[str]],
    cfg: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Parent-metered compile execution with setuid child drop.
    Gated by spawn_gate(cfg) and is_allowlisted_argv(argv).
    Executes compiler binary directly as user neutrino; parent meters package RAPL.
    """
    cfg = cfg or {}
    if not spawn_gate(cfg):
        return {
            "ran": False,
            "reason": "gate_closed",
            "exit_code": None,
            "job_id": None,
            "stdout_tail": "",
            "stderr_tail": "",
        }

    work_dir = cfg.get("handoff_work_dir", "/var/lib/neutrino/handoff-work")
    if not argv or not is_allowlisted_argv(argv):
        return {
            "ran": False,
            "reason": "argv_rejected",
            "exit_code": None,
            "job_id": None,
            "stdout_tail": "",
            "stderr_tail": "",
        }

    # Resolve user neutrino for privilege drop
    try:
        import pwd
        pw = pwd.getpwnam("neutrino")
    except KeyError:
        return {
            "ran": False,
            "reason": "no_drop_user",
            "exit_code": None,
            "job_id": None,
            "stdout_tail": "",
            "stderr_tail": "",
        }

    target_uid = pw.pw_uid
    target_gid = pw.pw_gid

    # Parent reads initial RAPL counter
    e0, meta0 = read_package_rapl_energy()
    if e0 is None:
        return {
            "ran": False,
            "reason": "parent_rapl_unreadable",
            "exit_code": None,
            "job_id": None,
            "stdout_tail": "",
            "stderr_tail": "",
        }

    try:
        os.makedirs(work_dir, mode=0o750, exist_ok=True)
    except Exception:
        pass

    # Direct execution of allowlisted compiler binary (child does not open RAPL sysfs)
    exec_bin = shutil.which(argv[0]) or f"/usr/bin/{argv[0]}"
    cmd = [exec_bin] + argv[1:]

    preexec_fn = None
    if os.geteuid() == 0:
        def _drop_privileges():
            os.setgid(target_gid)
            os.setuid(target_uid)
            if os.getuid() == 0:
                raise RuntimeError("Failed to drop root privileges before exec")

        preexec_fn = _drop_privileges

    env = dict(os.environ)
    env["CCACHE_DISABLE"] = "1"

    t0 = time.monotonic()
    t_start = time.time()
    try:
        res = subprocess.run(
            cmd,
            cwd=work_dir,
            capture_output=True,
            text=True,
            timeout=120.0,
            env=env,
            preexec_fn=preexec_fn,
        )
        t_stop = time.time()
        dt = max(0.001, time.monotonic() - t0)

        # Parent reads final RAPL counter
        e1, _ = read_package_rapl_energy()
        energy_pkg_j = compute_counter_delta_j(e0, e1, meta0) if e1 is not None else 0.0

        stdout_tail = res.stdout[-4096:] if res.stdout else ""
        stderr_tail = res.stderr[-4096:] if res.stderr else ""

        # Parent writes compile-class job record
        compile_job_id = f"job-compile-{secrets.token_hex(4)}"
        try:
            compile_record = create_job_record(
                job_id=compile_job_id,
                job_class="compile",
                rail="rapl-pkg",
                t_start=t_start,
                t_stop=t_stop,
                energy_pkg_j=energy_pkg_j,
                spawn_ran=True,
                spawn_exit=res.returncode,
                uid_dropped=target_uid,
                policy={
                    "applied": True,
                    "spawn": True,
                    "argv": argv,
                },
            )
            jobs_file = cfg.get("jobs_file", "/var/lib/neutrino/jobs.jsonl")
            parent_dir = os.path.dirname(jobs_file)
            if parent_dir:
                os.makedirs(parent_dir, exist_ok=True)
            with open(jobs_file, "a", encoding="utf-8") as jf:
                jf.write(json.dumps(compile_record, separators=(",", ":")) + "\n")
        except Exception:
            pass

        return {
            "ran": True,
            "reason": "spawn_success" if res.returncode == 0 else "spawn_error",
            "exit_code": res.returncode,
            "job_id": compile_job_id,
            "energy_pkg_j": energy_pkg_j,
            "t_cpu": round(dt, 3),
            "uid_dropped": target_uid,
            "stdout_tail": stdout_tail,
            "stderr_tail": stderr_tail,
        }
    except Exception as e:
        dt = max(0.001, time.monotonic() - t0)
        e1, _ = read_package_rapl_energy()
        energy_pkg_j = compute_counter_delta_j(e0, e1, meta0) if e1 is not None else 0.0
        return {
            "ran": True,
            "reason": f"spawn_exception: {e}",
            "exit_code": 127,
            "job_id": None,
            "energy_pkg_j": energy_pkg_j,
            "t_cpu": round(dt, 3),
            "uid_dropped": target_uid,
            "stdout_tail": "",
            "stderr_tail": str(e)[:4096],
        }


def build_handoff_response(
    suggested_argv: Optional[List[str]],
    prompt_tokens: int = 0,
    spawn_res: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Constructs the structured 200 handoff completion dictionary.
    """
    cmd_str = " ".join(suggested_argv) if suggested_argv else "make -B"
    content = f"Neutrino compile handoff. Run: neutrino-run --class compile -- {cmd_str}"
    if spawn_res and spawn_res.get("ran") and spawn_res.get("exit_code") is not None:
        content += f"\nspawn exit={spawn_res.get('exit_code')}"

    neutrino_meta = {
        "compile_applied": True,
        "proposed_action": "neutrino-run-compile",
        "suggested_argv": suggested_argv if suggested_argv else ["make", "-B"],
        "spawn_ran": spawn_res.get("ran", False) if spawn_res else False,
        "spawn_reason": spawn_res.get("reason") if spawn_res else None,
        "spawn_exit": spawn_res.get("exit_code") if spawn_res else None,
        "spawn_job_id": spawn_res.get("job_id") if spawn_res else None,
    }
    if spawn_res and spawn_res.get("ran"):
        if "energy_pkg_j" in spawn_res:
            neutrino_meta["energy_pkg_j"] = spawn_res["energy_pkg_j"]
        if "t_cpu" in spawn_res:
            neutrino_meta["t_cpu"] = spawn_res["t_cpu"]
        if "uid_dropped" in spawn_res:
            neutrino_meta["uid_dropped"] = spawn_res["uid_dropped"]

    return {
        "object": "chat.completion",
        "choices": [
            {
                "finish_reason": "handoff",
                "message": {
                    "role": "assistant",
                    "content": content,
                },
            }
        ],
        "usage": {
            "prompt_tokens": int(prompt_tokens or 0),
            "completion_tokens": 0,
        },
        "neutrino": neutrino_meta,
    }
