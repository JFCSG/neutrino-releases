"""
dialect.py - Lossless dialect-specific AST and header rewrites for infer-gpu-agent.
Standard library only. Zero host literals. Zero external dependencies.
"""

import copy
import hashlib
import json
import re
from typing import Any, Dict, List, Optional, Tuple

FORBIDDEN_INJECT_KEYS = frozenset({"id_slot", "slot_id"})
DUMP_TOKEN_THRESHOLD = 2000
FENCED_BLOCK_RE = re.compile(r"```[a-zA-Z0-9_-]*\n([\s\S]*?)```")


def detect_dump_guard(body: Dict[str, Any]) -> Tuple[bool, Optional[int], int]:
    """
    Detects if any message contains a large file-shaped dump (>= 2000 estimated tokens).
    Standard heuristic: ~4 characters per token.
    Never truncates payload content. Returns (dump_flag, dump_tok, dump_repeats).
    """
    max_dump_tokens = 0
    dump_count = 0

    messages = body.get("messages", [])
    if isinstance(messages, list):
        for msg in messages:
            if not isinstance(msg, dict):
                continue
            content = msg.get("content", "")
            texts_to_check = []
            if isinstance(content, str):
                texts_to_check.append(content)
            elif isinstance(content, list):
                for b in content:
                    if isinstance(b, dict):
                        if "text" in b:
                            texts_to_check.append(str(b["text"]))
                        elif "content" in b:
                            texts_to_check.append(str(b["content"]))

            for text in texts_to_check:
                # Check fenced code blocks
                fenced_matches = FENCED_BLOCK_RE.findall(text)
                if fenced_matches:
                    for match in fenced_matches:
                        tok_est = len(match) // 4
                        if tok_est >= DUMP_TOKEN_THRESHOLD:
                            dump_count += 1
                            if tok_est > max_dump_tokens:
                                max_dump_tokens = tok_est
                else:
                    # Check raw text if it looks like a code file or large log dump
                    tok_est = len(text) // 4
                    if tok_est >= DUMP_TOKEN_THRESHOLD and ("\n" in text or "{" in text or "def " in text):
                        dump_count += 1
                        if tok_est > max_dump_tokens:
                            max_dump_tokens = tok_est

    if dump_count > 0:
        return True, max_dump_tokens, dump_count
    return False, None, 0


def detect_dialect(body: Dict[str, Any], substrate_dialect: str = "llama-server") -> str:
    """Infers dialect shape from body structure and sensed substrate."""
    # Anthropic wire shape
    if "messages" in body and isinstance(body.get("messages"), list):
        for m in body["messages"]:
            if isinstance(m, dict):
                content = m.get("content")
                if isinstance(content, list):
                    for b in content:
                        if isinstance(b, dict) and b.get("type") in ("tool_use", "tool_result"):
                            return "anthropic"
    if "system" in body and isinstance(body["system"], (list, str)) and "messages" in body:
        # If Anthropic tool structure (input_schema in tools)
        tools = body.get("tools")
        if isinstance(tools, list) and tools and isinstance(tools[0], dict) and "input_schema" in tools[0]:
            return "anthropic"

    # Ollama wire shape
    if "options" in body and isinstance(body["options"], dict):
        return "ollama"
    if "model" in body and ("keep_alive" in body or "template" in body):
        return "ollama"

    # vLLM / cloud OpenAI wire shape
    if substrate_dialect in ("vllm", "cloud-openai"):
        return "vllm"

    # Default to llama / local OpenAI-compat
    return "llama"


def rewrite_agent_dialect(
    body: Dict[str, Any],
    dialect: Optional[str] = None,
    session_key: Optional[str] = None,
    is_holdout: bool = False,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Lossless dialect-specific rewrite for infer-gpu-agent:
    - llama: cache_prompt=True, strip skip_reading_prefix_cache, preserve tools[] sha256
    - anthropic: cache_control on last frozen block, never on tail
    - ollama: keep_alive -1 or 60m, do not change existing num_ctx
    - vLLM: no cache_prompt, optional prompt_cache_key
    - NEVER inject id_slot or slot_id
    - NEVER clamp max_tokens / n_predict
    - Passes unknown JSON fields through unchanged
    """
    out = copy.deepcopy(body)

    # Invariant: Never allow speculative/slot keys
    for k in list(out.keys()):
        if str(k).lower() in FORBIDDEN_INJECT_KEYS:
            del out[k]

    inferred_dialect = dialect or detect_dialect(out)
    telemetry: Dict[str, Any] = {
        "dialect": inferred_dialect,
        "cache_prompt_injected": False,
        "cache_control_injected": False,
        "holdout": is_holdout,
    }

    # Run dump guard detection (observe-only, zero truncation)
    dump_flag, dump_tok, dump_repeats = detect_dump_guard(out)
    telemetry["dump_flag"] = dump_flag
    telemetry["dump_tok"] = dump_tok
    telemetry["dump_repeats"] = dump_repeats

    if is_holdout:
        # Holdout: dialect inject skipped / cache_prompt forced false
        if inferred_dialect in ("llama", "llama-server", "openai"):
            out["cache_prompt"] = False
        return out, telemetry

    if inferred_dialect in ("llama", "llama-server", "openai"):
        # 1. llama / local OpenAI-compat
        out["cache_prompt"] = True
        out.pop("skip_reading_prefix_cache", None)
        telemetry["cache_prompt_injected"] = True

    elif inferred_dialect == "anthropic":
        # 2. Anthropic: inject cache_control on last frozen block
        injected = False
        # Case A: system is a list of blocks
        if "system" in out and isinstance(out["system"], list) and out["system"]:
            last_block = out["system"][-1]
            if isinstance(last_block, dict):
                if "cache_control" not in last_block:
                    last_block["cache_control"] = {"type": "ephemeral"}
                    injected = True
        # Case B: system is a string -> transform into blocks
        elif "system" in out and isinstance(out["system"], str) and out["system"].strip():
            out["system"] = [
                {"type": "text", "text": out["system"], "cache_control": {"type": "ephemeral"}}
            ]
            injected = True
        # Case C: tools present -> inject on last tool definition
        elif "tools" in out and isinstance(out["tools"], list) and out["tools"]:
            last_tool = out["tools"][-1]
            if isinstance(last_tool, dict):
                if "cache_control" not in last_tool:
                    last_tool["cache_control"] = {"type": "ephemeral"}
                    injected = True
        # Case D: multiple messages -> inject on message before the tail
        elif "messages" in out and isinstance(out["messages"], list) and len(out["messages"]) >= 2:
            frozen_msg = out["messages"][-2]
            if isinstance(frozen_msg, dict):
                c = frozen_msg.get("content")
                if isinstance(c, list) and c:
                    last_c = c[-1]
                    if isinstance(last_c, dict) and "cache_control" not in last_c:
                        last_c["cache_control"] = {"type": "ephemeral"}
                        injected = True
                elif isinstance(c, str):
                    frozen_msg["content"] = [
                        {"type": "text", "text": c, "cache_control": {"type": "ephemeral"}}
                    ]
                    injected = True

        telemetry["cache_control_injected"] = injected

    elif inferred_dialect == "ollama":
        # 3. Ollama: keep_alive -1 or 60m
        if "keep_alive" not in out:
            out["keep_alive"] = -1
        # If num_ctx already set, do not change it
        # (preserve out["options"]["num_ctx"] if present)

    elif inferred_dialect in ("vllm", "cloud-openai"):
        # 4. vLLM: no cache_prompt; prompt_cache_key if session present
        sess_id = session_key or out.get("session_id") or out.get("session_key")
        if sess_id:
            out["prompt_cache_key"] = hashlib.sha256(str(sess_id).encode("utf-8")).hexdigest()

    return out, telemetry
