"""
prefix_lint.py - Observe-only prefix stability linter for infer-gpu-agent.
Detects volatile prefix tokens (dates, cwd, git branches, pids, uuids) and mid-session tool drift.
Standard library only. Zero host literals. Zero external dependencies.
"""

import hashlib
import json
import re
from typing import Any, Dict, List, Optional, Tuple

# In-process session schema tracking: session_key -> tools_hash
_SESSION_TOOL_HASHES: Dict[str, str] = {}

ISO_DATE_RE = re.compile(
    r"\b\d{4}-\d{2}-\d{2}(?:[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)?\b"
)
CWD_RE = re.compile(
    r"\b(?:cwd\s*=|working directory:?\s*|current directory:?\s*|dir:?\s*/)",
    re.IGNORECASE,
)
GIT_BRANCH_RE = re.compile(
    r"\b(?:git branch|branch:?\s+[a-zA-Z0-9_\-\./]+|git:\s*\([a-zA-Z0-9_\-\./]+\))",
    re.IGNORECASE,
)
PID_RE = re.compile(
    r"\b(?:pid\s*[:=]\s*\d+|pid\s+\d+)\b",
    re.IGNORECASE,
)
UUID_RE = re.compile(
    r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"
)


def extract_prefix_text(body: Dict[str, Any]) -> str:
    """Extracts raw text representation of the prefix (messages[0] or prompt)."""
    messages = body.get("messages")
    if isinstance(messages, list) and messages:
        first = messages[0]
        if isinstance(first, dict):
            c = first.get("content", "")
            if isinstance(c, str):
                return c
            elif isinstance(c, list):
                parts = []
                for b in c:
                    if isinstance(b, dict) and "text" in b:
                        parts.append(str(b["text"]))
                return " ".join(parts)
    elif "prompt" in body:
        p = body["prompt"]
        if isinstance(p, str):
            return p
        elif isinstance(p, list):
            return " ".join(str(x) for x in p)
    return ""


def compute_tools_hash(tools: Any) -> Optional[str]:
    """Computes a stable deterministic SHA-256 hash of tools schema."""
    if not tools:
        return None
    try:
        norm = json.dumps(tools, sort_keys=True)
        return hashlib.sha256(norm.encode("utf-8")).hexdigest()
    except Exception:
        return None


def lint_prefix(
    body: Dict[str, Any],
    session_key: Optional[str] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Observe-only prefix check:
    Inspects messages[0] or tools[] for volatile elements that destroy KV cache reuse.
    Returns (prefix_break_reason, tools_hash).
    Never mutates or rewrites the prefix text.
    """
    prefix_text = extract_prefix_text(body)
    tools = body.get("tools")
    current_tools_hash = compute_tools_hash(tools)

    # 1. Mid-session tool-schema drift
    if session_key and current_tools_hash:
        prev_hash = _SESSION_TOOL_HASHES.get(session_key)
        if prev_hash and prev_hash != current_tools_hash:
            _SESSION_TOOL_HASHES[session_key] = current_tools_hash
            return "tool_schema_changed", current_tools_hash
        _SESSION_TOOL_HASHES[session_key] = current_tools_hash

    # Serialize tools to text for volatile token checks in tools schemas
    tools_text = ""
    if tools:
        try:
            tools_text = json.dumps(tools)
        except Exception:
            pass

    combined_inspect = f"{prefix_text}\n{tools_text}"

    # 2. Check volatile markers in order of precedence
    if ISO_DATE_RE.search(combined_inspect):
        return "timestamp", current_tools_hash

    if CWD_RE.search(combined_inspect):
        return "cwd", current_tools_hash

    if GIT_BRANCH_RE.search(combined_inspect):
        return "git_branch", current_tools_hash

    if PID_RE.search(combined_inspect):
        return "pid", current_tools_hash

    if UUID_RE.search(combined_inspect):
        return "uuid", current_tools_hash

    return None, current_tools_hash
