"""
neutrino/levers - Workload lever implementations (ccache, agent shape, prefix lint, dialect, dump guard).
Standard library only. Zero external dependencies.
"""

from neutrino.levers.ccache_env import resolve_ccache, parse_ccache_stats_text
from neutrino.levers.agent_shape import (
    classify_agent_request,
    detect_compile_handoff,
    estimate_turn_class,
)
from neutrino.levers.prefix_lint import lint_prefix, compute_tools_hash
from neutrino.levers.dialect import (
    rewrite_agent_dialect,
    detect_dialect,
)
from neutrino.levers.dump_guard import (
    detect_dump_guard,
    is_dump_guard_enabled,
    is_dump_guard_preview_enabled,
    rewrite_dump_guard,
)
from neutrino.levers.compile_handoff import detect_compile_handoff

__all__ = [
    "resolve_ccache",
    "parse_ccache_stats_text",
    "classify_agent_request",
    "detect_compile_handoff",
    "estimate_turn_class",
    "lint_prefix",
    "compute_tools_hash",
    "rewrite_agent_dialect",
    "detect_dump_guard",
    "is_dump_guard_enabled",
    "is_dump_guard_preview_enabled",
    "rewrite_dump_guard",
    "detect_compile_handoff",
    "detect_dialect",
]
