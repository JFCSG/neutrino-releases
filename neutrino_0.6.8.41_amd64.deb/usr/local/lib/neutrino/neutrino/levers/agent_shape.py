"""
agent_shape.py - Classifier for infer-gpu-agent vs infer-gpu-chat based on HTTP wire shape.
Standard library only. Zero host literals. Zero external dependencies.
"""

import hashlib
import json
import re
import time
from typing import Any, Dict, List, Optional, Set, Tuple

COMPILE_TOOLS = frozenset({
    "execute_command", "bash", "shell", "run_terminal_cmd"
})

COMPILE_CMD_RE = re.compile(
    r"\b(make|ninja|cmake|g\+\+|gcc|cargo|mvn|gradle|pytest|ctest|go test)\b",
    re.IGNORECASE,
)

CLINE_XML_TOOL_RE = re.compile(
    r"<(read_file|write_to_file|execute_command|attempt_completion|ask_followup_question|use_mcp_tool|bash|shell|run_terminal_cmd|invoke|tool_call)[^>]*>",
    re.IGNORECASE,
)

REPO_MAP_PATTERNS = (
    "repo-map",
    "repo_map",
    "REPO MAP",
    "<repo_map>",
    "REPO_MAP",
)

T2_READ_TOKENS = frozenset({"read", "grep", "glob", "list", "cat", "open", "search", "find"})
T3_WRITE_TOKENS = frozenset({"str_replace", "edit", "write", "apply_patch", "replace", "patch"})

# In-process session tracking: session_key -> dict of session metadata
_SESSION_CACHE: Dict[str, Dict[str, Any]] = {}


def has_aider_search_replace(text: str) -> bool:
    """True only if BOTH <<<<<<< SEARCH and >>>>>>> REPLACE are present."""
    return "<<<<<<< SEARCH" in text and ">>>>>>> REPLACE" in text


def has_patch_fence(text: str) -> bool:
    """True if explicit patch begin/apply_patch markers are present."""
    return "*** Begin Patch" in text or "apply_patch" in text


def has_agent_fence(text: str) -> bool:
    """Detects agent fences: full Aider SEARCH/REPLACE pair or patch fence.

    Never fires on standalone ======= or bare markdown tables.
    """
    return has_aider_search_replace(text) or has_patch_fence(text)


def detect_compile_handoff(body: Dict[str, Any]) -> bool:
    """Detects if tool call or invocation intends to execute compilation/test commands.

    Flag only; never alters workload class to compile.
    """
    messages = body.get("messages", [])
    if isinstance(messages, list):
        for msg in messages:
            if not isinstance(msg, dict):
                continue
            # Tool calls (OpenAI format)
            tool_calls = msg.get("tool_calls")
            if isinstance(tool_calls, list):
                for tc in tool_calls:
                    if isinstance(tc, dict):
                        fn = tc.get("function", {})
                        if isinstance(fn, dict):
                            fn_name = str(fn.get("name", "")).strip().lower()
                            fn_args = str(fn.get("arguments", ""))
                            if fn_name in COMPILE_TOOLS and COMPILE_CMD_RE.search(fn_args):
                                return True

            # Anthropic tool_use blocks
            content = msg.get("content")
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        name = str(block.get("name", "")).strip().lower()
                        inp = str(block.get("input", ""))
                        if name in COMPILE_TOOLS and COMPILE_CMD_RE.search(inp):
                            return True

            # Text content with tool-call like command
            text_content = ""
            if isinstance(content, str):
                text_content = content
            elif isinstance(content, list):
                text_parts = []
                for b in content:
                    if isinstance(b, dict) and "text" in b:
                        text_parts.append(str(b["text"]))
                text_content = " ".join(text_parts)

            for tool_name in COMPILE_TOOLS:
                if f"<{tool_name}>" in text_content.lower() or f"{tool_name}:" in text_content.lower():
                    if COMPILE_CMD_RE.search(text_content):
                        return True

    return False


def extract_tool_invocations(messages: List[Dict[str, Any]]) -> List[str]:
    """Extracts list of tool names invoked across messages in chronological order."""
    tools_invoked = []
    for m in messages:
        if not isinstance(m, dict):
            continue
        # OpenAI tool calls on assistant message
        tcs = m.get("tool_calls")
        if isinstance(tcs, list):
            for tc in tcs:
                if isinstance(tc, dict):
                    fn = tc.get("function")
                    if isinstance(fn, dict) and fn.get("name"):
                        tools_invoked.append(str(fn["name"]).strip().lower())
        # OpenAI function call
        fc = m.get("function_call")
        if isinstance(fc, dict) and fc.get("name"):
            tools_invoked.append(str(fc["name"]).strip().lower())
        # Anthropic content blocks
        content = m.get("content")
        if isinstance(content, list):
            for b in content:
                if isinstance(b, dict):
                    if b.get("type") == "tool_use" and b.get("name"):
                        tools_invoked.append(str(b["name"]).strip().lower())
                    elif b.get("type") == "tool_result" and b.get("name"):
                        tools_invoked.append(str(b["name"]).strip().lower())
        # Tool message role
        if m.get("role") in ("tool", "function") and m.get("name"):
            tools_invoked.append(str(m["name"]).strip().lower())
    return tools_invoked


def count_tool_assistant_pairs(messages: List[Dict[str, Any]]) -> int:
    """Counts pairs of assistant messages (with tool calls/use) and tool result messages."""
    asst_tool_count = 0
    tool_res_count = 0
    for m in messages:
        if not isinstance(m, dict):
            continue
        role = str(m.get("role", "")).lower()
        if role == "assistant":
            has_tc = bool(m.get("tool_calls") or m.get("function_call"))
            c = m.get("content")
            if isinstance(c, list) and any(isinstance(b, dict) and b.get("type") == "tool_use" for b in c):
                has_tc = True
            if has_tc:
                asst_tool_count += 1
        elif role in ("tool", "function"):
            tool_res_count += 1
        else:
            c = m.get("content")
            if isinstance(c, list) and any(isinstance(b, dict) and b.get("type") == "tool_result" for b in c):
                tool_res_count += 1
    return min(asst_tool_count, tool_res_count)


def is_t2_tool(name: str) -> bool:
    n = name.lower()
    return any(tok in n for tok in T2_READ_TOKENS)


def is_t3_tool(name: str) -> bool:
    n = name.lower()
    return any(tok in n for tok in T3_WRITE_TOKENS)


def estimate_turn_class(
    body: Dict[str, Any],
    compile_handoff: bool,
    prompt_tok: Optional[int] = None,
    prior_prompt_tok: Optional[int] = None,
    is_agent: Optional[bool] = None,
) -> str:
    """
    Locked turn classification:
    - compile_handoff -> T5
    - prompt_tok dropped >50% vs prior session turn -> T7
    - last tool name in read/grep/glob/list/cat/open/search -> T2
    - last tool name in str_replace/edit/write/apply_patch or SEARCH-REPLACE pair -> T3
    - >=3 tool<->assistant pairs, growing -> T4
    - no tools, no fences, short -> T8 (infer-gpu-chat)
    - first call, tools, no results -> T0 or T1
    - unknown allowed -> unknown

    T7 is compact ONLY on a measured token drop, never 'n_msg > 2'.
    Do not map a lone ======= to anything.
    """
    # 1. compile_handoff -> T5
    if compile_handoff:
        return "T5"

    # 2. prompt_tok dropped >50% vs prior session turn -> T7
    if prior_prompt_tok is not None and prompt_tok is not None:
        if prior_prompt_tok > 0 and prompt_tok < 0.5 * prior_prompt_tok:
            return "T7"

    messages = body.get("messages", [])
    if not isinstance(messages, list):
        messages = []

    # Extract all text for fence inspection
    all_text = []
    for m in messages:
        if isinstance(m, dict):
            c = m.get("content", "")
            if isinstance(c, str):
                all_text.append(c)
            elif isinstance(c, list):
                for b in c:
                    if isinstance(b, dict) and "text" in b:
                        all_text.append(str(b["text"]))
    if "prompt" in body and isinstance(body["prompt"], str):
        all_text.append(body["prompt"])
    full_text = "\n".join(all_text)

    has_aider = has_aider_search_replace(full_text)
    tools_invoked = extract_tool_invocations(messages)
    last_tool = tools_invoked[-1] if tools_invoked else None

    # 3. last tool name in read/grep/glob/list/cat/open/search -> T2
    if last_tool and is_t2_tool(last_tool):
        return "T2"

    # 4. last tool name in str_replace/edit/write/apply_patch or SEARCH-REPLACE pair -> T3
    if has_aider or (last_tool and is_t3_tool(last_tool)):
        return "T3"

    # 5. >=3 tool<->assistant pairs, growing -> T4
    pair_count = count_tool_assistant_pairs(messages)
    if pair_count >= 3:
        return "T4"

    has_tools_declared = bool(body.get("tools") or body.get("functions"))

    # 6. first call, tools, no results -> T0 or T1
    if has_tools_declared and not tools_invoked:
        return "T1" if messages else "T0"

    # 7. no tools, no fences, short -> T8 (infer-gpu-chat)
    if is_agent is False or (not has_tools_declared and not has_aider and not tools_invoked):
        if len(full_text) < 4000:
            return "T8"

    return "unknown"


def classify_agent_request(
    body: Dict[str, Any],
    session_key: Optional[str] = None,
    prompt_tok: Optional[int] = None,
    completion_tok: Optional[int] = None,
    prefix_hash: Optional[str] = None,
    prior_prompt_tok: Optional[int] = None,
) -> Tuple[str, bool, str, Dict[str, Any]]:
    """
    Classifies HTTP wire shape into:
    - infer-gpu-agent vs infer-gpu-chat
    - compile_handoff: bool
    - turn_class: T0-T9 or unknown
    - meta: dict with classification reasoning
    """
    meta: Dict[str, Any] = {"agent_reasons": []}
    is_agent = False

    # 1. tools / functions / tool_choice present
    if "tools" in body and body["tools"]:
        is_agent = True
        meta["agent_reasons"].append("tools_present")
    if "functions" in body and body["functions"]:
        is_agent = True
        meta["agent_reasons"].append("functions_present")
    if "tool_choice" in body and body["tool_choice"]:
        is_agent = True
        meta["agent_reasons"].append("tool_choice_present")

    messages = body.get("messages", [])
    if isinstance(messages, list) and messages:
        # 2. role in {tool, function} OR block type tool_use / tool_result
        for m in messages:
            if not isinstance(m, dict):
                continue
            role = str(m.get("role", "")).lower()
            if role in ("tool", "function"):
                is_agent = True
                meta["agent_reasons"].append(f"role_{role}")
            if m.get("tool_calls") or m.get("function_call"):
                is_agent = True
                meta["agent_reasons"].append("tool_calls_present")

            content = m.get("content")
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        btype = str(block.get("type", "")).lower()
                        if btype in ("tool_use", "tool_result"):
                            is_agent = True
                            meta["agent_reasons"].append(f"block_{btype}")

        # 3. Last message inspection for agent markers (Aider, Cline, repo-map)
        last_m = messages[-1]
        if isinstance(last_m, dict):
            last_content = last_m.get("content", "")
            last_text = ""
            if isinstance(last_content, str):
                last_text = last_content
            elif isinstance(last_content, list):
                parts = []
                for b in last_content:
                    if isinstance(b, dict) and "text" in b:
                        parts.append(str(b["text"]))
                last_text = "\n".join(parts)

            if has_agent_fence(last_text):
                is_agent = True
                meta["agent_reasons"].append("agent_fence")
            if CLINE_XML_TOOL_RE.search(last_text):
                is_agent = True
                meta["agent_reasons"].append("cline_xml_tool_fence")
            if any(pat in last_text for pat in REPO_MAP_PATTERNS):
                is_agent = True
                meta["agent_reasons"].append("repo_map_block")

    # 4. Optional session rule
    now = time.time()
    effective_prior_prompt_tok = prior_prompt_tok
    if session_key:
        sess = _SESSION_CACHE.get(session_key)
        if sess is not None:
            if effective_prior_prompt_tok is None:
                effective_prior_prompt_tok = sess.get("prompt_tok")
            last_t = sess.get("last_t", 0.0)
            sess_prefix_hash = sess.get("prefix_hash")
            gap = now - last_t
            if gap < 60.0 and prefix_hash and prefix_hash == sess_prefix_hash:
                if prompt_tok is not None and completion_tok is not None and prompt_tok >= 2 * completion_tok:
                    is_agent = True
                    meta["agent_reasons"].append("session_ratio_rule")

        _SESSION_CACHE[session_key] = {
            "last_t": now,
            "prefix_hash": prefix_hash,
            "prompt_tok": prompt_tok,
        }

    compile_handoff = detect_compile_handoff(body)
    turn_class = estimate_turn_class(
        body=body,
        compile_handoff=compile_handoff,
        prompt_tok=prompt_tok,
        prior_prompt_tok=effective_prior_prompt_tok,
        is_agent=is_agent,
    )

    child_class = "infer-gpu-agent" if is_agent else "infer-gpu-chat"
    return child_class, compile_handoff, turn_class, meta
