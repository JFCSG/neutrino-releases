"""
neutrino/levers/dump_guard.py - Detects dump vs patch shapes for infer-gpu-agent.
Standard library only. Zero external dependencies.
When enabled: rewrites full file dump turns into compact unified-diff patches against prior tool read.
"""

import copy
import difflib
import json
import os
import re
from typing import Dict, Any, Tuple, Optional, List, Set

from neutrino.config import DEFAULT_APPLY_DIR

# Patch / diff markers that indicate a hunk-based patch rather than a full file dump
PATCH_MARKERS = [
    "<<<<<<< SEARCH",
    "=======",
    ">>>>>>> REPLACE",
    "@@ -",
    "diff --git",
    "*** ",
    "--- ",
]

FENCED_CODE_RE = re.compile(r"```[a-zA-Z0-9_-]*\n([\s\S]*?)```")
FILE_PATH_RE = re.compile(r"([a-zA-Z0-9_.-]+(?:/[a-zA-Z0-9_.-]+)+\.[a-zA-Z0-9_]+)")


def _extract_text_from_message(msg: Dict[str, Any]) -> str:
    """Extracts plain text content from a message dict."""
    content = msg.get("content", "")
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, dict):
                if "text" in b:
                    parts.append(str(b["text"]))
                elif "content" in b:
                    parts.append(str(b["content"]))
        return "\n".join(parts)
    return str(content or "")


def _has_patch_markers(text: str) -> bool:
    """Returns True if text contains explicit patch or diff hunk markers."""
    for marker in PATCH_MARKERS:
        if marker in text:
            return True
    return False


def _split_lines(text: str) -> List[str]:
    """Splits text strictly on POSIX line breaks (\\n), preserving line endings."""
    if not text:
        return []
    lines = text.split("\n")
    res = [l + "\n" for l in lines[:-1]]
    if lines[-1]:
        res.append(lines[-1])
    return res


def _extract_paths_from_read_activity(messages: List[Dict[str, Any]]) -> List[str]:
    """Extracts candidate file paths referenced in read/view tool calls or descriptions."""
    tool_paths: List[str] = []
    text_paths: List[str] = []
    read_names = {"read_file", "view_file", "cat", "cat_file", "read", "view", "open", "read_file_content"}

    for msg in messages:
        if not isinstance(msg, dict):
            continue
        # Check tool_calls in assistant messages
        tool_calls = msg.get("tool_calls")
        if isinstance(tool_calls, list):
            for tc in tool_calls:
                if not isinstance(tc, dict):
                    continue
                fn = tc.get("function", {})
                name = str(fn.get("name", "")).lower()
                if name in read_names:
                    args_raw = fn.get("arguments", "")
                    if isinstance(args_raw, str):
                        try:
                            args = json.loads(args_raw)
                        except Exception:
                            args = {}
                    elif isinstance(args_raw, dict):
                        args = args_raw
                    else:
                        args = {}
                    for k in ("path", "file_path", "filename", "file"):
                        val = args.get(k)
                        if val and isinstance(val, str):
                            p = val.strip()
                            if p not in tool_paths:
                                tool_paths.append(p)

        # Check plain text mentions of file reads in user or assistant messages ONLY (never in tool response payloads)
        role = str(msg.get("role", "")).lower()
        if role in ("user", "assistant"):
            text = _extract_text_from_message(msg)
            if any(kw in text.lower() for kw in ("read", "view", "cat", "file")):
                for m in FILE_PATH_RE.findall(text):
                    p = m.strip()
                    if p not in tool_paths and p not in text_paths:
                        text_paths.append(p)

    return tool_paths + text_paths



def _is_markdown_table(text: str) -> bool:
    """Returns True if the text represents a markdown table rather than source code."""
    if not text or not isinstance(text, str):
        return False
    lines = [l.strip() for l in text.strip().splitlines() if l.strip()]
    if len(lines) < 2:
        return False

    def _is_sep(line: str) -> bool:
        if "|" not in line or "-" not in line:
            return False
        cells = [c.strip() for c in line.split("|")]
        valid_cells = [c for c in cells if c]
        if len(valid_cells) < 2:
            return False
        return all(bool(re.match(r"^:?-+:?$", c)) for c in valid_cells)

    has_separator = any(_is_sep(l) for l in lines)
    table_lines = sum(1 for l in lines if l.startswith("|") and l.endswith("|"))
    if has_separator and (table_lines / len(lines) >= 0.5):
        return True
    return False


def detect_dump_guard(
    body: Dict[str, Any],
    prompt_tok: Optional[int] = None,
    prefix_tok: Optional[int] = None,
) -> Tuple[bool, Optional[str], str, bool]:
    """
    Evaluates whether an infer-gpu-agent payload contains a full file dump vs patch.
    Observe only: dump_mutated is ALWAYS False.

    Returns:
        (dump_suspect: bool, dump_reason: Optional[str], proposed_action: str, dump_mutated: bool)
    """
    messages = body.get("messages", [])
    if not isinstance(messages, list) or not messages:
        return False, None, "noop", False

    # 1. Detect order check: If ANY message contains Aider / unified-diff markers -> false (noop) immediately.
    for msg in messages:
        if isinstance(msg, dict):
            text = _extract_text_from_message(msg)
            if _has_patch_markers(text):
                return False, None, "noop", False

    # 3. Trigger 2: full-file dump (large fenced block or whole-buffer read result) after a prior read of the same path
    tail_msg = messages[-1]
    if isinstance(tail_msg, dict):
        prior_messages = messages[:-1]
        prior_paths = _extract_paths_from_read_activity(prior_messages)

        tail_text = _extract_text_from_message(tail_msg)
        tail_role = str(tail_msg.get("role", "")).lower()
        if tail_role in ("user", "tool", "function"):
            fenced_matches = FENCED_CODE_RE.findall(tail_text)
            non_table_fences = [m for m in fenced_matches if not _is_markdown_table(m)]
            has_large_fence = any(len(m) >= 2000 for m in non_table_fences)
            is_large_text = len(tail_text) >= 2000 and not _is_markdown_table(tail_text)

            if (has_large_fence or is_large_text) and prior_paths:
                for p in prior_paths:
                    filename = p.split("/")[-1]
                    if p in tail_text or filename in tail_text:
                        return True, "full_file_dump_after_read", "patch_not_dump", False

    # 2. Trigger 1: user/tool content repeats >= 80% of a prior message over >= 2k chars
    for i, msg in enumerate(messages):
        if not isinstance(msg, dict):
            continue
        role = str(msg.get("role", "")).lower()
        if role in ("user", "tool", "function"):
            text_i = _extract_text_from_message(msg)
            len_i = len(text_i)
            if len_i >= 2000:
                for j in range(i):
                    prior_msg = messages[j]
                    if not isinstance(prior_msg, dict):
                        continue
                    text_j = _extract_text_from_message(prior_msg)
                    len_j = len(text_j)
                    if len_j >= 2000 and not _is_markdown_table(text_i) and not _is_markdown_table(text_j):
                        min_len = min(len_i, len_j)
                        max_len = max(len_i, len_j)
                        if (min_len / max_len) >= 0.80:
                            if text_j in text_i or text_i in text_j:
                                return True, "repeated_prior_message", "patch_not_dump", False
                            matcher = difflib.SequenceMatcher(None, text_j, text_i, autojunk=False)
                            if matcher.quick_ratio() >= 0.80 and matcher.ratio() >= 0.80:
                                return True, "repeated_prior_message", "patch_not_dump", False

    # 4. Trigger 3: prompt_tok grew >= 2x the frozen system+tools prefix without a new tool name
    sys_text = ""
    if "system" in body:
        sys_val = body["system"]
        if isinstance(sys_val, str):
            sys_text = sys_val
        elif isinstance(sys_val, list):
            sys_text = json.dumps(sys_val)
    elif messages and isinstance(messages[0], dict) and str(messages[0].get("role")).lower() == "system":
        sys_text = _extract_text_from_message(messages[0])

    tools = body.get("tools", [])
    tools_text = json.dumps(tools) if tools else ""
    prefix_chars = len(sys_text) + len(tools_text)
    est_prefix_tok = prefix_tok if prefix_tok is not None else max(1, prefix_chars // 4)

    if prompt_tok is not None:
        total_tok = prompt_tok
    else:
        total_chars = sum(len(_extract_text_from_message(m)) for m in messages if isinstance(m, dict)) + len(tools_text)
        total_tok = total_chars // 4

    if est_prefix_tok >= 200 and total_tok >= 2 * est_prefix_tok:
        for msg in messages:
            if isinstance(msg, dict) and str(msg.get("role")).lower() in ("user", "tool", "function"):
                msg_text = _extract_text_from_message(msg)
                if len(msg_text) >= 2000 and not _has_patch_markers(msg_text) and not _is_markdown_table(msg_text):
                    return True, "prompt_expansion_without_tools", "patch_not_dump", False

    return False, None, "noop", False



def is_dump_guard_preview_enabled(cfg: Optional[Dict[str, Any]] = None) -> bool:
    """
    Checks if operator-planted /etc/neutrino/apply.d/dump_guard.preview exists and is true.
    Header X-Neutrino-Preview: 1 is ignored unless this file exists.
    """
    cfg = cfg or {}
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    preview_file = os.path.join(apply_dir, "dump_guard.preview")
    if not os.path.isfile(preview_file):
        return False
    try:
        with open(preview_file, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return True
            data = json.loads(content)
            return bool(data.get("enabled", True) if isinstance(data, dict) else True)
    except Exception:
        return True


def is_dump_guard_enabled(cfg: Optional[Dict[str, Any]] = None) -> bool:
    cfg = cfg or {}
    from neutrino.apply.manager import load_revoked_classes
    if "dump_guard" in load_revoked_classes(cfg):
        return False
    apply_dir = cfg.get("apply_dir", DEFAULT_APPLY_DIR)
    enabled_file = os.path.join(apply_dir, "dump_guard.enabled")
    if os.path.isfile(enabled_file):
        try:
            with open(enabled_file, "r", encoding="utf-8") as f:
                data = json.loads(f.read())
                return bool(data.get("enabled", True))
        except Exception:
            return True
    try:
        from neutrino.apply.autopilot import licensed_and_armed
        if licensed_and_armed(cfg):
            return True
    except Exception:
        pass
    return False


def _extract_substantive_code(text: str) -> Optional[str]:
    """
    Returns substantive code lines from text, or None if the text is merely metadata/summary.
    """
    if not text or not isinstance(text, str):
        return None
    s = text.strip()
    if not s or s.startswith("Error:") or s.startswith("File not found"):
        return None

    # If fenced, extract fenced content
    fenced_match = FENCED_CODE_RE.search(text)
    if fenced_match:
        cand = fenced_match.group(1)
        if len(cand.strip()) >= 40:
            return cand

    # If raw code: check for multi-line and code characteristics
    lines = [l for l in s.splitlines() if l.strip()]
    if len(lines) >= 3 and len(s) >= 80:
        # Avoid metadata strings like "File content of X (Y bytes read)."
        if lines[0].startswith("File content of ") and len(lines) <= 2:
            return None
        return text

    return None


def _extract_baseline_content(
    messages: List[Dict[str, Any]],
    target_path: Optional[str] = None,
) -> Optional[str]:
    """
    Extracts baseline file content from prior tool messages.
    Returns None if no substantive file content is found (no_baseline).
    """
    read_names = {"read_file", "view_file", "cat", "cat_file", "read", "view", "open", "read_file_content"}
    filename = target_path.split("/")[-1] if target_path else None

    # Pass 1: Correlate assistant tool_calls with tool responses
    for i, msg in enumerate(messages):
        if not isinstance(msg, dict):
            continue
        tool_calls = msg.get("tool_calls")
        if isinstance(tool_calls, list):
            for tc in tool_calls:
                if not isinstance(tc, dict):
                    continue
                fn = tc.get("function", {})
                name = str(fn.get("name", "")).lower()
                if name in read_names:
                    args_raw = fn.get("arguments", "")
                    if isinstance(args_raw, str):
                        try:
                            args = json.loads(args_raw)
                        except Exception:
                            args = {}
                    elif isinstance(args_raw, dict):
                        args = args_raw
                    else:
                        args = {}
                    cand_path = None
                    for k in ("path", "file_path", "filename", "file"):
                        val = args.get(k)
                        if val and isinstance(val, str):
                            cand_path = val.strip()
                            break

                    matches_target = False
                    if not target_path:
                        matches_target = True
                    elif cand_path:
                        cand_filename = cand_path.split("/")[-1]
                        if cand_path == target_path or cand_filename == filename:
                            matches_target = True

                    if matches_target:
                        call_id = tc.get("id")
                        for resp_msg in messages[i + 1:]:
                            if not isinstance(resp_msg, dict):
                                continue
                            if resp_msg.get("role") in ("tool", "function"):
                                if not call_id or resp_msg.get("tool_call_id") == call_id:
                                    text = _extract_text_from_message(resp_msg)
                                    clean_text = _extract_substantive_code(text)
                                    if clean_text:
                                        return clean_text

    # Pass 2: Fallback scan of any tool message that contains substantive code
    for msg in reversed(messages):
        if isinstance(msg, dict) and msg.get("role") in ("tool", "function"):
            text = _extract_text_from_message(msg)
            clean_text = _extract_substantive_code(text)
            if clean_text:
                return clean_text

    return None


def rewrite_dump_guard(
    body: Dict[str, Any],
    cfg: Optional[Dict[str, Any]] = None,
    is_holdout: bool = False,
    preview: bool = False,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Applies dump_guard live rewrite if licensed and (enabled or preview).
    Replaces full-file dump in tail message with a compact unified-diff patch
    against the prior tool read.
    Holdout turns skip rewrite (returns body unmutated, dump_mutated=False).
    Preview mode returns candidate hunk without requiring apply.d/dump_guard.enabled or autopilot,
    provided operator-planted apply.d/dump_guard.preview exists and preview=True.
    If unlicensed, unenabled/unpreviewed, or no baseline text found, fails closed (returns body unmutated).
    """
    cfg = cfg or {}

    # Run detection
    dump_suspect, dump_reason, proposed_action, _ = detect_dump_guard(body)
    default_meta = {
        "dump_suspect": dump_suspect,
        "dump_reason": dump_reason,
        "proposed_action": proposed_action,
        "dump_mutated": False,
        "dump_bytes_in": None,
        "dump_bytes_out": None,
    }

    if not (dump_suspect and dump_reason == "full_file_dump_after_read"):
        return body, default_meta

    if is_holdout:
        # Holdout: skips rewrite, dump_mutated=False
        return body, default_meta

    has_preview_file = is_dump_guard_preview_enabled(cfg)
    effective_preview = preview and has_preview_file

    # Check license
    try:
        from neutrino.apply.manager import verify_apply_license
        lic_ok, _ = verify_apply_license(cfg, feature_class="dump_guard", read_only=True)
    except Exception:
        lic_ok = False

    if not lic_ok:
        return body, default_meta

    # Check enabled or operator-planted preview: preview emits hunk without requiring dump_guard.enabled or autopilot
    if not (effective_preview or is_dump_guard_enabled(cfg)):
        return body, default_meta

    messages = body.get("messages", [])
    if not isinstance(messages, list) or len(messages) < 2:
        return body, default_meta

    tail_msg = messages[-1]
    if not isinstance(tail_msg, dict):
        return body, default_meta

    tail_text = _extract_text_from_message(tail_msg)
    prior_messages = messages[:-1]
    prior_paths = _extract_paths_from_read_activity(prior_messages)

    # Extract dumped source block from tail message
    fenced_matches = list(FENCED_CODE_RE.finditer(tail_text))
    if fenced_matches:
        dumped_match = max(fenced_matches, key=lambda m: len(m.group(1)))
        dumped_code = dumped_match.group(1)
        raw_fence = dumped_match.group(0)
        preamble = tail_text[:dumped_match.start()] + " " + tail_text[dumped_match.end():]
    else:
        dumped_code = tail_text
        raw_fence = tail_text
        preamble = tail_text

    # Find candidate path
    matched_path = None
    # 1. First priority: match against preamble (user instructions outside dumped code)
    for p in prior_paths:
        filename = p.split("/")[-1]
        if p in preamble or filename in preamble:
            matched_path = p
            break
    # 2. Second priority: full path match in tail text
    if not matched_path:
        for p in prior_paths:
            if p in tail_text:
                matched_path = p
                break
    # 3. Third priority: filename match in tail text
    if not matched_path:
        for p in prior_paths:
            filename = p.split("/")[-1]
            if filename in tail_text:
                matched_path = p
                break
    # 4. Fallback: first prior path
    if not matched_path and prior_paths:
        matched_path = prior_paths[0]

    # Extract baseline content
    baseline_text = _extract_baseline_content(prior_messages, target_path=matched_path)
    if not baseline_text:
        # FAIL_CLOSED: forward unchanged, dump_mutated=false, reason=no_baseline
        meta_no_baseline = dict(default_meta)
        meta_no_baseline["dump_reason"] = "no_baseline"
        return body, meta_no_baseline

    # Generate unified diff using stdlib difflib
    fname = (matched_path or "source").split("/")[-1]
    baseline_lines = _split_lines(baseline_text)
    dumped_lines = _split_lines(dumped_code)

    diff_lines = list(difflib.unified_diff(
        baseline_lines,
        dumped_lines,
        fromfile=f"a/{fname}",
        tofile=f"b/{fname}",
        n=3,
    ))
    diff_body = "".join(diff_lines)
    if not diff_body:
        diff_body = f"# No changes detected for {fname}\n"

    replacement_block = f"```diff\n{diff_body}```"
    new_tail_text = tail_text.replace(raw_fence, replacement_block, 1)

    dump_bytes_in = len(raw_fence.encode("utf-8"))
    dump_bytes_out = len(replacement_block.encode("utf-8"))

    new_body = copy.deepcopy(body)
    new_body["messages"][-1]["content"] = new_tail_text

    return new_body, {
        "dump_suspect": True,
        "dump_reason": "full_file_dump_after_read",
        "proposed_action": "patch_not_dump",
        "dump_mutated": True,
        "dump_bytes_in": dump_bytes_in,
        "dump_bytes_out": dump_bytes_out,
    }
