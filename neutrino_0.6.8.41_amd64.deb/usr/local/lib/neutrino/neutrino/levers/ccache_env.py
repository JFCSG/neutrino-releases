"""
ccache_env.py - C/C++ compiler cache materialization helper for Neutrino.
Maps class compile lever materialize onto host ccache for child execution.
Standard library only. Zero external dependencies.
"""

import os
import re
import shutil
import subprocess
from typing import Dict, Any, Optional

DEFAULT_CCACHE_DIR = "/var/lib/neutrino/ccache"
DEFAULT_LIBEXEC_CCACHE_DIR = "/opt/neutrino/libexec/ccache"


def resolve_ccache() -> Optional[str]:
    """Finds ccache binary on system PATH. Never installs packages."""
    return shutil.which("ccache")


def parse_ccache_stats_text(text: str) -> Dict[str, int]:
    """
    Parses ccache stats text supporting ccache 4.x, 3.x, and --print-stats formats.
    Returns {'hits': int, 'misses': int}, or empty dict on failure.
    """
    if not text:
        return {}

    # 1. ccache --print-stats format
    d_hit = re.search(r"^direct_cache_hit\s+(\d+)", text, re.MULTILINE)
    p_hit = re.search(r"^preprocessed_cache_hit\s+(\d+)", text, re.MULTILINE)
    c_miss = re.search(r"^cache_miss\s+(\d+)", text, re.MULTILINE)
    if d_hit and c_miss:
        h = int(d_hit.group(1)) + (int(p_hit.group(1)) if p_hit else 0)
        m = int(c_miss.group(1))
        return {"hits": h, "misses": m}

    # 2. ccache 4.x Summary format:
    #   Hits:               12 /    20
    #   Misses:             5
    hits_m4 = re.search(r"^\s*Hits:\s*(\d+)", text, re.MULTILINE)
    miss_m4 = re.search(r"^\s*Misses:\s*(\d+)", text, re.MULTILINE)
    if hits_m4 is not None and miss_m4 is not None:
        return {"hits": int(hits_m4.group(1)), "misses": int(miss_m4.group(1))}

    # 3. ccache 3.x format:
    # cache hit (direct) <int>
    # cache hit (preprocessed) <int>
    # cache miss <int>
    c3_hits = re.findall(r"cache hit.*?\s+(\d+)", text, re.IGNORECASE)
    c3_miss = re.search(r"cache miss\s+(\d+)", text, re.IGNORECASE)
    if c3_hits and c3_miss:
        return {"hits": sum(int(x) for x in c3_hits), "misses": int(c3_miss.group(1))}

    # Fallback search
    if hits_m4 is not None and miss_m4 is not None:
        return {"hits": int(hits_m4.group(1)), "misses": int(miss_m4.group(1))}

    return {}


def snapshot_stats(
    ccache_dir: Optional[str] = None,
    ccache_bin: Optional[str] = None,
) -> Dict[str, int]:
    """
    Executes 'ccache -s' against the target CCACHE_DIR and extracts hits and misses.
    Returns {'hits': int, 'misses': int}, or empty dict on failure or missing binary.
    """
    binary = ccache_bin or resolve_ccache()
    if not binary:
        return {}

    target_dir = ccache_dir or os.environ.get("CCACHE_DIR") or DEFAULT_CCACHE_DIR
    env = dict(os.environ)
    env["CCACHE_DIR"] = target_dir

    try:
        proc = subprocess.run(
            [binary, "-s"],
            capture_output=True,
            text=True,
            env=env,
            timeout=5,
        )
        if proc.returncode != 0:
            return {}
        return parse_ccache_stats_text(proc.stdout)
    except Exception:
        return {}


def is_compile_apply_enabled(
    cfg: Optional[Dict[str, Any]] = None,
    root: str = "/",
) -> bool:
    """Checks whether compile apply is enabled."""
    cfg = cfg or {}
    apply_dir = cfg.get("apply_dir") or os.environ.get("NEUTRINO_APPLY_DIR") or os.path.join(root, "etc/neutrino/apply.d")
    disabled_file = os.path.join(apply_dir, "compile.disabled")
    if os.path.isfile(disabled_file):
        return False
    from neutrino.apply.manager import load_revoked_classes
    if "compile" in load_revoked_classes(cfg):
        return False
    try:
        from neutrino.apply.autopilot import licensed_and_armed
        if licensed_and_armed(cfg=cfg, root=root):
            return True
    except Exception:
        pass
    enabled_file = os.path.join(apply_dir, "compile.enabled")
    return os.path.isfile(enabled_file)


def child_env(
    base_env: Optional[Dict[str, str]] = None,
    cfg: Optional[Dict[str, Any]] = None,
    force_apply: bool = False,
    libexec_dir: Optional[str] = None,
    ccache_dir: Optional[str] = None,
) -> Dict[str, str]:
    """
    Constructs child environment for wrapped compilation jobs:
    Prepends /opt/neutrino/libexec/ccache to PATH,
    Sets CCACHE_DIR = /var/lib/neutrino/ccache,
    Sets CCACHE_UMASK = 007.
    Only if apply compile enabled (or force_apply) AND ccache binary exists.
    """
    env = dict(base_env if base_env is not None else os.environ)
    ccache_bin = resolve_ccache()
    if not ccache_bin:
        return env

    if not force_apply and not is_compile_apply_enabled(cfg):
        return env

    target_libexec = (
        libexec_dir
        or os.environ.get("NEUTRINO_LIBEXEC_CCACHE_DIR")
        or DEFAULT_LIBEXEC_CCACHE_DIR
    )
    target_ccache_dir = (
        ccache_dir
        or (cfg.get("ccache_dir") if cfg else None)
        or os.environ.get("NEUTRINO_CCACHE_DIR")
        or DEFAULT_CCACHE_DIR
    )

    old_path = env.get("PATH", "")
    if old_path:
        env["PATH"] = f"{target_libexec}:{old_path}"
    else:
        env["PATH"] = target_libexec

    env["CCACHE_DIR"] = target_ccache_dir
    env["CCACHE_UMASK"] = "007"
    return env
