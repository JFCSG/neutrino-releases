"""
Hardware abstraction package for Neutrino.
"""
