"""
rapl.py - Wrap-aware sysfs RAPL energy counter acquisition.
Standard library only. Zero external dependencies.
"""

import os
from typing import Tuple, Optional, Dict, Any

POWERCAP_PATH = "/sys/class/powercap"


def find_rapl_packages() -> Dict[str, Dict[str, Any]]:
    """
    Discovers available intel-rapl packages and subdomains (core, uncore, dram).
    """
    packages = {}
    if not os.path.isdir(POWERCAP_PATH):
        return packages

    try:
        entries = sorted(os.listdir(POWERCAP_PATH))
    except OSError:
        return packages

    for entry in entries:
        if not entry.startswith("intel-rapl:"):
            continue
        p_path = os.path.join(POWERCAP_PATH, entry)
        name_file = os.path.join(p_path, "name")
        energy_file = os.path.join(p_path, "energy_uj")
        max_file = os.path.join(p_path, "max_energy_range_uj")

        if not os.path.isfile(energy_file):
            continue

        name = "unknown"
        if os.path.isfile(name_file):
            try:
                with open(name_file, "r", encoding="utf-8") as f:
                    name = f.read().strip()
            except OSError:
                pass

        max_range = 0
        if os.path.isfile(max_file):
            try:
                with open(max_file, "r", encoding="utf-8") as f:
                    max_range = int(f.read().strip())
            except (OSError, ValueError):
                pass

        packages[entry] = {
            "path": p_path,
            "name": name,
            "energy_file": energy_file,
            "max_energy_range_uj": max_range,
        }

    return packages


def read_package_rapl_energy() -> Tuple[Optional[int], Optional[int]]:
    """
    Reads the primary package RAPL energy counter in microjoules (uJ)
    along with its maximum wrap range (max_energy_range_uj).
    Returns (energy_uj, max_range_uj) or (None, None).
    """
    packages = find_rapl_packages()
    # Find package-0 or first available package
    target_entry = None
    for k, v in packages.items():
        if "package" in v["name"].lower():
            target_entry = v
            break
    if not target_entry and packages:
        target_entry = next(iter(packages.values()))

    if not target_entry:
        return None, None

    try:
        with open(target_entry["energy_file"], "r", encoding="utf-8") as f:
            uj = int(f.read().strip())
        return uj, target_entry.get("max_energy_range_uj")
    except (OSError, ValueError):
        return None, None


def read_dram_rapl_energy() -> Tuple[Optional[int], Optional[int]]:
    """
    Reads DRAM sub-rail energy if exposed by hardware sysfs.
    Returns (energy_uj, max_range_uj) or (None, None).
    Never fabricates a 0 reading if hardware omits DRAM counter.
    """
    packages = find_rapl_packages()
    for k, v in packages.items():
        if "dram" in v["name"].lower():
            try:
                with open(v["energy_file"], "r", encoding="utf-8") as f:
                    uj = int(f.read().strip())
                return uj, v.get("max_energy_range_uj")
            except (OSError, ValueError):
                return None, None
    return None, None


def compute_counter_delta_j(start_uj: int, stop_uj: int, max_range_uj: Optional[int] = None) -> float:
    """
    Calculates differential Joules across counter reads with wrap-around safety.
    Handles hardware wrapping counters (e.g. 32-bit integer wrap).
    """
    if stop_uj >= start_uj:
        delta_uj = stop_uj - start_uj
    elif max_range_uj and max_range_uj > 0:
        delta_uj = (stop_uj + max_range_uj) - start_uj
    else:
        # 32-bit wrap fallback if max_range_uj is not populated
        delta_uj = (stop_uj + (1 << 32)) - start_uj
    return round(delta_uj / 1e6, 3)
