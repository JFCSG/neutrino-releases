"""
nvml_stub.py - Backward compatibility shim re-exporting from neutrino.hardware.nvml.
Single loader architecture; all logic lives in nvml.py.
"""

from neutrino.hardware.nvml import (
    is_gpu_present,
    gpu_energy_mj,
    gpu_telemetry_snapshot,
    is_nvml_readable,
    get_gpu_count,
    read_gpu_energy_mj,
    read_gpu_power_w,
    compute_gpu_counter_delta_j,
)

__all__ = [
    "is_gpu_present",
    "gpu_energy_mj",
    "gpu_telemetry_snapshot",
    "is_nvml_readable",
    "get_gpu_count",
    "read_gpu_energy_mj",
    "read_gpu_power_w",
    "compute_gpu_counter_delta_j",
]
