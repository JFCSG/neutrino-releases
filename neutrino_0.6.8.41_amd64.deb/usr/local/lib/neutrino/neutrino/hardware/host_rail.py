"""
host_rail.py - Low-overhead always-on host RAPL rail (rapl-host).
Meters package energy over wall time intervals (default 60s).
License-independent, meter-only. Stdlib only. Zero external dependencies.
"""

import grp
import json
import os
import threading
import time
from typing import Dict, Any, Optional, Tuple

from neutrino.hardware.rapl import (
    find_rapl_packages,
    read_package_rapl_energy,
    compute_counter_delta_j,
)

DEFAULT_HOST_SAMPLE_SEC = 60
MIN_HOST_SAMPLE_SEC = 15
MAX_HOST_SAMPLE_SEC = 300
MAX_LOG_SIZE_BYTES = 32 * 1024 * 1024  # 32 MiB
MAX_LOG_AGE_SEC = 14 * 86400  # 14 days
FSYNC_SAMPLE_INTERVAL = 10

_host_rail_lock = threading.Lock()
_global_sampler: Optional["HostSampler"] = None


def clamp_interval(val: Any) -> int:
    """Clamps sample interval to [15, 300] seconds, default 60."""
    try:
        sec = int(val)
        return max(MIN_HOST_SAMPLE_SEC, min(MAX_HOST_SAMPLE_SEC, sec))
    except (ValueError, TypeError):
        return DEFAULT_HOST_SAMPLE_SEC


def read_host_governor() -> str:
    """Reads scaling governor from sysfs cpu0 or returns unknown."""
    gov_path = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
    if os.path.isfile(gov_path):
        try:
            with open(gov_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    return content
        except OSError:
            pass
    return "unknown"


def read_logical_cpus() -> int:
    """Returns logical CPU count on host."""
    return os.cpu_count() or 1


class HostSampler:
    def __init__(self, log_file: str = "/var/lib/neutrino/host.jsonl", interval_sec: int = 60, cfg: Optional[Dict[str, Any]] = None):
        self.log_file = log_file
        self.born_file = f"{self.log_file}.born"
        self._cfg = cfg
        self.interval_sec = clamp_interval(interval_sec)
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._sample_count = 0
        self._fsync_counter = 0
        self._file_born: Optional[float] = None

    @property
    def sample_count(self) -> int:
        return self._sample_count

    @property
    def is_active(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def _get_or_init_born(self) -> Optional[float]:
        if self._file_born is not None:
            return self._file_born
        if os.path.isfile(self.born_file):
            try:
                with open(self.born_file, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        self._file_born = float(content)
                        return self._file_born
            except (OSError, ValueError):
                pass
        if os.path.isfile(self.log_file):
            try:
                st = os.stat(self.log_file)
                born = getattr(st, "st_birthtime", None) or st.st_ctime or time.time()
                self._record_born(born)
                return self._file_born
            except OSError:
                pass
        return None

    def _record_born(self, born_ts: float):
        self._file_born = float(born_ts)
        try:
            with open(self.born_file, "w", encoding="utf-8") as f:
                f.write(f"{born_ts:.3f}\n")
            try:
                os.chmod(self.born_file, 0o640)
            except OSError:
                pass
            try:
                gid = grp.getgrnam("neutrino").gr_gid
                os.chown(self.born_file, -1, gid)
            except Exception:
                pass
        except OSError:
            pass

    def _rotate_if_needed(self):
        if not os.path.isfile(self.log_file):
            return
        try:
            st = os.stat(self.log_file)
            size_trigger = st.st_size >= MAX_LOG_SIZE_BYTES
            born = self._get_or_init_born()
            now = time.time()
            age_trigger = born is not None and (now - born) >= MAX_LOG_AGE_SEC
            if size_trigger or age_trigger:
                rot_path = f"{self.log_file}.1"
                os.replace(self.log_file, rot_path)
                self._file_born = None
                try:
                    if os.path.isfile(self.born_file):
                        os.unlink(self.born_file)
                except OSError:
                    pass
        except OSError:
            pass

    def _append_record(self, record: Dict[str, Any]):
        with _host_rail_lock:
            self._rotate_if_needed()
            parent = os.path.dirname(self.log_file)
            if parent:
                try:
                    os.makedirs(parent, mode=0o750, exist_ok=True)
                except OSError:
                    pass

            created_new = not os.path.exists(self.log_file)
            if created_new:
                self._record_born(time.time())

            line = json.dumps(record, separators=(",", ":")) + "\n"
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write(line)
                    f.flush()
                    if created_new:
                        try:
                            os.chmod(self.log_file, 0o640)
                        except OSError:
                            pass
                        try:
                            gid = grp.getgrnam("neutrino").gr_gid
                            os.chown(self.log_file, -1, gid)
                        except Exception:
                            pass
                    self._sample_count += 1
                    self._fsync_counter += 1
                    if self._fsync_counter >= FSYNC_SAMPLE_INTERVAL:
                        try:
                            os.fsync(f.fileno())
                        except OSError:
                            pass
                        self._fsync_counter = 0
            except OSError:
                pass

    def _read_all_domain_uj(self, packages: Optional[Dict[str, Any]] = None) -> Dict[str, Tuple[Optional[int], Optional[int]]]:
        if packages is None:
            packages = find_rapl_packages()
        res = {}
        for entry_id, info in packages.items():
            name = info.get("name", entry_id)
            energy_file = info.get("energy_file")
            max_range = info.get("max_energy_range_uj")
            uj = None
            if energy_file and os.path.isfile(energy_file):
                try:
                    with open(energy_file, "r", encoding="utf-8") as f:
                        uj = int(f.read().strip())
                except (OSError, ValueError):
                    pass
            res[name] = (uj, max_range)
        return res

    def _loop(self):
        packages = find_rapl_packages()
        prev_uj, max_range_uj = read_package_rapl_energy()
        prev_mono = time.monotonic()
        prev_domains = self._read_all_domain_uj(packages)

        while not self._stop_event.is_set():
            if self._stop_event.wait(timeout=float(self.interval_sec)):
                break

            # 60s host-rail tick: re-check paper and ensure Autopilot is armed
            if self._cfg:
                try:
                    from neutrino.apply.manager import ensure_autopilot
                    ensure_autopilot(cfg=self._cfg)
                except Exception:
                    pass

            curr_mono = time.monotonic()
            dt_s = round(curr_mono - prev_mono, 2)
            if dt_s <= 0:
                prev_mono = curr_mono
                continue

            packages = find_rapl_packages()
            curr_uj, curr_max_range = read_package_rapl_energy()
            curr_domains = self._read_all_domain_uj(packages)
            rapl_present = bool(packages)
            rapl_readable = curr_uj is not None and prev_uj is not None

            if not rapl_readable:
                record = {
                    "ts": round(time.time(), 3),
                    "dt_s": dt_s,
                    "rail": "rapl-host",
                    "rapl_present": rapl_present,
                    "rapl_readable": False,
                    "energy_pkg_j": 0.0,
                    "p_pkg_w": 0.0,
                    "governor": read_host_governor(),
                    "logical_cpus": read_logical_cpus(),
                    "domains_power_w": {},
                }
                self._append_record(record)
                prev_uj = curr_uj
                prev_mono = curr_mono
                prev_domains = curr_domains
                continue

            # Compute interval delta
            max_r = curr_max_range if curr_max_range else max_range_uj
            energy_pkg_j = compute_counter_delta_j(prev_uj, curr_uj, max_range_uj=max_r)
            if energy_pkg_j < 0:
                # Drop sample on counter delta anomaly
                prev_uj = curr_uj
                prev_mono = curr_mono
                prev_domains = curr_domains
                continue

            p_pkg_w = round(energy_pkg_j / dt_s, 2) if dt_s >= 1.0 else 0.0

            # Compute subdomain powers
            domains_power_w: Dict[str, float] = {}
            for dom_name, (c_uj, c_max) in curr_domains.items():
                if dom_name in prev_domains:
                    p_uj, p_max = prev_domains[dom_name]
                    if c_uj is not None and p_uj is not None:
                        d_max = c_max or p_max
                        d_energy_j = compute_counter_delta_j(p_uj, c_uj, max_range_uj=d_max)
                        if d_energy_j >= 0 and dt_s >= 1.0:
                            domains_power_w[dom_name] = round(d_energy_j / dt_s, 2)

            record = {
                "ts": round(time.time(), 3),
                "dt_s": dt_s,
                "rail": "rapl-host",
                "rapl_present": rapl_present,
                "rapl_readable": True,
                "energy_pkg_j": energy_pkg_j,
                "p_pkg_w": p_pkg_w,
                "governor": read_host_governor(),
                "logical_cpus": read_logical_cpus(),
                "domains_power_w": domains_power_w,
            }
            self._append_record(record)

            prev_uj = curr_uj
            prev_mono = curr_mono
            prev_domains = curr_domains
            max_range_uj = curr_max_range

    def start(self):
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._loop, name="neutrino-host-rail", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        # Flush on shutdown
        if os.path.isfile(self.log_file):
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.flush()
                    os.fsync(f.fileno())
            except OSError:
                pass


def start_host_rail(cfg: Dict[str, Any]) -> Optional[HostSampler]:
    global _global_sampler
    with _host_rail_lock:
        if not cfg.get("host_log_enable", True):
            return None
        log_file = cfg.get("host_log", "/var/lib/neutrino/host.jsonl")
        interval_sec = cfg.get("host_sample_sec", DEFAULT_HOST_SAMPLE_SEC)
        sampler = HostSampler(log_file=log_file, interval_sec=interval_sec, cfg=cfg)
        sampler.start()
        _global_sampler = sampler
        return sampler


def stop_host_rail():
    global _global_sampler
    with _host_rail_lock:
        if _global_sampler:
            _global_sampler.stop()
            _global_sampler = None


def get_host_rail_status() -> Tuple[bool, int]:
    global _global_sampler
    with _host_rail_lock:
        if _global_sampler:
            return _global_sampler.is_active, _global_sampler.sample_count
        return False, 0
