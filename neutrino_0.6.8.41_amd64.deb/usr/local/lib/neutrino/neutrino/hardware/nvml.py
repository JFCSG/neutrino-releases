"""
nvml.py - NVIDIA Management Library (NVML) interface for GPU energy rail.
Uses ctypes to bind libnvidia-ml.so dynamically. Zero external dependencies.
FORBIDDEN:
- Any call to mutation functions (no clock or power mutations).
- Modifying GPU persistence, governors, or power limits.
Standard library only.
"""

import ctypes
import os
from typing import Dict, Any, Optional, Tuple

_NVML_LIB = None
_NVML_INITED = False
_GPU_COUNT = 0
_INIT_ATTEMPTED = False


def _find_libnvml() -> Optional[str]:
    custom_path = os.environ.get("LIBNVML_PATH")
    if custom_path and os.path.isfile(custom_path):
        return custom_path
    candidates = [
        "libnvidia-ml.so.1",
        "/usr/lib/x86_64-linux-gnu/libnvidia-ml.so",
        "/usr/lib/x86_64-linux-gnu/libnvidia-ml.so.1",
        "/usr/lib64/libnvidia-ml.so.1",
        "libnvidia-ml.so",
    ]
    for c in candidates:
        try:
            lib = ctypes.CDLL(c)
            if lib:
                return c
        except Exception:
            continue
    return None


def _init_nvml():
    global _NVML_LIB, _NVML_INITED, _GPU_COUNT, _INIT_ATTEMPTED
    if _INIT_ATTEMPTED:
        return
    _INIT_ATTEMPTED = True

    lib_path = _find_libnvml()
    if not lib_path:
        return

    try:
        lib = ctypes.CDLL(lib_path)
        init_fn = getattr(lib, "nvmlInit_v2", getattr(lib, "nvmlInit", None))
        if not init_fn or init_fn() != 0:
            return

        _NVML_LIB = lib
        _NVML_INITED = True

        count = ctypes.c_uint()
        get_count = getattr(lib, "nvmlDeviceGetCount_v2", getattr(lib, "nvmlDeviceGetCount", None))
        if get_count and get_count(ctypes.byref(count)) == 0:
            _GPU_COUNT = int(count.value)
        else:
            _GPU_COUNT = 0
    except Exception:
        _NVML_LIB = None
        _NVML_INITED = False
        _GPU_COUNT = 0


def is_nvml_readable() -> bool:
    """Returns True if NVML is initialized and at least one device is accessible."""
    _init_nvml()
    return bool(_NVML_INITED and _GPU_COUNT > 0)


def get_gpu_count() -> int:
    """Returns number of accessible NVIDIA GPUs."""
    _init_nvml()
    return _GPU_COUNT


def read_gpu_energy_mj() -> Tuple[Optional[int], int]:
    """
    Reads cumulative GPU energy consumption across all devices in millijoules (mJ).
    Returns (total_energy_mj, device_count).
    Returns (None, 0) if NVML is unavailable or fails closed.
    """
    _init_nvml()
    if not _NVML_INITED or not _NVML_LIB or _GPU_COUNT == 0:
        return (None, 0)

    try:
        get_handle = getattr(_NVML_LIB, "nvmlDeviceGetHandleByIndex_v2", getattr(_NVML_LIB, "nvmlDeviceGetHandleByIndex", None))
        get_energy = getattr(_NVML_LIB, "nvmlDeviceGetTotalEnergyConsumption", None)
        if not get_handle or not get_energy:
            return (None, _GPU_COUNT)

        total_mj = 0
        read_success = 0
        for i in range(_GPU_COUNT):
            dev = ctypes.c_void_p()
            if get_handle(ctypes.c_uint(i), ctypes.byref(dev)) != 0:
                continue
            energy = ctypes.c_ulonglong()
            if get_energy(dev, ctypes.byref(energy)) == 0:
                total_mj += int(energy.value)
                read_success += 1

        if read_success > 0:
            return (total_mj, read_success)
        return (None, _GPU_COUNT)
    except Exception:
        return (None, _GPU_COUNT)


def read_gpu_power_w() -> Tuple[Optional[float], int]:
    """
    Reads instantaneous GPU power consumption across all devices in Watts.
    Returns (total_power_w, device_count).
    FOR LOGS ONLY: Do not integrate power for job energy.
    """
    _init_nvml()
    if not _NVML_INITED or not _NVML_LIB or _GPU_COUNT == 0:
        return (None, 0)

    try:
        get_handle = getattr(_NVML_LIB, "nvmlDeviceGetHandleByIndex_v2", getattr(_NVML_LIB, "nvmlDeviceGetHandleByIndex", None))
        get_power = getattr(_NVML_LIB, "nvmlDeviceGetPowerUsage", None)
        if not get_handle or not get_power:
            return (None, _GPU_COUNT)

        total_mw = 0
        read_success = 0
        for i in range(_GPU_COUNT):
            dev = ctypes.c_void_p()
            if get_handle(ctypes.c_uint(i), ctypes.byref(dev)) != 0:
                continue
            pwr = ctypes.c_uint()
            if get_power(dev, ctypes.byref(pwr)) == 0:
                total_mw += int(pwr.value)
                read_success += 1

        if read_success > 0:
            return (round(total_mw / 1000.0, 3), read_success)
        return (None, _GPU_COUNT)
    except Exception:
        return (None, _GPU_COUNT)


def compute_gpu_counter_delta_j(start_mj: Optional[int], stop_mj: Optional[int]) -> Optional[float]:
    """
    Computes energy delta in Joules from mJ start and stop counters.
    Handles 64-bit counter rollover:
    If stop < start: (stop + 2^64) - start. NEVER + 2^32.
    """
    if start_mj is None or stop_mj is None:
        return None
    if stop_mj >= start_mj:
        diff_mj = stop_mj - start_mj
    else:
        # 64-bit rollover
        diff_mj = (stop_mj + (1 << 64)) - start_mj
    return round(diff_mj / 1000.0, 3)


# Compatibility functions previously in nvml_stub.py
def is_gpu_present() -> bool:
    """Returns True if NVIDIA GPU / driver is accessible."""
    return is_nvml_readable()


def gpu_energy_mj() -> Optional[int]:
    """Returns total energy consumption in millijoules or None if absent."""
    mj, _ = read_gpu_energy_mj()
    return mj


def gpu_telemetry_snapshot() -> Dict[str, Any]:
    """Returns power and device count snapshot or empty dict."""
    pwr, cnt = read_gpu_power_w()
    if pwr is not None:
        return {"power_w": pwr, "device_count": cnt}
    return {}
