"""
probe.py - Non-destructive pre-flight hardware, port, systemd, and conflict inspection.
Outputs structured JSON status (ok, warn, fail).
Standard library only. Zero external dependencies.
"""

import json
import os
import shutil
import socket
import subprocess
import sys
import urllib.request
from typing import Dict, Any

from neutrino.hardware.rapl import read_package_rapl_energy, read_dram_rapl_energy


def check_rapl() -> Dict[str, Any]:
    uj, _ = read_package_rapl_energy()
    if uj is not None:
        return {"status": "ok", "message": f"RAPL Package counter readable ({uj} uJ)"}
    if os.path.isdir("/sys/class/powercap"):
        return {"status": "warn", "message": "RAPL powercap exists but energy_uj is unreadable (udev rule/group neutrino will be installed, non-blocking)"}
    return {"status": "warn", "message": "RAPL powercap not exposed by hardware kernel (/sys/class/powercap absent, non-blocking)"}


def check_dram_rapl() -> Dict[str, Any]:
    uj, _ = read_dram_rapl_energy()
    if uj is not None:
        return {"status": "ok", "message": f"DRAM RAPL counter readable ({uj} uJ)"}
    return {"status": "warn", "message": "DRAM RAPL counter not exposed by hardware sysfs (DRAM energy omitted, non-blocking)"}


def check_gpu(require_gpu: bool = False) -> Dict[str, Any]:
    if shutil.which("nvidia-smi"):
        try:
            res = subprocess.run(
                ["nvidia-smi", "-L"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3,
            )
            if res.returncode == 0 and res.stdout.strip():
                first_line = res.stdout.strip().splitlines()[0]
                return {"status": "ok", "message": f"NVIDIA GPU / driver detected: {first_line}"}
        except Exception:
            pass
    if require_gpu:
        return {"status": "fail", "message": "NVIDIA GPU requested but nvidia-smi failed or unavailable"}
    return {"status": "ok", "message": "NVIDIA GPU not detected (CPU-only observe mode active, non-blocking)"}


def check_disk_space(path: str = "/var/lib", min_mb: int = 500) -> Dict[str, Any]:
    p = path
    while not os.path.exists(p):
        p = os.path.dirname(p)
    try:
        usage = shutil.disk_usage(p)
        free_mb = usage.free // (1024 * 1024)
        if free_mb >= min_mb:
            return {"status": "ok", "message": f"{free_mb} MB free in {p} (>= {min_mb} MB required)"}
        return {"status": "fail", "message": f"Insufficient disk space in {p}: {free_mb} MB free (< {min_mb} MB required)"}
    except OSError as e:
        return {"status": "fail", "message": f"Unable to check disk space in {p}: {e}"}


def check_python_version() -> Dict[str, Any]:
    v = sys.version_info
    v_str = f"{v.major}.{v.minor}.{v.micro}"
    if v >= (3, 8):
        return {"status": "ok", "message": f"Python {v_str} supported (>= 3.8)"}
    return {"status": "fail", "message": f"Python {v_str} unsupported (< 3.8)"}


def check_systemd() -> Dict[str, Any]:
    if os.path.isdir("/run/systemd/system"):
        return {"status": "ok", "message": "systemd runtime detected"}
    # Check if systemctl binary exists
    if shutil.which("systemctl"):
        return {"status": "warn", "message": "systemctl binary present but /run/systemd/system absent"}
    return {"status": "fail", "message": "systemd not detected on host"}


def check_port_8741(bind_ip: str = "127.0.0.1", port: int = 8741) -> Dict[str, Any]:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((bind_ip, port))
        s.close()
        return {"status": "ok", "message": f"{bind_ip}:{port} is available"}
    except OSError as e:
        s.close()
        # Check if our own neutrino.service is actively running and holding the port
        if shutil.which("systemctl"):
            try:
                res = subprocess.run(
                    ["systemctl", "is-active", "neutrino.service"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=3,
                )
                if res.stdout.strip() == "active":
                    # Verify the endpoint responds with healthy JSON (do NOT pin a specific version)
                    try:
                        req = urllib.request.Request(f"http://{bind_ip}:{port}/health")
                        with urllib.request.urlopen(req, timeout=1.0) as resp:
                            if resp.status == 200:
                                body = resp.read().decode("utf-8")
                                data = json.loads(body)
                                if data.get("status") == "ok":
                                    return {
                                        "status": "ok",
                                        "message": f"{bind_ip}:{port} held by active neutrino.service (self-verified)",
                                    }
                    except Exception:
                        pass
            except Exception:
                pass
        return {"status": "fail", "message": f"{bind_ip}:{port} is already in use: {e}"}


def check_legacy_conflict() -> Dict[str, Any]:
    """
    Ensures legacy energisaver_dim is not active or contesting resources.
    Must fail closed if legacy daemon is currently active.
    """
    # Check running process / systemd service
    if shutil.which("systemctl"):
        try:
            res = subprocess.run(
                ["systemctl", "is-active", "energisaver_dim"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3,
            )
            if res.stdout.strip() == "active":
                return {
                    "status": "fail",
                    "message": "Legacy service energisaver_dim is currently ACTIVE. Run neutrino-setup with --migrate-from-legacy or stop energisaver_dim first.",
                }
        except Exception:
            pass

    # Check running process name directly
    if os.path.isdir("/proc"):
        try:
            for pid in os.listdir("/proc"):
                if not pid.isdigit():
                    continue
                try:
                    with open(f"/proc/{pid}/cmdline", "rb") as f:
                        cmd = f.read().decode("utf-8", errors="ignore")
                        if "energisaver_dim_agent" in cmd or "energisaver_dim.service" in cmd:
                            return {
                                "status": "fail",
                                "message": f"Detected running legacy energisaver_dim process (PID {pid}). Must be stopped before Neutrino initialization.",
                            }
                except OSError:
                    pass
        except Exception:
            pass

    return {"status": "ok", "message": "No legacy energisaver_dim active conflict detected"}


def check_governor() -> Dict[str, Any]:
    gov_path = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
    if os.path.isfile(gov_path):
        try:
            with open(gov_path, "r", encoding="utf-8") as f:
                gov = f.read().strip()
            return {"status": "ok", "message": f"CPU0 governor: {gov}", "governor": gov}
        except OSError:
            pass
    return {"status": "warn", "message": "CPU scaling governor sysfs not readable (non-blocking)"}


def check_libkltu_dlopen() -> Dict[str, Any]:
    """Checks whether libkltu shared object can be loaded via ctypes."""
    import ctypes
    candidate_paths = [
        "/opt/neutrino/lib/libkltu_v3.so",
        os.path.join(os.path.dirname(__file__), "..", "..", "third_party", "kltu", "libkltu_v3.so"),
        os.path.join("/usr/local/lib/neutrino", "third_party", "kltu", "libkltu_v3.so"),
    ]
    for p in candidate_paths:
        norm_p = os.path.normpath(p)
        if os.path.isfile(norm_p):
            try:
                lib = ctypes.CDLL(norm_p, mode=getattr(os, "RTLD_LAZY", 1))
                if hasattr(lib, "kltu_dsa16_verify_l3"):
                    return {"status": "ok", "message": f"libkltu dlopen verified: {norm_p} (kltu_dsa16_verify_l3 present)"}
            except Exception as e:
                return {"status": "fail", "message": f"libkltu dlopen error ({norm_p}): {e}"}
    return {"status": "warn", "message": "libkltu_v3.so not yet installed at /opt/neutrino/lib/libkltu_v3.so (will be deployed during install)"}


def check_bind_loopback() -> Dict[str, Any]:
    """Verifies that loopback address 127.0.0.1 is available for binding."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        return {"status": "ok", "message": f"Loopback bind verified on 127.0.0.1:{port}"}
    except OSError as e:
        return {"status": "fail", "message": f"Failed binding loopback 127.0.0.1: {e}"}


def check_whiptail() -> Dict[str, Any]:
    if shutil.which("whiptail"):
        return {"status": "ok", "message": "whiptail/newt present for TUI installation"}
    return {"status": "warn", "message": "whiptail not installed; installation must proceed in headless (--unattended) mode"}


def run_preflight(require_gpu: bool = False, bind_ip: str = "127.0.0.1", port: int = 8741) -> Dict[str, Any]:
    """
    Executes full pre-flight suite and produces standard JSON report.
    """
    checks = {
        "systemd": check_systemd(),
        "python": check_python_version(),
        "rapl": check_rapl(),
        "libkltu": check_libkltu_dlopen(),
        "bind_loopback": check_bind_loopback(),
        "port_8741": check_port_8741(bind_ip, port),
        "disk_space": check_disk_space(),
        "legacy_conflict": check_legacy_conflict(),
        "dram_rapl": check_dram_rapl(),
        "governor": check_governor(),
        "whiptail": check_whiptail(),
        "gpu": check_gpu(require_gpu=require_gpu),
    }

    fail_count = sum(1 for v in checks.values() if v.get("status") == "fail")
    warn_count = sum(1 for v in checks.values() if v.get("status") == "warn")

    return {
        "ok": fail_count == 0,
        "fail_count": fail_count,
        "warn_count": warn_count,
        "checks": checks,
    }
