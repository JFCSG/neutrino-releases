"""
tracker.py - Telemetry aggregation, job ledger summaries, and local tracker rollups.
Standard library only. Zero external dependencies.
"""

import json
import os
from typing import Dict, Any, List


def load_jobs(jobs_file: str) -> List[Dict[str, Any]]:
    jobs = []
    if not os.path.isfile(jobs_file):
        return jobs
    try:
        with open(jobs_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    jobs.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except OSError:
        pass
    return jobs


def compute_tracker_rollup(jobs_file: str) -> Dict[str, Any]:
    """
    Summarizes ledger by job class:
      - count (all jobs)
      - sum_energy_j (all jobs)
      - sum_energy_gpu_j (all jobs if GPU energy present)
      - mean_power_w (only jobs with t >= 1.0s, else None)
      - mean_elapsed_s (all jobs)
      - power_count_ge_1s (count of jobs with t >= 1.0s)
    """
    jobs = load_jobs(jobs_file)
    classes_data: Dict[str, Dict[str, Any]] = {}

    total_jobs = len(jobs)
    total_energy_j = 0.0
    total_energy_gpu_j = 0.0

    for j in jobs:
        c = j.get("class", "unspecified")
        e = float(j.get("energy_j", 0.0))
        p = float(j.get("p_mean_w", 0.0))
        t = float(j.get("t_elapsed_s", 0.0))
        eg = j.get("energy_gpu_j")
        eg_val = float(eg) if eg is not None else 0.0

        total_energy_j += e
        total_energy_gpu_j += eg_val

        if c not in classes_data:
            classes_data[c] = {
                "count": 0,
                "sum_energy_j": 0.0,
                "sum_energy_gpu_j": 0.0,
                "has_gpu_energy": False,
                "sum_power_w": 0.0,
                "power_count": 0,
                "sum_time_s": 0.0,
            }

        st = classes_data[c]
        st["count"] += 1
        st["sum_energy_j"] += e
        if eg is not None:
            st["sum_energy_gpu_j"] += eg_val
            st["has_gpu_energy"] = True
        st["sum_time_s"] += t

        # Sub-second runs (t < 1.0s) stay in ledger and count/energy sums,
        # but are excluded from mean_power_w to eliminate short-job noise.
        if t >= 1.0:
            st["sum_power_w"] += p
            st["power_count"] += 1

    summary_by_class = {}
    for c, st in classes_data.items():
        cnt = st["count"]
        p_cnt = st["power_count"]
        class_summary = {
            "count": cnt,
            "sum_energy_j": round(st["sum_energy_j"], 2),
            "mean_energy_j": round(st["sum_energy_j"] / cnt, 2) if cnt > 0 else 0.0,
            "mean_power_w": round(st["sum_power_w"] / p_cnt, 2) if p_cnt > 0 else None,
            "mean_elapsed_s": round(st["sum_time_s"] / cnt, 2) if cnt > 0 else 0.0,
            "power_count_ge_1s": p_cnt,
        }
        if st["has_gpu_energy"]:
            class_summary["sum_energy_gpu_j"] = round(st["sum_energy_gpu_j"], 2)
        summary_by_class[c] = class_summary

    res = {
        "total_jobs": total_jobs,
        "total_energy_j": round(total_energy_j, 2),
        "classes": summary_by_class,
    }
    if total_energy_gpu_j > 0.0:
        res["total_energy_gpu_j"] = round(total_energy_gpu_j, 2)
    return res


def format_tracker_table(rollup: Dict[str, Any]) -> str:
    """Formats ASCII table for neutrino status CLI output."""
    lines = [
        "-------------------------------------------------------------------------------",
        f"Neutrino Job Ledger Tracker  (Total Jobs: {rollup.get('total_jobs', 0)}, Total Energy: {rollup.get('total_energy_j', 0.0)} J)",
        "-------------------------------------------------------------------------------",
        f"{'Class':<14} {'Count':<8} {'Total Energy (J)':<18} {'Mean Power (W)':<16} {'Mean Time (s)':<14}",
        "-------------------------------------------------------------------------------",
    ]
    classes = rollup.get("classes", {})
    if not classes:
        lines.append("  (No recorded jobs in ledger yet)")
    else:
        for c, st in sorted(classes.items()):
            p_val = st.get("mean_power_w")
            p_str = f"{p_val:<16.2f}" if p_val is not None else f"{'n/a (<1s)':<16}"
            lines.append(
                f"{c:<14} {st['count']:<8} {st['sum_energy_j']:<18.2f} {p_str} {st['mean_elapsed_s']:<14.2f}"
            )
    lines.append("-------------------------------------------------------------------------------")
    return "\n".join(lines)
