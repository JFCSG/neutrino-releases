"""
export.py - Checksummed telemetry export pack (JSONL / CSV) with SHA-256 sidecar.
Filters to method: uj_delta only.
Supports time-window filtering via since / until.
Redacts tokens, node.sk, and signatures to prevent credential leakage.
Standard library only. Zero external dependencies.
"""

import csv
import hashlib
import io
import json
import os
from typing import Dict, Any, List, Optional, Tuple

CSV_COLUMNS = [
    "id",
    "class",
    "rail",
    "t_start",
    "t_stop",
    "t_elapsed_s",
    "energy_j",
    "energy_pkg_j",
    "energy_dram_j",
    "energy_gpu_j",
    "p_mean_w",
    "n_samples",
    "method",
    "host_fingerprint",
    "scheduler",
    "sched_job_id",
    "cpus",
    "energy_per_core_hour_j",
    "unit_name",
    "unit_count",
    "energy_per_unit_j",
    "version_id",
]

SENSITIVE_KEYS = {
    "token",
    "secret",
    "node.sk",
    "lease.sig",
    "voucher.sig",
    "signature",
    "sig",
}


def parse_timestamp(val: Any) -> Optional[float]:
    """Parses float/int timestamp or ISO-8601 string into unix epoch seconds."""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        val = val.strip()
        if not val:
            return None
        try:
            return float(val)
        except ValueError:
            pass
        try:
            from datetime import datetime
            iso_str = val.replace("Z", "+00:00")
            dt = datetime.fromisoformat(iso_str)
            return dt.timestamp()
        except Exception:
            pass
    return None


def sanitize_record_for_export(record: Dict[str, Any]) -> Dict[str, Any]:
    """
    Sanitizes job record for export pack.
    Redacts tokens, secret keys (*.sk, node.sk), signatures, and lease.sig.
    Ensures zero secret leakage.
    """
    clean: Dict[str, Any] = {}
    for k, v in record.items():
        k_lower = k.lower()
        if k_lower in SENSITIVE_KEYS or k_lower.endswith(".sk"):
            continue
        if "signature" in k_lower or k_lower == "sig":
            continue

        if isinstance(v, dict):
            clean[k] = _sanitize_dict(v)
        elif isinstance(v, list):
            clean[k] = [_sanitize_item(item) for item in v]
        elif isinstance(v, str):
            clean[k] = _scrub_string(v)
        else:
            clean[k] = v
    return clean


def _sanitize_dict(d: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in d.items():
        k_lower = k.lower()
        if k_lower in SENSITIVE_KEYS or k_lower.endswith(".sk"):
            continue
        if "signature" in k_lower or k_lower == "sig" or "token" in k_lower or "secret" in k_lower:
            continue
        if isinstance(v, dict):
            out[k] = _sanitize_dict(v)
        elif isinstance(v, list):
            out[k] = [_sanitize_item(item) for item in v]
        elif isinstance(v, str):
            out[k] = _scrub_string(v)
        else:
            out[k] = v
    return out


def _sanitize_item(item: Any) -> Any:
    if isinstance(item, dict):
        return _sanitize_dict(item)
    if isinstance(item, list):
        return [_sanitize_item(i) for i in item]
    if isinstance(item, str):
        return _scrub_string(item)
    return item


def _scrub_string(s: str) -> str:
    if any(secret in s for secret in ("token", "lease.sig", "voucher.sig", "node.sk")):
        return "[REDACTED]"
    if s.endswith(".sk"):
        return "[REDACTED]"
    return s


def export_jobs(
    jobs_file: str,
    fmt: str = "jsonl",
    since: Optional[float] = None,
    until: Optional[float] = None,
) -> Tuple[bytes, str]:
    """
    Exports jobs from jobs_file in jsonl or csv format.
    Filters to method == 'uj_delta' only.
    Filters to t_start >= since (if specified) and t_stop <= until (if specified).
    Sanitizes records to prevent secret leaks (token, node.sk, signatures, lease.sig).
    Returns (body_bytes, sha256_hex).
    """
    records: List[Dict[str, Any]] = []
    if os.path.isfile(jobs_file):
        try:
            with open(jobs_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    # Filter 1: method must be 'uj_delta'
                    if rec.get("method") != "uj_delta":
                        continue

                    # Filter 2: since (t_start >= since)
                    t_start = rec.get("t_start")
                    if since is not None and t_start is not None:
                        try:
                            if float(t_start) < since:
                                continue
                        except (ValueError, TypeError):
                            pass

                    # Filter 3: until (t_stop <= until)
                    t_stop = rec.get("t_stop")
                    if until is not None and t_stop is not None:
                        try:
                            if float(t_stop) > until:
                                continue
                        except (ValueError, TypeError):
                            pass

                    records.append(sanitize_record_for_export(rec))
        except OSError:
            pass

    fmt = fmt.lower()
    if fmt == "csv":
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS, extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        for r in records:
            row: Dict[str, Any] = {}
            for col in CSV_COLUMNS:
                val = r.get(col)
                if val is None and col == "version_id":
                    val = r.get("policy", {}).get("version_id", "")
                if val is None:
                    row[col] = ""
                else:
                    row[col] = val
            writer.writerow(row)
        body_bytes = output.getvalue().encode("utf-8")
    else:
        lines = [json.dumps(r, separators=(",", ":")) for r in records]
        body_bytes = ("\n".join(lines) + "\n").encode("utf-8") if lines else b""

    sha256_hex = hashlib.sha256(body_bytes).hexdigest()
    return body_bytes, sha256_hex



HOST_CSV_COLUMNS = [
    "ts",
    "dt_s",
    "rail",
    "rapl_present",
    "rapl_readable",
    "energy_pkg_j",
    "p_pkg_w",
    "governor",
    "logical_cpus",
    "domains_power_w",
]


def export_host(
    host_file: str,
    fmt: str = "jsonl",
    since: Optional[float] = None,
    until: Optional[float] = None,
) -> Tuple[bytes, str]:
    """
    Exports host rail samples from host_file in jsonl or csv format.
    Filters to ts >= since (if specified) and ts <= until (if specified).
    Sanitizes records to prevent secret leaks (no tokens, node.sk, signatures, lease.sig).
    Does not export raw counter uj_raw.
    Returns (body_bytes, sha256_hex).
    """
    records: List[Dict[str, Any]] = []
    if os.path.isfile(host_file):
        try:
            with open(host_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    ts = rec.get("ts")
                    if since is not None and ts is not None:
                        try:
                            if float(ts) < since:
                                continue
                        except (ValueError, TypeError):
                            pass

                    if until is not None and ts is not None:
                        try:
                            if float(ts) > until:
                                continue
                        except (ValueError, TypeError):
                            pass

                    clean = sanitize_record_for_export(rec)
                    clean.pop("uj_raw", None)
                    records.append(clean)
        except OSError:
            pass

    fmt = fmt.lower()
    if fmt == "csv":
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=HOST_CSV_COLUMNS, extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        for r in records:
            row: Dict[str, Any] = {}
            for col in HOST_CSV_COLUMNS:
                val = r.get(col)
                if isinstance(val, dict):
                    val = json.dumps(val)
                elif val is None:
                    val = ""
                row[col] = val
            writer.writerow(row)
        body_bytes = output.getvalue().encode("utf-8")
    else:
        lines = [json.dumps(r, separators=(",", ":")) for r in records]
        body_bytes = ("\n".join(lines) + "\n").encode("utf-8") if lines else b""

    sha256_hex = hashlib.sha256(body_bytes).hexdigest()
    return body_bytes, sha256_hex
