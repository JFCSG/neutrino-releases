"""
classify.py - Workload argv classifier for Neutrino.
Infers high-confidence workload class from command-line arguments when --class is unspecified.
Standard library only. Zero external dependencies.
"""

import os
import re
from typing import List, Optional

PYTHON_BIN_RE = re.compile(r"^python([23](\.[0-9]+)?)?(\.exe)?$", re.IGNORECASE)

# 1. Idle (never wrap)
IDLE_BINARIES = {"sleep", "true"}

# 2. Compilers and build systems
COMPILER_DRIVERS = {"gcc", "g++", "clang", "clang++", "cc", "c++"}
SOURCE_EXTENSIONS = (".c", ".cc", ".cpp", ".cxx")
BUILD_BINARIES = {"make", "ninja"}

# 3. OLTP clients and helpers
OLTP_BINARIES = {"sqlite", "sqlite3", "psql", "mysql", "redis-cli", "neutrino-oltp-load"}

# 4. Message queues
MQ_BINARIES = {"kafka", "kafka-server-start", "kafka-server-start.sh", "mosquitto", "rabbitmq-server", "neutrino-mq-append"}

# 5. HPC launchers
HPC_BINARIES = {"srun", "neutrino-srun", "mpirun", "mpiexec"}


def classify_argv(cmd: Optional[List[str]]) -> str:
    """
    Classifies a command-line invocation into a workload class.
    Deterministic token and suffix matching.
    Fails closed to 'unspecified' for all unknown, excluded, or ambiguous invocations.
    """
    if not cmd or not isinstance(cmd, (list, tuple)):
        return "unspecified"

    tokens = [str(t).strip() for t in cmd if str(t).strip()]
    if not tokens:
        return "unspecified"

    base = os.path.basename(tokens[0]).lower()

    # 1. Idle (never wrap): sleep, true
    if base in IDLE_BINARIES:
        return "idle"

    # 2. Compilers and build systems:
    # compileall, .c/.cc/.cpp + gcc|g++|clang, make, ninja, cargo build -> compile
    if base in ("compileall", "py_compile"):
        return "compile"

    if PYTHON_BIN_RE.match(base):
        for idx, arg in enumerate(tokens[1:]):
            if arg == "--":
                break
            if arg == "-m":
                if idx + 2 < len(tokens):
                    mod = tokens[idx + 2].strip()
                    if mod in ("compileall", "py_compile"):
                        return "compile"
            elif arg.startswith("-m"):
                mod = arg[2:].strip()
                if mod in ("compileall", "py_compile"):
                    return "compile"
            elif not arg.startswith("-"):
                script_base = os.path.basename(arg).lower()
                if script_base in ("compileall.py", "py_compile.py"):
                    return "compile"
                break

    if base in COMPILER_DRIVERS:
        for t in tokens[1:]:
            if t.lower().endswith(SOURCE_EXTENSIONS):
                return "compile"

    if base in BUILD_BINARIES:
        return "compile"

    if base == "cargo" and len(tokens) > 1 and tokens[1].lower() == "build":
        return "compile"

    # 3. infer-cpu: conservative match on numpy / matrix / infer-campaign invocations
    if PYTHON_BIN_RE.match(base):
        joined_cmd = " ".join(tokens).lower()
        if any(k in joined_cmd for k in ("numpy", "matrix", "infer_bench", "infer-cpu", "infer_eval")):
            return "infer-cpu"

    # 4. OLTP: sqlite, psql, mysql, redis-cli
    if base in OLTP_BINARIES or any(base.startswith(p) for p in ("sqlite", "psql", "mysql", "redis-cli")):
        return "oltp"

    # 5. MQ: kafka, rabbit, mosquitto, explicit helper
    if base in MQ_BINARIES or any(k in base for k in ("kafka", "rabbit", "mosquitto")):
        return "mq"

    # 6. HPC: slurm / neutrino-srun default
    if base in HPC_BINARIES:
        return "hpc"

    return "unspecified"
