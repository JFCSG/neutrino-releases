"""
schema.py - Neutrino Job Schema v1 and validation contracts.
Enforces method: uj_delta, hash of machine-id, and single primary rail.
Standard library only. Zero external dependencies.
"""

import hashlib
import re
from typing import Dict, Any, Optional

from neutrino.crypto.license import get_machine_id_hash

JOB_ID_REGEX = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
JOB_CLASS_REGEX = re.compile(r"^[A-Za-z0-9._-]{1,64}$")

VALID_RAILS = {
    "rapl-pkg",
    "rapl-dram",
    "nvml",
    "cheap",
    "dear",
    "compile",
}

OPTIONAL_COMPILE_FIELDS = (
    "ccache_present",
    "ccache_hits",
    "ccache_misses",
    "ccache_hit_rate",
    "compile_backend",
)

OPTIONAL_AGENT_FIELDS = (
    "agent_detected",
    "agent_dialect",
    "turn_class",
    "rail",
    "session_key",
    "prefix_hash",
    "prefix_tok",
    "suffix_tok",
    "prompt_tok",
    "completion_tok",
    "cached_tok",
    "cache_miss_tok",
    "cache_prompt_injected",
    "cache_control_injected",
    "prefix_hit",
    "prefix_break_reason",
    "dump_flag",
    "dump_tok",
    "dump_repeats",
    "dump_suspect",
    "dump_reason",
    "proposed_action",
    "dump_mutated",
    "dump_bytes_in",
    "dump_bytes_out",
    "compile_suspect",
    "compile_reason",
    "compile_mutated",
    "compile_handoff",
    "compile_applied",
    "spawn_ran",
    "spawn_reason",
    "spawn_exit",
    "holdout",
    "proposed_cap",
    "cap_mutated",
    "quality_ok",
    "prompt_ms",
    "predicted_ms",
    "decode_cap_applied",
    "cap_used",
)


def compute_blake2b_hash(data: bytes) -> str:
    """Computes standard blake2b hex digest via standard library hashlib."""
    return hashlib.blake2b(data, digest_size=32).hexdigest()


def create_job_record(
    job_id: str,
    job_class: str,
    rail: str,
    t_start: float,
    t_stop: float,
    energy_pkg_j: Optional[float] = None,
    energy_dram_j: Optional[float] = None,
    energy_gpu_j: Optional[float] = None,
    gpu_method: Optional[str] = None,
    n_samples: int = 0,
    policy: Optional[Dict[str, Any]] = None,
    payload_hash: Optional[str] = None,
    scheduler: Optional[str] = None,
    sched_job_id: Optional[str] = None,
    cpus: Optional[int] = None,
    unit_name: Optional[str] = None,
    unit_count: Optional[float] = None,
    execution: Optional[str] = None,
    holdout: Optional[bool] = None,
    ccache_present: Optional[bool] = None,
    ccache_hits: Optional[int] = None,
    ccache_misses: Optional[int] = None,
    ccache_hit_rate: Optional[float] = None,
    compile_backend: Optional[str] = None,
    agent_detected: Optional[bool] = None,
    agent_dialect: Optional[str] = None,
    turn_class: Optional[str] = None,
    session_key: Optional[str] = None,
    prefix_hash: Optional[str] = None,
    prefix_tok: Optional[int] = None,
    suffix_tok: Optional[int] = None,
    prompt_tok: Optional[int] = None,
    completion_tok: Optional[int] = None,
    cached_tok: Optional[int] = None,
    cache_miss_tok: Optional[int] = None,
    cache_prompt_injected: Optional[bool] = None,
    cache_control_injected: Optional[bool] = None,
    prefix_hit: Optional[bool] = None,
    prefix_break_reason: Optional[str] = None,
    dump_flag: Optional[bool] = None,
    dump_tok: Optional[int] = None,
    dump_repeats: Optional[int] = None,
    dump_suspect: Optional[bool] = None,
    dump_reason: Optional[str] = None,
    proposed_action: Optional[str] = None,
    dump_mutated: Optional[bool] = None,
    dump_bytes_in: Optional[int] = None,
    dump_bytes_out: Optional[int] = None,
    compile_suspect: Optional[bool] = None,
    compile_reason: Optional[str] = None,
    compile_mutated: Optional[bool] = None,
    compile_handoff: Optional[bool] = None,
    compile_applied: Optional[bool] = None,
    spawn_ran: Optional[bool] = None,
    spawn_reason: Optional[str] = None,
    spawn_exit: Optional[int] = None,
    proposed_cap: Optional[int] = None,
    cap_mutated: Optional[bool] = None,
    quality_ok: Optional[bool] = None,
    prompt_ms: Optional[float] = None,
    predicted_ms: Optional[float] = None,
    decode_cap_applied: Optional[bool] = None,
    cap_used: Optional[int] = None,
    **kwargs: Any,
) -> Dict[str, Any]:
    """
    Constructs and validates standard Job Record v1.
    Primary invariant:
    If rail == nvml, energy_j == energy_gpu_j.
    Otherwise, energy_j == energy_pkg_j.
    Package and GPU energies are NEVER summed together.
    """
    if not JOB_ID_REGEX.match(job_id):
        raise ValueError(f"Invalid job id {job_id}: must match [A-Za-z0-9._-]{{1,64}}")

    if isinstance(job_class, str) and JOB_CLASS_REGEX.match(job_class):
        normalized_class = job_class.lower()
    else:
        normalized_class = "unspecified"

    normalized_rail = rail if rail in VALID_RAILS else "rapl-pkg"

    t_elapsed = round(max(0.001, t_stop - t_start), 3)

    if normalized_rail == "nvml" and energy_gpu_j is not None:
        primary_energy = energy_gpu_j
    elif energy_pkg_j is not None:
        primary_energy = energy_pkg_j
    else:
        primary_energy = 0.0

    p_mean = round(primary_energy / t_elapsed, 3)

    # HPC & Unit normalization metrics
    energy_per_core_hour_j = None
    if cpus is not None and cpus > 0 and t_elapsed > 0:
        energy_per_core_hour_j = round(primary_energy / (cpus * t_elapsed / 3600.0), 3)

    energy_per_unit_j = None
    if unit_count is not None and unit_count > 0:
        energy_per_unit_j = round(primary_energy / float(unit_count), 3)

    policy_dict = dict(policy or {})
    for forbidden in ("outbound_body", "messages", "tools", "system", "prompt"):
        policy_dict.pop(forbidden, None)
    effective_execution = str(execution) if execution is not None else policy_dict.get("execution")
    if effective_execution and "execution" not in policy_dict:
        policy_dict["execution"] = effective_execution
    if cpus is not None and "cpus" not in policy_dict:
        policy_dict["cpus"] = int(cpus)

    if gpu_method is not None:
        eff_gpu_method = gpu_method
    elif energy_gpu_j is not None:
        eff_gpu_method = "nvml_mj_delta"
    else:
        eff_gpu_method = "none"

    record = {
        "id": job_id,
        "class": normalized_class,
        "rail": normalized_rail,
        "t_start": round(t_start, 3),
        "t_stop": round(t_stop, 3),
        "t_elapsed_s": t_elapsed,
        "energy_j": primary_energy,
        "energy_pkg_j": energy_pkg_j,
        "energy_dram_j": energy_dram_j,
        "energy_gpu_j": energy_gpu_j,
        "p_mean_w": p_mean,
        "n_samples": n_samples,
        "method": "uj_delta",
        "gpu_method": eff_gpu_method,
        "hash": payload_hash,
        "policy": policy_dict,
        "execution": effective_execution,
        "host_fingerprint": get_machine_id_hash(),
        "scheduler": str(scheduler) if scheduler is not None else None,
        "sched_job_id": str(sched_job_id) if sched_job_id is not None else None,
        "cpus": int(cpus) if cpus is not None else None,
        "energy_per_core_hour_j": energy_per_core_hour_j,
        "unit_name": str(unit_name) if unit_name is not None else None,
        "unit_count": float(unit_count) if unit_count is not None else None,
        "energy_per_unit_j": energy_per_unit_j,
    }
    if holdout is True or policy_dict.get("holdout") is True:
        record["holdout"] = True
    elif holdout is False:
        record["holdout"] = False

    # Optional compile / ccache fields
    cp = ccache_present if ccache_present is not None else kwargs.get("ccache_present")
    if cp is not None:
        record["ccache_present"] = bool(cp)

    ch = ccache_hits if ccache_hits is not None else kwargs.get("ccache_hits")
    if ch is not None:
        record["ccache_hits"] = int(ch)

    cm = ccache_misses if ccache_misses is not None else kwargs.get("ccache_misses")
    if cm is not None:
        record["ccache_misses"] = int(cm)

    chr_ = ccache_hit_rate if ccache_hit_rate is not None else kwargs.get("ccache_hit_rate")
    if chr_ is not None:
        record["ccache_hit_rate"] = float(chr_)

    cb = compile_backend if compile_backend is not None else kwargs.get("compile_backend")
    if cb is not None:
        record["compile_backend"] = str(cb)

    # Optional agent fields
    agent_vals = {
        "agent_detected": agent_detected if agent_detected is not None else kwargs.get("agent_detected"),
        "agent_dialect": agent_dialect if agent_dialect is not None else kwargs.get("agent_dialect"),
        "turn_class": turn_class if turn_class is not None else kwargs.get("turn_class"),
        "session_key": session_key if session_key is not None else kwargs.get("session_key"),
        "prefix_hash": prefix_hash if prefix_hash is not None else kwargs.get("prefix_hash"),
        "prefix_tok": prefix_tok if prefix_tok is not None else kwargs.get("prefix_tok"),
        "suffix_tok": suffix_tok if suffix_tok is not None else kwargs.get("suffix_tok"),
        "prompt_tok": prompt_tok if prompt_tok is not None else kwargs.get("prompt_tok"),
        "completion_tok": completion_tok if completion_tok is not None else kwargs.get("completion_tok"),
        "cached_tok": cached_tok if cached_tok is not None else kwargs.get("cached_tok"),
        "cache_miss_tok": cache_miss_tok if cache_miss_tok is not None else kwargs.get("cache_miss_tok"),
        "cache_prompt_injected": cache_prompt_injected if cache_prompt_injected is not None else kwargs.get("cache_prompt_injected"),
        "cache_control_injected": cache_control_injected if cache_control_injected is not None else kwargs.get("cache_control_injected"),
        "prefix_hit": prefix_hit if prefix_hit is not None else kwargs.get("prefix_hit"),
        "prefix_break_reason": prefix_break_reason if prefix_break_reason is not None else kwargs.get("prefix_break_reason"),
        "dump_flag": dump_flag if dump_flag is not None else kwargs.get("dump_flag"),
        "dump_tok": dump_tok if dump_tok is not None else kwargs.get("dump_tok"),
        "dump_repeats": dump_repeats if dump_repeats is not None else kwargs.get("dump_repeats"),
        "dump_suspect": dump_suspect if dump_suspect is not None else kwargs.get("dump_suspect"),
        "dump_reason": dump_reason if dump_reason is not None else kwargs.get("dump_reason"),
        "proposed_action": proposed_action if proposed_action is not None else kwargs.get("proposed_action"),
        "dump_mutated": dump_mutated if dump_mutated is not None else kwargs.get("dump_mutated"),
        "dump_bytes_in": dump_bytes_in if dump_bytes_in is not None else kwargs.get("dump_bytes_in"),
        "dump_bytes_out": dump_bytes_out if dump_bytes_out is not None else kwargs.get("dump_bytes_out"),
        "compile_suspect": compile_suspect if compile_suspect is not None else kwargs.get("compile_suspect"),
        "compile_reason": compile_reason if compile_reason is not None else kwargs.get("compile_reason"),
        "compile_mutated": compile_mutated if compile_mutated is not None else kwargs.get("compile_mutated"),
        "compile_handoff": compile_handoff if compile_handoff is not None else kwargs.get("compile_handoff"),
        "compile_applied": compile_applied if compile_applied is not None else kwargs.get("compile_applied"),
        "spawn_ran": spawn_ran if spawn_ran is not None else kwargs.get("spawn_ran"),
        "spawn_reason": spawn_reason if spawn_reason is not None else kwargs.get("spawn_reason"),
        "spawn_exit": spawn_exit if spawn_exit is not None else kwargs.get("spawn_exit"),
        "proposed_cap": proposed_cap if proposed_cap is not None else kwargs.get("proposed_cap"),
        "cap_mutated": cap_mutated if cap_mutated is not None else kwargs.get("cap_mutated"),
        "quality_ok": quality_ok if quality_ok is not None else kwargs.get("quality_ok"),
        "prompt_ms": prompt_ms if prompt_ms is not None else kwargs.get("prompt_ms"),
        "predicted_ms": predicted_ms if predicted_ms is not None else kwargs.get("predicted_ms"),
        "decode_cap_applied": decode_cap_applied if decode_cap_applied is not None else kwargs.get("decode_cap_applied"),
        "cap_used": cap_used if cap_used is not None else kwargs.get("cap_used"),
    }
    for k, v in agent_vals.items():
        if v is not None:
            record[k] = v

    # Enforce flag consistency: mutated => suspect; not suspect => not mutated
    if record.get("dump_mutated"):
        record["dump_suspect"] = True
    if not record.get("dump_suspect"):
        record["dump_mutated"] = False

    if "agent_rail" in kwargs and kwargs["agent_rail"] is not None:
        record["agent_rail"] = kwargs["agent_rail"]

    return record
