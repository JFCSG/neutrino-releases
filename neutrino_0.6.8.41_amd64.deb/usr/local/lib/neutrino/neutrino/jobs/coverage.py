"""
coverage.py - Autopilot 19+1 coverage state machine and recipe management.
Thin Job Plane compliant:
- Zero imports of capture, apply.manager, installer, agent, urllib.
- Fast file I/O with atomic replace (write tmp + fsync + os.replace).
- Recipe schema (agent-owned):
  {
    "version": 1,
    "classes": {
      "<class>": {
        "covered": true,
        "mode": "covered" | "uncovered",
        "n_since_ref": 0,
        "e_ref_j": 123.4,
        "e_wrap_sum_j": 0.0,
        "e_wrap_n": 0,
        "e_unwrap_sum_j": 0.0,
        "e_unwrap_n": 0,
        "last_delta_pct": -12.0,
        "miss_streak": 0,
        "first_cycle": true,
        "updated_at": 0
      }
    }
  }
"""

import json
import os
import sys
import time
from typing import Dict, Any, Tuple, Optional, List

DEFAULT_RECIPE_PATH = "/etc/neutrino/recipe.json"
DEFAULT_LEASE_PATH = "/etc/neutrino/lease.json"

WRAP_DENY_CLASSES = {"heartbeat", "idle", "unspecified"}
WRAP_DENY_COMMANDS = {"sshd", "ssh", "systemd", "chowon-ui", "neutrino", "neutrino-run", "neutrino-agent"}

DELTA_E_THRESHOLD_PCT = -5.0  # Savings must be <= -5.0%


def is_denylisted(job_class: str, cmd: Optional[List[str]] = None) -> bool:
    if not job_class or str(job_class).strip().lower() in WRAP_DENY_CLASSES:
        return True
    if cmd:
        for arg in cmd:
            if not arg:
                continue
            base = os.path.basename(arg).lower()
            clean = base.split(".")[0] if "." in base else base
            for d in WRAP_DENY_COMMANDS:
                if d in base or d in clean:
                    return True
    return False


def check_lease_apply(cfg: Optional[Dict[str, Any]] = None) -> bool:
    cfg = cfg or {}
    lease_path = cfg.get("lease_json_file", DEFAULT_LEASE_PATH)
    if not os.path.isfile(lease_path):
        return False
    try:
        with open(lease_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return False
        # Lease expiry is the only clock
        now = time.time()
        not_after = data.get("not_after")
        if isinstance(not_after, (int, float)) and now > not_after:
            return False
        claims = data.get("claims", {})
        if not isinstance(claims, dict):
            return False
        return bool(claims.get("apply") is True)
    except Exception:
        return False


def load_recipe(recipe_path: str = DEFAULT_RECIPE_PATH) -> Dict[str, Any]:
    if not os.path.isfile(recipe_path):
        return {"version": 1, "classes": {}}
    try:
        with open(recipe_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {"version": 1, "classes": {}}
        if not isinstance(data.get("classes"), dict):
            data["classes"] = {}
        data.setdefault("version", 1)
        return data
    except Exception:
        return {"version": 1, "classes": {}}


def save_recipe(recipe: Dict[str, Any], recipe_path: str = DEFAULT_RECIPE_PATH) -> None:
    out_dir = os.path.dirname(os.path.abspath(recipe_path)) or "."
    os.makedirs(out_dir, exist_ok=True)
    tmp_path = f"{recipe_path}.tmp.{os.getpid()}"
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(recipe, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, recipe_path)
    except Exception:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        raise


def get_or_create_class_entry(recipe: Dict[str, Any], job_class: str) -> Dict[str, Any]:
    classes = recipe.setdefault("classes", {})
    entry = classes.get(job_class)
    if not isinstance(entry, dict):
        entry = {
            "covered": True,
            "mode": "covered",
            "n_since_ref": 0,
            "e_ref_j": None,
            "e_wrap_sum_j": 0.0,
            "e_wrap_n": 0,
            "e_unwrap_sum_j": 0.0,
            "e_unwrap_n": 0,
            "last_delta_pct": None,
            "miss_streak": 0,
            "first_cycle": True,
            "updated_at": int(time.time()),
        }
        classes[job_class] = entry
    else:
        entry.setdefault("covered", True)
        entry.setdefault("mode", "covered" if entry.get("covered", True) else "uncovered")
        entry.setdefault("n_since_ref", 0)
        entry.setdefault("e_ref_j", None)
        entry.setdefault("e_wrap_sum_j", 0.0)
        entry.setdefault("e_wrap_n", 0)
        entry.setdefault("e_unwrap_sum_j", 0.0)
        entry.setdefault("e_unwrap_n", 0)
        entry.setdefault("last_delta_pct", None)
        entry.setdefault("miss_streak", 0)
        entry.setdefault("first_cycle", entry.get("e_ref_j") is None)
        entry.setdefault("updated_at", int(time.time()))
    return entry


def decide_wrap_before_job(
    job_class: str,
    cmd: Optional[List[str]] = None,
    cfg: Optional[Dict[str, Any]] = None,
) -> Tuple[bool, Optional[Dict[str, Any]]]:
    """
    Wrap decision (neutrino-run / srun / bsub):
    Runtime gate is only licensed_and_armed():
    (a) sku=NEUTRINO source=desk apply=true
    (b) /etc/neutrino/apply.d/autopilot.enabled
    No per-class enabled files required.
    """
    cfg = cfg or {}
    from neutrino.apply.autopilot import licensed_and_armed
    if not licensed_and_armed(cfg):
        return False, None

    if is_denylisted(job_class, cmd):
        return False, None

    apply_dir = cfg.get("apply_dir", "/etc/neutrino/apply.d")
    override_disabled = os.path.join(apply_dir, f"{job_class}.disabled")
    if os.path.isfile(override_disabled):
        return False, None

    from neutrino.recipes.registry import get_recipes_for_class
    matches = get_recipes_for_class(job_class)
    armed_recipes = [r for r in matches if r.get("auto", True) and r.get("rail", "cpu") == "cpu"]
    if not armed_recipes:
        return False, None

    lever = armed_recipes[0]["lever"]
    version_id = "autopilot"
    recipe_ids = [r["id"] for r in armed_recipes]

    conf_file = os.path.join(apply_dir, f"{job_class}.conf")
    if os.path.isfile(conf_file):
        try:
            with open(conf_file, "r", encoding="utf-8") as cf:
                for line in cf:
                    if line.strip().startswith("version_id="):
                        version_id = line.strip().split("=", 1)[1].strip()
                    elif line.strip().startswith("lever="):
                        lever = line.strip().split("=", 1)[1].strip()
        except Exception:
            pass

    recipe_path = cfg.get("recipe_json_file", DEFAULT_RECIPE_PATH)
    recipe = load_recipe(recipe_path)
    entry = get_or_create_class_entry(recipe, job_class)

    n_since_ref = entry.get("n_since_ref", 0)
    covered = bool(entry.get("covered", True))
    e_ref_j = entry.get("e_ref_j")

    is_ref = False
    is_probe = False
    should_wrap = False

    if n_since_ref >= 19:
        if covered:
            should_wrap = False
            is_ref = True
        else:
            should_wrap = True
            is_probe = True
    else:
        if covered:
            if e_ref_j is None and n_since_ref == 0:
                should_wrap = False
                is_ref = True
            else:
                should_wrap = True
        else:
            should_wrap = False

    state_token = {
        "job_class": job_class,
        "recipe_path": recipe_path,
        "should_wrap": should_wrap,
        "is_ref": is_ref,
        "is_probe": is_probe,
        "lever": lever,
        "version_id": version_id,
        "recipes": recipe_ids,
    }
    return should_wrap, state_token


def record_job_and_update_coverage(
    job_class: str,
    duration_s: float,
    energy_pkg_j: float,
    coverage_state: Dict[str, Any],
    cfg: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Called after child execution to record energy and update the 19+1 state machine.
    - t < 1.0s or E <= 0: meter, do not use as ref, do not flip coverage.
    - Updates recipe.json atomically.
    """
    if not coverage_state or not isinstance(coverage_state, dict):
        return

    recipe_path = coverage_state.get("recipe_path") or (cfg.get("recipe_json_file") if cfg else None) or DEFAULT_RECIPE_PATH
    should_wrap = coverage_state.get("should_wrap", False)
    is_ref = coverage_state.get("is_ref", False)
    is_probe = coverage_state.get("is_probe", False)

    # If t < 1.0s or non-positive energy, do not alter reference or flip coverage
    valid_sample = (duration_s >= 1.0 and energy_pkg_j > 0.0)

    recipe = load_recipe(recipe_path)
    entry = get_or_create_class_entry(recipe, job_class)

    n_since_ref = entry.get("n_since_ref", 0)
    covered = bool(entry.get("covered", True))
    first_cycle = bool(entry.get("first_cycle", False))
    miss_streak = entry.get("miss_streak", 0)

    if n_since_ref >= 19:
        # Decision point on 20th job
        if covered and is_ref:
            # End of covered cycle: evaluate wrap mean vs this unwrap reference
            if valid_sample and entry.get("e_wrap_n", 0) > 0:
                wrap_mean = entry["e_wrap_sum_j"] / entry["e_wrap_n"]
                ref = energy_pkg_j
                if ref > 0.0:
                    delta_pct = ((wrap_mean - ref) / ref) * 100.0
                    entry["last_delta_pct"] = round(delta_pct, 1)
                    if delta_pct <= DELTA_E_THRESHOLD_PCT:
                        entry["covered"] = True
                        entry["mode"] = "covered"
                        entry["miss_streak"] = 0
                    else:
                        entry["miss_streak"] = miss_streak + 1
                        if first_cycle or entry["miss_streak"] >= 2:
                            entry["covered"] = False
                            entry["mode"] = "uncovered"
                entry["e_ref_j"] = ref
            # Reset cycle accumulators
            entry["n_since_ref"] = 0
            entry["e_wrap_sum_j"] = 0.0
            entry["e_wrap_n"] = 0
            entry["first_cycle"] = False

        elif (not covered) and is_probe:
            # End of uncovered cycle: evaluate this wrap probe vs unwrap mean
            if valid_sample and entry.get("e_unwrap_n", 0) > 0:
                unwrap_mean = entry["e_unwrap_sum_j"] / entry["e_unwrap_n"]
                probe = energy_pkg_j
                if unwrap_mean > 0.0:
                    delta_pct = ((probe - unwrap_mean) / unwrap_mean) * 100.0
                    entry["last_delta_pct"] = round(delta_pct, 1)
                    if delta_pct <= DELTA_E_THRESHOLD_PCT:
                        entry["covered"] = True
                        entry["mode"] = "covered"
                        entry["miss_streak"] = 0
                    else:
                        entry["covered"] = False
                        entry["mode"] = "uncovered"
                        entry["miss_streak"] = miss_streak + 1
            # Reset cycle accumulators
            entry["n_since_ref"] = 0
            entry["e_unwrap_sum_j"] = 0.0
            entry["e_unwrap_n"] = 0
            entry["first_cycle"] = False
        else:
            entry["n_since_ref"] = 0
    else:
        # Progressing through the 19 jobs
        if is_ref and entry.get("e_ref_j") is None:
            # Bootstrap initial reference from job 1
            if valid_sample:
                entry["e_ref_j"] = energy_pkg_j
            entry["n_since_ref"] = 1
        else:
            if should_wrap:
                if valid_sample:
                    entry["e_wrap_sum_j"] = entry.get("e_wrap_sum_j", 0.0) + energy_pkg_j
                    entry["e_wrap_n"] = entry.get("e_wrap_n", 0) + 1
            else:
                if valid_sample:
                    entry["e_unwrap_sum_j"] = entry.get("e_unwrap_sum_j", 0.0) + energy_pkg_j
                    entry["e_unwrap_n"] = entry.get("e_unwrap_n", 0) + 1
            entry["n_since_ref"] = n_since_ref + 1

    entry["updated_at"] = int(time.time())
    recipe.setdefault("version", 1)
    save_recipe(recipe, recipe_path)
