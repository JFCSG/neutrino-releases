"""
license.py - Neutrino License Interface
Pure DSA-16 L3 paper licensing. Legacy signature modules have been retired.
Standard library only.
"""

import hashlib
import json
import os
from typing import Dict, Any, Optional

from neutrino.config import DEFAULT_LICENSE_PATH


def get_machine_id_hash() -> str:
    """
    Computes an opaque SHA-256 hash of system /etc/machine-id or dbus machine-id.
    Strict rule: Never uses hostname or user account names.
    """
    candidates = ["/etc/machine-id", "/var/lib/dbus/machine-id"]
    for path in candidates:
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        return hashlib.sha256(content.encode("utf-8")).hexdigest()
            except OSError:
                pass
    fallback = "neutrino-node-fallback-machine-id"
    return hashlib.sha256(fallback.encode("utf-8")).hexdigest()


def canonical_claims_bytes(claims: Dict[str, Any]) -> bytes:
    """Canonical, deterministic JSON encoding for signature verification."""
    return json.dumps(claims, sort_keys=True, separators=(",", ":")).encode("utf-8")


def load_license(license_path: Optional[str] = None, public_key_bytes: Optional[bytes] = None) -> Dict[str, Any]:
    """
    Evaluates effective license status via DSA-16 papers.
    """
    from neutrino.crypto.desk_license import load_effective_license
    cfg = {}
    if license_path:
        cfg["license_file"] = license_path
    return load_effective_license(cfg)


def sanitize_license_for_display(license_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Redacts raw cryptographic signatures and returns safe display metadata.
    """
    claims = license_data.get("claims", {})
    return {
        "status": license_data.get("status", "unknown"),
        "reason": license_data.get("reason", ""),
        "org": license_data.get("org", claims.get("org", "Unknown")),
        "sku": license_data.get("sku", "none"),
        "source": license_data.get("source", "none"),
        "node_id": license_data.get("node_id"),
        "pk_sha256": license_data.get("pk_sha256"),
        "not_before": license_data.get("not_before"),
        "not_after": license_data.get("not_after"),
        "features": license_data.get("features", []),
        "apply": license_data.get("apply", False),
        "trial": False,
        "signature": "[REDACTED]",
    }
