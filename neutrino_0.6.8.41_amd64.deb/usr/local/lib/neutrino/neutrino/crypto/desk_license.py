"""
desk_license.py - Neutrino License Desk integration.
Controls:
1. Host identity keypair generation and management (Level 3 DSA-16).
2. Paper validation (lease.json/sig or voucher.json/sig):
   - DSA-16 L3 verify against pinned operator public keys.
   - Pinned hashes: OPERATOR_NEUTRINO_PK_SHA256 (primary) and LEGACY_OPERATOR_PK_SHA256 (dual-accept timebox).
   - Exact SKU check ("NEUTRINO"). Foreign SKUs (e.g. foreign) are never accepted.
   - Node binding via pk_sha256.
   - Validity window checks: not_after >= issued_at, issued_at <= now + 48h skew, now <= not_after.
   - Nonce binding (seen_nonces.jsonl mode 0640, fail closed on error).
3. Signed CRL consumption (crl.json / crl.sig):
   - Verified against pinned operator keys.
   - Revokes apply if lease nonce, node_id, or pk_sha256 is in revocation list.
   - Fails closed (apply=False, crl="bad-sig") if CRL signature or integrity is invalid.
Standard library only. Zero external dependencies.
"""

import hashlib
import json
import os
import time
import uuid
from typing import Dict, Any, Tuple, Optional, List

from neutrino.config import (
    DEFAULT_OPERATOR_PK_PATH,
    DEFAULT_OPERATOR_NEUTRINO_PK_PATH,
    DEFAULT_NODE_PKI_DIR,
    DEFAULT_LEASE_JSON_PATH,
    DEFAULT_LEASE_SIG_PATH,
    DEFAULT_RECIPE_JSON_PATH,
    DEFAULT_RECIPE_SIG_PATH,
    DEFAULT_VOUCHER_JSON_PATH,
    DEFAULT_VOUCHER_SIG_PATH,
    DEFAULT_CRL_JSON_PATH,
    DEFAULT_CRL_SIG_PATH,
    DEFAULT_SEEN_NONCES_PATH,
    DEFAULT_LICENSE_PATH,
)
from neutrino.crypto.kltu_dsa import (
    generate_node_keypair,
    verify_dsa16_l3,
    DSA16_L3_PK_BYTES,
    DSA16_L3_SIG_BYTES,
)

# Operator Public Key Pins (SHA-256)
# Single dedicated Neutrino operator key (dual-accept transition window concluded).
# Foreign SKUs are never accepted.
OPERATOR_NEUTRINO_PK_SHA256 = "3cfaf18e572de32800a128340dd0733b1fdbe4ca95b001ff1acdc0bef0decfd9"
ALLOWED_OPERATOR_PK_HASHES = (OPERATOR_NEUTRINO_PK_SHA256,)

_EPHEMERAL_NODE_IDENTITY: Optional[Dict[str, Any]] = None
_IN_MEMORY_SEEN_NONCES: Dict[str, str] = {}


def canonicalize_json(obj: Dict[str, Any]) -> bytes:
    """Canonical, deterministic JSON encoding for signature verification."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def ensure_node_identity(pki_dir: str = DEFAULT_NODE_PKI_DIR) -> Dict[str, Any]:
    """
    Initializes or loads host node identity.
    Paths under pki_dir:
      - node_id: neutrino-<hex uuid> (mode 0644)
      - node.sk: 0600 root:neutrino
      - node.pk: 0640 root:neutrino
    Strict rule: Never sends or prints node.sk.
    Returns: {"node_id": str, "pk_sha256": str, "node_pk": bytes}
    """
    global _EPHEMERAL_NODE_IDENTITY
    try:
        os.makedirs(pki_dir, mode=0o750, exist_ok=True)
    except OSError:
        pass

    id_path = os.path.join(pki_dir, "node_id")
    sk_path = os.path.join(pki_dir, "node.sk")
    pk_path = os.path.join(pki_dir, "node.pk")

    # If identity exists on disk, load and return
    if os.path.isfile(id_path) and os.path.isfile(pk_path):
        try:
            with open(id_path, "r", encoding="utf-8") as f:
                node_id = f.read().strip()
            with open(pk_path, "rb") as f:
                pk_bytes = f.read()
            if len(pk_bytes) == DSA16_L3_PK_BYTES and node_id:
                pk_sha256 = hashlib.sha256(pk_bytes).hexdigest().lower()
                return {"node_id": node_id, "pk_sha256": pk_sha256, "node_pk": pk_bytes}
        except OSError:
            pass

    if _EPHEMERAL_NODE_IDENTITY is not None:
        return _EPHEMERAL_NODE_IDENTITY

    # Generate new host node keypair
    pk_bytes, sk_bytes = generate_node_keypair()
    node_id = f"neutrino-{uuid.uuid4().hex}"
    pk_sha256 = hashlib.sha256(pk_bytes).hexdigest().lower()

    # Attempt to write to disk if permitted
    try:
        # Write node.sk with 0600
        tmp_sk = f"{sk_path}.tmp.{uuid.uuid4().hex[:8]}"
        with open(tmp_sk, "wb") as f:
            f.write(sk_bytes)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_sk, 0o600)
        try:
            import grp
            gid = grp.getgrnam("neutrino").gr_gid
            os.chown(tmp_sk, 0, gid)
        except Exception:
            pass
        os.replace(tmp_sk, sk_path)

        # Write node.pk with 0640
        tmp_pk = f"{pk_path}.tmp.{uuid.uuid4().hex[:8]}"
        with open(tmp_pk, "wb") as f:
            f.write(pk_bytes)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_pk, 0o640)
        try:
            import grp
            gid = grp.getgrnam("neutrino").gr_gid
            os.chown(tmp_pk, 0, gid)
        except Exception:
            pass
        os.replace(tmp_pk, pk_path)

        # Write node_id with 0644
        tmp_id = f"{id_path}.tmp.{uuid.uuid4().hex[:8]}"
        with open(tmp_id, "w", encoding="utf-8") as f:
            f.write(node_id + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_id, 0o644)
        os.replace(tmp_id, id_path)
    except OSError:
        _EPHEMERAL_NODE_IDENTITY = {"node_id": node_id, "pk_sha256": pk_sha256, "node_pk": pk_bytes}
        return _EPHEMERAL_NODE_IDENTITY

    return {"node_id": node_id, "pk_sha256": pk_sha256, "node_pk": pk_bytes}


def check_and_bind_nonce(seen_nonces_path: str, nonce: str, canonical_body_bytes: bytes, read_only: bool = False, bind: bool = True) -> Tuple[bool, str]:
    """
    Binds sha256(canonical JSON) + nonce on first accept.
    - Same files, same nonce -> VALID (re-verify signature and not_after only).
    - New JSON with a nonce already used on a different body -> REPLAY, reject.
    - New JSON, new nonce -> accept and record to seen_nonces.jsonl (mode 0640).
    Fail-closed on any persistence failure.
    """
    body_sha256 = hashlib.sha256(canonical_body_bytes).hexdigest().lower()
    known_nonces: Dict[str, str] = dict(_IN_MEMORY_SEEN_NONCES)

    # Support reading existing file
    if os.path.isfile(seen_nonces_path):
        try:
            with open(seen_nonces_path, "r", encoding="utf-8") as f:
                for line in f:
                    line_str = line.strip()
                    if not line_str:
                        continue
                    if line_str.startswith("{"):
                        try:
                            rec = json.loads(line_str)
                            k_nonce = rec.get("nonce")
                            k_sha = rec.get("body_sha256")
                            if k_nonce and k_sha:
                                known_nonces[k_nonce] = k_sha.lower()
                        except Exception:
                            pass
                    else:
                        parts = line_str.split()
                        if len(parts) >= 2:
                            known_nonces[parts[0]] = parts[1].lower()
        except OSError:
            pass

    if nonce in known_nonces:
        bound_sha = known_nonces[nonce]
        if bound_sha == body_sha256:
            return True, "Existing bound paper accepted"
        return False, f"Replay rejected: nonce '{nonce}' was previously bound to different paper body ({bound_sha})"

    if not bind:
        return True, "Nonce valid (preview/status unbound)"

    # Record to disk - MUST fail closed on write error unless read_only is True
    parent = os.path.dirname(seen_nonces_path)
    if parent:
        if read_only and not os.access(parent, os.W_OK):
            _IN_MEMORY_SEEN_NONCES[nonce] = body_sha256
            return True, "Nonce verified in-memory (read-only CLI caller)"
        try:
            os.makedirs(parent, mode=0o750, exist_ok=True)
        except OSError as e:
            if read_only:
                _IN_MEMORY_SEEN_NONCES[nonce] = body_sha256
                return True, "Nonce verified in-memory (read-only CLI caller)"
            return False, f"Failed to create PKI seen_nonces directory: {e}"

    rec_obj = {
        "nonce": nonce,
        "body_sha256": body_sha256,
        "ts": int(time.time()),
    }
    record_line = json.dumps(rec_obj, sort_keys=True) + "\n"
    tmp_path = f"{seen_nonces_path}.tmp.{uuid.uuid4().hex[:8]}"
    try:
        existing = b""
        if os.path.isfile(seen_nonces_path):
            with open(seen_nonces_path, "rb") as f:
                existing = f.read()
        with open(tmp_path, "wb") as f:
            f.write(existing + record_line.encode("utf-8"))
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_path, 0o640)
        try:
            import grp
            gid = grp.getgrnam("neutrino").gr_gid
            os.chown(tmp_path, 0, gid)
        except Exception:
            pass
        os.replace(tmp_path, seen_nonces_path)
    except OSError as e:
        if read_only:
            _IN_MEMORY_SEEN_NONCES[nonce] = body_sha256
            return True, "Nonce verified in-memory (read-only CLI caller)"
        return False, f"Nonce persistence failure (fail closed): {e}"

    _IN_MEMORY_SEEN_NONCES[nonce] = body_sha256
    return True, "New nonce bound and recorded"


def load_all_operator_pks(pk_path: Optional[str] = None) -> List[Tuple[bytes, str]]:
    """
    Finds and returns valid operator public keys: list of (pk_bytes, pk_sha256).
    Enforces pinning against ALLOWED_OPERATOR_PK_HASHES.
    """
    candidates = []
    if pk_path:
        candidates.append(pk_path)
    env_path = os.environ.get("OPERATOR_DSA16_PK_PATH")
    if env_path:
        candidates.append(env_path)

    # Shipped system locations
    candidates.append(DEFAULT_OPERATOR_NEUTRINO_PK_PATH)

    # Local repo fallbacks
    repo_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    candidates.append(os.path.join(repo_root, "third_party", "kltu", "operator_neutrino_dsa16_l3.pk"))

    valid_pks: List[Tuple[bytes, str]] = []
    seen_hashes = set()

    for path in candidates:
        if os.path.isfile(path):
            try:
                with open(path, "rb") as f:
                    data = f.read()
                if len(data) == DSA16_L3_PK_BYTES:
                    h = hashlib.sha256(data).hexdigest().lower()
                    if h in ALLOWED_OPERATOR_PK_HASHES and h not in seen_hashes:
                        valid_pks.append((data, h))
                        seen_hashes.add(h)
            except OSError:
                pass

    if not valid_pks:
        raise RuntimeError(
            f"No valid operator DSA-16 public key matching pinned hashes found in candidates: {candidates}"
        )
    return valid_pks


def load_operator_pk(pk_path: Optional[str] = None) -> bytes:
    """Loads primary operator public key (Neutrino key preferred)."""
    pks = load_all_operator_pks(pk_path)
    # Prefer new Neutrino PK if available
    for pk_bytes, pk_hash in pks:
        if pk_hash == OPERATOR_NEUTRINO_PK_SHA256:
            return pk_bytes
    return pks[0][0]


def verify_crl(
    crl_json_path: str,
    crl_sig_path: str,
    valid_operator_pks: List[Tuple[bytes, str]],
) -> Tuple[str, Optional[Dict[str, Any]], str]:
    """
    Evaluates signed CRL.
    Returns: (status, crl_dict, reason)
    status is one of: 'absent', 'ok', 'bad-sig'
    """
    has_json = os.path.isfile(crl_json_path)
    has_sig = os.path.isfile(crl_sig_path)
    if not has_json and not has_sig:
        return "absent", None, "No CRL installed"
    if not has_json or not has_sig:
        return "bad-sig", None, "Incomplete CRL pair (missing json or sig)"

    try:
        with open(crl_json_path, "r", encoding="utf-8") as f:
            crl_data = json.load(f)
        with open(crl_sig_path, "rb") as f:
            crl_sig = f.read()
    except Exception as e:
        return "bad-sig", None, f"Failed to read CRL files: {e}"

    if not isinstance(crl_data, dict) or len(crl_sig) != DSA16_L3_SIG_BYTES:
        return "bad-sig", None, "Invalid CRL structure or signature length"

    if crl_data.get("sku") != "NEUTRINO":
        return "bad-sig", None, f"CRL SKU mismatch: {crl_data.get('sku')}"

    canon_crl = canonicalize_json(crl_data)
    sig_ok = False
    for pk_bytes, pk_hash in valid_operator_pks:
        if verify_dsa16_l3(pk_bytes, canon_crl, crl_sig):
            sig_ok = True
            break

    if not sig_ok:
        return "bad-sig", None, "CRL cryptographic signature verification failed"

    return "ok", crl_data, "CRL signature valid"


def verify_desk_paper(
    paper_json_path: str,
    paper_sig_path: str,
    pki_dir: str = DEFAULT_NODE_PKI_DIR,
    operator_pk_path: Optional[str] = None,
    read_only: bool = False,
    bind_nonce: bool = False,
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Validates a staff-dropped desk paper (lease or voucher).
    Returns: (is_valid, reason, paper_dict)
    """
    if not os.path.isfile(paper_json_path):
        return False, f"Paper JSON not found at {paper_json_path}", {}
    if not os.path.isfile(paper_sig_path):
        return False, f"Paper signature sidecar not found at {paper_sig_path}", {}

    try:
        with open(paper_json_path, "r", encoding="utf-8") as f:
            paper = json.load(f)
    except Exception as e:
        return False, f"Invalid JSON format in paper: {e}", {}

    if not isinstance(paper, dict):
        return False, "Paper structure must be a JSON object", {}

    try:
        with open(paper_sig_path, "rb") as f:
            sig_bytes = f.read()
    except OSError as e:
        return False, f"Unable to read paper signature sidecar: {e}", {}

    if len(sig_bytes) != DSA16_L3_SIG_BYTES:
        return False, f"Invalid signature sidecar length: {len(sig_bytes)} bytes (expected {DSA16_L3_SIG_BYTES})", {}

    # Rule 2: SKU == "NEUTRINO" (reject missing or non-NEUTRINO leases)
    sku = paper.get("sku")
    if sku != "NEUTRINO":
        return False, f"Invalid license paper: sku must be exactly 'NEUTRINO' (found '{sku}')", {}

    # Rule 3: pk_sha256 == sha256(this host node.pk) hex lowercase
    local_id = ensure_node_identity(pki_dir)
    paper_pk_sha = str(paper.get("pk_sha256", "")).strip().lower()
    if paper_pk_sha != local_id["pk_sha256"]:
        return False, f"Host mismatch: paper locked to pk_sha256 {paper_pk_sha[:16]}..., this host is {local_id['pk_sha256'][:16]}...", paper

    # Rule 4: Validity window checks
    now = time.time()
    not_after = paper.get("not_after")
    not_before = paper.get("not_before", 0)
    issued_at = paper.get("issued_at")

    if not isinstance(not_after, (int, float)) or not_after <= 0:
        return False, "Invalid paper: must have finite positive not_after timestamp", paper

    if isinstance(issued_at, (int, float)):
        if not_after < issued_at:
            return False, f"Invalid paper: not_after ({not_after}) is earlier than issued_at ({issued_at})", paper
        if issued_at > now + 172800:
            return False, "Invalid paper: issued_at is too far in future (clock skew > 48h)", paper

    if now > not_after:
        return False, f"License paper expired on {time.ctime(not_after)}", paper

    if isinstance(not_before, (int, float)) and now < not_before:
        return False, f"License paper is not yet active (valid from {time.ctime(not_before)})", paper

    # Rule 5: Nonce binding
    nonce = paper.get("nonce")
    if not nonce or not isinstance(nonce, str):
        return False, "Invalid paper: missing required 'nonce' string", paper

    canonical_msg = canonicalize_json(paper)
    seen_path = os.path.join(pki_dir, "seen_nonces.jsonl")
    nonce_ok, nonce_msg = check_and_bind_nonce(
        seen_path, nonce, canonical_msg, read_only=read_only, bind=bind_nonce
    )
    if not nonce_ok:
        return False, nonce_msg, paper

    # Rule 1: DSA-16 Level 3 signature verification against pinned operator keys
    try:
        valid_pks = load_all_operator_pks(operator_pk_path)
    except Exception as e:
        return False, f"Unable to load valid operator public key: {e}", paper

    sig_valid = False
    for pk_bytes, pk_hash in valid_pks:
        if verify_dsa16_l3(pk_bytes, canonical_msg, sig_bytes):
            sig_valid = True
            break

    if not sig_valid:
        return False, "Cryptographic signature verification failed: signature does not match operator public key", {}

    return True, "Valid DSA-16 Neutrino paper", paper


def verify_recipe_paper(
    recipe_json_path: str,
    recipe_sig_path: Optional[str] = None,
    pki_dir: str = DEFAULT_NODE_PKI_DIR,
    operator_pk_path: Optional[str] = None,
    read_only: bool = False,
    bind_nonce: bool = False,
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Validates recipe state on disk.
    Product rule: Recipe is local coverage map. It NEVER expires. Ignore not_after.
    Desk signature on recipe is optional/legacy.
    """
    if not os.path.isfile(recipe_json_path):
        return False, "recipe paper missing or unsigned; install recipe.json + recipe.sig", {}

    try:
        with open(recipe_json_path, "r", encoding="utf-8") as f:
            recipe = json.load(f)
    except Exception:
        return False, "recipe paper missing or unsigned; install recipe.json + recipe.sig", {}

    if not isinstance(recipe, dict):
        return False, "recipe paper missing or unsigned; install recipe.json + recipe.sig", {}

    # Purpose check (if present)
    purpose = recipe.get("purpose")
    if purpose and purpose != "recipe":
        return False, f"Invalid recipe paper: purpose must be 'recipe' (found '{purpose}')", {}

    # SKU check (if present)
    sku = recipe.get("sku")
    if sku and sku != "NEUTRINO":
        return False, f"Invalid recipe paper: sku must be exactly 'NEUTRINO' (found '{sku}')", {}

    # Node match (if present)
    local_id = ensure_node_identity(pki_dir)
    recipe_pk_sha = str(recipe.get("pk_sha256", "")).strip().lower()
    recipe_node_id = str(recipe.get("node_id", "")).strip()
    if recipe_pk_sha and recipe_pk_sha != local_id["pk_sha256"]:
        return False, f"Host mismatch: recipe locked to pk_sha256 {recipe_pk_sha[:16]}..., this host is {local_id['pk_sha256'][:16]}...", recipe
    if recipe_node_id and recipe_node_id != local_id["node_id"]:
        return False, f"Host mismatch: recipe locked to node_id {recipe_node_id}, this host is {local_id['node_id']}", recipe

    # Classes check: must be dictionary or list
    classes = recipe.get("classes")
    if classes is None or not isinstance(classes, (dict, list, tuple)):
        return False, "recipe paper missing or unsigned; install recipe.json + recipe.sig", {}

    # not_after is ignored for validity (pure metadata; never expires)
    return True, "Valid DSA-16 Neutrino recipe", recipe


def load_effective_license(
    cfg: Optional[Dict[str, Any]] = None,
    read_only: bool = False,
    bind_nonce: Optional[bool] = None,
) -> Dict[str, Any]:
    if bind_nonce is None:
        bind_nonce = not read_only
    """
    Evaluates system license under DSA-16 paper rules:
    1. Valid DSA-16 Neutrino paper -> source of license (sku, claims, expiry).
    2. Signed CRL gate: if CRL signature is bad -> fail closed (apply: False).
       If CRL revokes this paper/node -> apply: False, status: revoked.
    3. Else -> unlicensed / none.
    """
    cfg = cfg or {}
    pki_dir = cfg.get("pki_dir", DEFAULT_NODE_PKI_DIR)
    operator_pk_path = cfg.get("operator_pk_file", DEFAULT_OPERATOR_PK_PATH)
    crl_json_path = cfg.get("crl_json_file", DEFAULT_CRL_JSON_PATH)
    crl_sig_path = cfg.get("crl_sig_file", DEFAULT_CRL_SIG_PATH)
    local_id = ensure_node_identity(pki_dir)

    # Evaluate recipe sidecar
    recipe_json_path = cfg.get("recipe_json_file", DEFAULT_RECIPE_JSON_PATH)
    recipe_sig_path = cfg.get("recipe_sig_file", DEFAULT_RECIPE_SIG_PATH)
    if not os.path.isfile(recipe_json_path) and not read_only:
        try:
            os.makedirs(os.path.dirname(os.path.abspath(recipe_json_path)), exist_ok=True)
            with open(recipe_json_path, "w", encoding="utf-8") as rf:
                from neutrino.recipes import DEFAULT_RECIPE
            json.dump(DEFAULT_RECIPE, rf, indent=2)
        except Exception:
            pass

    r_valid, r_reason, r_recipe = verify_recipe_paper(
        recipe_json_path,
        recipe_sig_path,
        pki_dir=pki_dir,
        operator_pk_path=operator_pk_path,
        read_only=read_only,
        bind_nonce=bind_nonce,
    )

    # 1. Candidate paper pairs (lease or voucher)
    paper_candidates = [
        (
            cfg.get("lease_json_file", DEFAULT_LEASE_JSON_PATH),
            cfg.get("lease_sig_file", DEFAULT_LEASE_SIG_PATH),
        ),
        (
            cfg.get("voucher_json_file", DEFAULT_VOUCHER_JSON_PATH),
            cfg.get("voucher_sig_file", DEFAULT_VOUCHER_SIG_PATH),
        ),
    ]

    recipe_block = {
        "valid": r_valid,
        "reason": r_reason,
        "not_after": r_recipe.get("not_after") if r_valid else None,
        "classes": r_recipe.get("classes", {}) if r_valid else {},
    }

    for json_path, sig_path in paper_candidates:
        if os.path.isfile(json_path) and os.path.isfile(sig_path):
            valid, reason, paper = verify_desk_paper(
                json_path,
                sig_path,
                pki_dir=pki_dir,
                operator_pk_path=operator_pk_path,
                read_only=read_only,
                bind_nonce=bind_nonce,
            )
            if valid:
                claims = paper.get("claims", {})
                apply_granted = (claims.get("apply") is True)
                auto_apply_claim = claims.get("auto_apply", False) if apply_granted else False
                features = list(claims.get("features", []))
                if apply_granted and "apply" not in features:
                    features.append("apply")
                if "tracker" not in features:
                    features.append("tracker")
                if "rail-rapl" not in features:
                    features.append("rail-rapl")

                # Evaluate CRL
                try:
                    operator_pks = load_all_operator_pks(operator_pk_path)
                except Exception:
                    operator_pks = []

                crl_status, crl_data, crl_msg = verify_crl(crl_json_path, crl_sig_path, operator_pks)

                if crl_status == "bad-sig":
                    # Corrupt or forged CRL -> fail closed, revoke apply
                    return {
                        "valid": False,
                        "source": "desk",
                        "status": "invalid",
                        "reason": f"CRL integrity failure: {crl_msg}",
                        "sku": "none",
                        "node_id": local_id["node_id"],
                        "pk_sha256": local_id["pk_sha256"],
                        "claims": {},
                        "features": [f for f in features if f != "apply"],
                        "apply": False,
                        "crl": "bad-sig",
                        "trial": False,
                        "recipe_valid": r_valid,
                        "recipe_reason": r_reason,
                        "recipe_not_after": r_recipe.get("not_after") if r_valid else None,
                        "recipe_classes": r_recipe.get("classes", {}) if r_valid else {},
                        "recipe": recipe_block,
                    }

                elif crl_status == "ok" and crl_data:
                    # Check if this lease / node is revoked
                    is_revoked = False
                    revoke_reason = ""
                    revoked_list = crl_data.get("revoked", [])
                    for rev_entry in revoked_list:
                        r_nonce = rev_entry.get("nonce")
                        r_pk = rev_entry.get("pk_sha256")
                        r_node = rev_entry.get("node_id")
                        if r_nonce:
                            if r_nonce == paper.get("nonce"):
                                is_revoked = True
                                revoke_reason = rev_entry.get("reason", "Revoked by operator")
                                break
                        elif r_pk and r_pk.lower() == local_id["pk_sha256"]:
                            is_revoked = True
                            revoke_reason = rev_entry.get("reason", "Revoked by operator")
                            break
                        elif r_node and r_node == local_id["node_id"]:
                            is_revoked = True
                            revoke_reason = rev_entry.get("reason", "Revoked by operator")
                            break

                    if is_revoked:
                        return {
                            "valid": False,
                            "source": "desk",
                            "status": "revoked",
                            "reason": f"Revoked by signed CRL: {revoke_reason}",
                            "sku": "none",
                            "org": paper.get("org", "Enterprise Customer"),
                            "node_id": local_id["node_id"],
                            "pk_sha256": local_id["pk_sha256"],
                            "not_before": paper.get("not_before"),
                            "not_after": paper.get("not_after"),
                            "claims": claims,
                            "features": [f for f in features if f not in ("apply", "auto_apply")],
                            "apply": False,
                            "auto_apply": False,
                            "crl": "revoked",
                            "trial": False,
                            "paper": paper,
                            "recipe_valid": r_valid,
                            "recipe_reason": r_reason,
                            "recipe_not_after": r_recipe.get("not_after") if r_valid else None,
                            "recipe_classes": r_recipe.get("classes", {}) if r_valid else {},
                            "recipe": recipe_block,
                        }

                # Paper valid, CRL absent or ok (not revoked)
                return {
                    "valid": True,
                    "source": "desk",
                    "status": "valid",
                    "reason": reason,
                    "sku": "NEUTRINO",
                    "org": paper.get("org", "Enterprise Customer"),
                    "node_id": local_id["node_id"],
                    "pk_sha256": local_id["pk_sha256"],
                    "not_before": paper.get("not_before"),
                    "not_after": paper.get("not_after"),
                    "claims": claims,
                    "features": features,
                    "apply": apply_granted,
                    "auto_apply": auto_apply_claim,
                    "crl": crl_status,
                    "trial": False,
                    "paper": paper,
                    "recipe_valid": r_valid,
                    "recipe_reason": r_reason,
                    "recipe_not_after": r_recipe.get("not_after") if r_valid else None,
                    "recipe_classes": r_recipe.get("classes", {}) if r_valid else {},
                    "recipe": recipe_block,
                }
            else:
                return {
                    "valid": False,
                    "source": "desk",
                    "status": "invalid",
                    "reason": reason,
                    "sku": "none",
                    "node_id": local_id["node_id"],
                    "pk_sha256": local_id["pk_sha256"],
                    "claims": {},
                    "features": [],
                    "apply": False,
                    "crl": "absent",
                    "trial": False,
                    "recipe_valid": r_valid,
                    "recipe_reason": r_reason,
                    "recipe_not_after": r_recipe.get("not_after") if r_valid else None,
                    "recipe_classes": r_recipe.get("classes", {}) if r_valid else {},
                    "recipe": recipe_block,
                }

    # No paper found
    return {
        "valid": False,
        "source": "none",
        "status": "missing",
        "reason": "No valid DSA-16 paper (/etc/neutrino/lease.json) found",
        "sku": "none",
        "node_id": local_id["node_id"],
        "pk_sha256": local_id["pk_sha256"],
        "claims": {},
        "features": [],
        "apply": False,
        "crl": "absent",
        "trial": False,
        "recipe_valid": r_valid,
        "recipe_reason": r_reason,
        "recipe_not_after": r_recipe.get("not_after") if r_valid else None,
        "recipe_classes": r_recipe.get("classes", {}) if r_valid else {},
        "recipe": recipe_block,
    }


def is_auto_apply_permitted(lic_dict: Optional[Dict[str, Any]], job_class: str) -> bool:
    """
    Evaluates whether N2 auto-apply is cryptographically authorized for job_class:
    1. License must be valid, status 'valid', sku 'NEUTRINO', apply True.
    2. job_class in ('heartbeat', 'idle') is strictly prohibited.
    3. claims.auto_apply must be:
       - True (bool): grants all savings classes
       - list/tuple: grants if job_class in list
    4. Missing, false, or unparseable fails closed (returns False).
    """
    if not isinstance(lic_dict, dict):
        return False
    if not lic_dict.get("valid") or lic_dict.get("status") != "valid":
        return False
    if lic_dict.get("sku") != "NEUTRINO":
        return False
    if not lic_dict.get("apply"):
        return False
    if job_class in ("heartbeat", "idle"):
        return False

    claims = lic_dict.get("claims", {})
    auto_apply_val = claims.get("auto_apply", lic_dict.get("auto_apply", False))
    if auto_apply_val is True:
        return True
    if isinstance(auto_apply_val, (list, tuple)) and job_class in auto_apply_val:
        return True
    return False


def licensed_apply(root: str = "/", cfg: Optional[Dict[str, Any]] = None, read_only: bool = True, bind_nonce: bool = False) -> bool:
    """
    Single predicate: effective desk paper valid AND sku==NEUTRINO AND apply claim true.
    Must not become an ON-switch: reads only the desk paper.
    If false: observe only. Do not create .enabled. Do not wrap.
    If true: autopilot ON. No second file required to begin.
    """
    cfg_copy = dict(cfg or {})
    if root and root != "/":
        cfg_copy.setdefault("root", root)
        cfg_copy.setdefault("pki_dir", os.path.join(root, "var/lib/neutrino/pki"))
        cfg_copy.setdefault("lease_json_file", os.path.join(root, "etc/neutrino/lease.json"))
        cfg_copy.setdefault("lease_sig_file", os.path.join(root, "etc/neutrino/lease.sig"))
        cfg_copy.setdefault("voucher_json_file", os.path.join(root, "etc/neutrino/voucher.json"))
        cfg_copy.setdefault("voucher_sig_file", os.path.join(root, "etc/neutrino/voucher.sig"))
        cfg_copy.setdefault("crl_json_file", os.path.join(root, "etc/neutrino/crl.json"))
        cfg_copy.setdefault("crl_sig_file", os.path.join(root, "etc/neutrino/crl.sig"))
        cfg_copy.setdefault("operator_pk_file", os.path.join(root, "opt/neutrino/share/neutrino/third_party/kltu/operator_neutrino_dsa16_l3.pk"))

    lic = load_effective_license(cfg_copy, read_only=read_only, bind_nonce=bind_nonce)
    if not lic.get("valid"):
        return False
    if lic.get("status") != "valid":
        return False
    if lic.get("sku") != "NEUTRINO":
        return False
    if lic.get("crl") == "revoked":
        return False
    claims = lic.get("claims", {})
    return bool(lic.get("apply") is True or claims.get("apply") is True)
