"""
kltu_dsa.py - Low-level ctypes bindings for KLTu DSA-16 Level 3.
Security requirements:
- Level 3 verify-only against shipped operator public key.
- Host node keypair generation (random CSPRNG seed).
- Zero operator secret key references or signing APIs.
- Fail closed if shared library cannot be loaded.
Standard library only (ctypes, os). Zero external dependencies.
"""

import ctypes
import os
from typing import Tuple, Optional

# DSA-16 Level 3 Wire & Structure Constants (from kltu_dsa16.h)
DSA16_L3_PK_BYTES = 1184
DSA16_L3_SK_BYTES = 2080
DSA16_L3_SIG_BYTES = 1043
DSA16_L3_SEED_BYTES = 32

DSA16_L3_PK_STRUCT_SIZE = 1568
DSA16_L3_SK_STRUCT_SIZE = 9376

_lib = None


def _resolve_libkltu_path() -> Optional[str]:
    """Resolves path to libkltu shared library in priority order:
    1. env LIBKLTU_PATH if isfile
    2. <repo>/third_party/kltu/libkltu_dsa16_l3.so
    3. /opt/neutrino/lib/libkltu_dsa16_l3.so
    4. same-tree / rollback /opt libkltu_v3.so (Neutrino 15669046… only)
    Fail closed if none. Do not search authenticator or external active dir.
    """
    # 1. env LIBKLTU_PATH if isfile
    env_path = os.environ.get("LIBKLTU_PATH")
    if env_path and os.path.isfile(env_path):
        return env_path

    # Local repository fallback relative to this file
    repo_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    # 2. <repo>/third_party/kltu/libkltu_dsa16_l3.so
    repo_dsa16 = os.path.join(repo_root, "third_party", "kltu", "libkltu_dsa16_l3.so")
    if os.path.isfile(repo_dsa16):
        return repo_dsa16

    # 3. /opt/neutrino/lib/libkltu_dsa16_l3.so
    installed_dsa16 = "/opt/neutrino/lib/libkltu_dsa16_l3.so"
    if os.path.isfile(installed_dsa16):
        return installed_dsa16

    # 4. same-tree / rollback /opt libkltu_v3.so (Neutrino 15669046… only)
    repo_v3 = os.path.join(repo_root, "third_party", "kltu", "libkltu_v3.so")
    if os.path.isfile(repo_v3):
        return repo_v3

    opt_v3 = "/opt/neutrino/lib/libkltu_v3.so"
    if os.path.isfile(opt_v3):
        return opt_v3

    return None


def get_kltu_lib():
    """Loads and binds libkltu_dsa16_l3.so (or rollback libkltu_v3.so). Fails closed if absent."""
    global _lib
    if _lib is not None:
        return _lib

    lib_path = _resolve_libkltu_path()
    if not lib_path or not os.path.isfile(lib_path):
        raise RuntimeError(f"libkltu library not found (resolved: {lib_path})")

    try:
        lib = ctypes.CDLL(lib_path, mode=os.RTLD_LAZY)
    except Exception as e:
        raise RuntimeError(f"Failed to load libkltu from {lib_path}: {e}")

    # Level 3 Keygen (derandomized with 32-byte host CSPRNG seed)
    lib.kltu_dsa16_keygen_derand_l3.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p]
    lib.kltu_dsa16_keygen_derand_l3.restype = ctypes.c_int

    # Level 3 Export
    lib.kltu_dsa16_export_pk_bytes_l3.argtypes = [ctypes.c_char_p, ctypes.c_void_p]
    lib.kltu_dsa16_export_pk_bytes_l3.restype = ctypes.c_int

    lib.kltu_dsa16_export_sk_bytes_l3.argtypes = [ctypes.c_char_p, ctypes.c_void_p]
    lib.kltu_dsa16_export_sk_bytes_l3.restype = ctypes.c_int

    # Level 3 Import
    lib.kltu_dsa16_import_pk_bytes_l3.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    lib.kltu_dsa16_import_pk_bytes_l3.restype = ctypes.c_int

    lib.kltu_dsa16_import_sk_bytes_l3.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    lib.kltu_dsa16_import_sk_bytes_l3.restype = ctypes.c_int

    # Level 3 Verification
    lib.kltu_dsa16_verify_l3.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_size_t,
        ctypes.POINTER(ctypes.c_uint8),
        ctypes.c_size_t,
        ctypes.c_void_p,
    ]
    lib.kltu_dsa16_verify_l3.restype = ctypes.c_int

    _lib = lib
    return _lib


def _make_aligned_buf(size: int, alignment: int = 64) -> Tuple[ctypes.Array, ctypes.c_void_p]:
    """Allocates a buffer aligned to 64 bytes for SIMD operations."""
    raw = ctypes.create_string_buffer(size + alignment)
    addr = ctypes.addressof(raw)
    offset = (alignment - (addr % alignment)) % alignment
    ptr = ctypes.c_void_p(addr + offset)
    return raw, ptr


def generate_node_keypair(seed: Optional[bytes] = None) -> Tuple[bytes, bytes]:
    """
    Generates host node Level 3 keypair.
    Strict rule: Only generates the node's local keypair, never operator keys.
    Returns: (pk_bytes, sk_bytes)
    """
    lib = get_kltu_lib()
    if seed is None:
        seed = os.urandom(DSA16_L3_SEED_BYTES)
    elif len(seed) != DSA16_L3_SEED_BYTES:
        raise ValueError(f"Seed must be exactly {DSA16_L3_SEED_BYTES} bytes")

    raw_pk, pk_struct = _make_aligned_buf(DSA16_L3_PK_STRUCT_SIZE)
    raw_sk, sk_struct = _make_aligned_buf(DSA16_L3_SK_STRUCT_SIZE)

    rc = lib.kltu_dsa16_keygen_derand_l3(pk_struct, sk_struct, seed)
    if rc != 0:
        raise RuntimeError(f"kltu_dsa16_keygen_derand_l3 failed with code {rc}")

    pk_buf = ctypes.create_string_buffer(DSA16_L3_PK_BYTES)
    sk_buf = ctypes.create_string_buffer(DSA16_L3_SK_BYTES)

    rc1 = lib.kltu_dsa16_export_pk_bytes_l3(pk_buf, pk_struct)
    rc2 = lib.kltu_dsa16_export_sk_bytes_l3(sk_buf, sk_struct)
    if rc1 != 0 or rc2 != 0:
        raise RuntimeError(f"Failed to export DSA-16 L3 key bytes (rc_pk={rc1}, rc_sk={rc2})")

    return bytes(pk_buf.raw), bytes(sk_buf.raw)


def verify_dsa16_l3(operator_pk_bytes: bytes, message: bytes, signature: bytes) -> bool:
    """
    Verifies a Level 3 DSA-16 signature against the operator public key.
    Returns True if valid, False otherwise. Fails closed on any error.
    """
    if len(operator_pk_bytes) != DSA16_L3_PK_BYTES:
        return False
    if len(signature) != DSA16_L3_SIG_BYTES:
        return False

    lib = get_kltu_lib()
    raw_pk, pk_struct = _make_aligned_buf(DSA16_L3_PK_STRUCT_SIZE)

    rc_import = lib.kltu_dsa16_import_pk_bytes_l3(pk_struct, operator_pk_bytes)
    if rc_import != 0:
        return False

    sig_arr = (ctypes.c_uint8 * len(signature)).from_buffer_copy(signature)
    msg_arr = (ctypes.c_uint8 * len(message)).from_buffer_copy(message) if len(message) > 0 else None

    rc_verify = lib.kltu_dsa16_verify_l3(
        None,
        None,
        sig_arr,
        len(signature),
        msg_arr,
        len(message),
        pk_struct,
    )
    return rc_verify == 0
