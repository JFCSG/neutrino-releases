"""
pkg_verify.py - Package checksum and detached DSA-16 Level 3 signature verification.
Security requirements:
- Level 3 verify-only against shipped operator public key.
- Validates SHA256 checksums of release packages (.deb, .rpm).
- Fails closed on any corruption, hash mismatch, or signature invalidity.
- Zero secret key references or signing APIs.
"""

import hashlib
import os
from typing import Tuple, Optional

from neutrino.crypto.kltu_dsa import (
    verify_dsa16_l3,
    DSA16_L3_PK_BYTES,
    DSA16_L3_SIG_BYTES,
)

DEFAULT_OPERATOR_NEUTRINO_PK_PATH = "/etc/neutrino/pki/operator_neutrino_dsa16_l3.pk"
DEFAULT_OPERATOR_PK_PATH = DEFAULT_OPERATOR_NEUTRINO_PK_PATH


def _resolve_operator_pk_path(
    explicit_path: Optional[str] = None,
    candidate_dirs: Optional[list] = None,
) -> str:
    """Resolves operator public key path."""
    if explicit_path and os.path.isfile(explicit_path):
        return explicit_path

    if os.path.isfile(DEFAULT_OPERATOR_NEUTRINO_PK_PATH):
        return DEFAULT_OPERATOR_NEUTRINO_PK_PATH

    repo_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    neutrino_pk = os.path.join(repo_root, "third_party", "kltu", "operator_neutrino_dsa16_l3.pk")
    if os.path.isfile(neutrino_pk):
        return neutrino_pk

    dirs = [os.getcwd()]
    if candidate_dirs:
        dirs.extend(candidate_dirs)
    for d in dirs:
        if not d:
            continue
        for name in ("operator_dsa16_l3.pk", "operator_neutrino_dsa16_l3.pk"):
            cand = os.path.join(d, name)
            if os.path.isfile(cand):
                return cand

    return explicit_path or DEFAULT_OPERATOR_PK_PATH


def verify_package(
    deb_path: str,
    sums_path: Optional[str] = None,
    sig_path: Optional[str] = None,
    pk_path: Optional[str] = None,
) -> Tuple[bool, str]:
    """
    Verifies a release package file against SHA256SUMS and its detached DSA-16 Level 3 signature.
    Returns: (is_valid, message)
    """
    if not deb_path or not os.path.isfile(deb_path):
        return False, f"Package file not found: {deb_path}"

    deb_dir = os.path.dirname(os.path.abspath(deb_path))

    # Resolve sums_path
    if not sums_path:
        sums_path = os.path.join(deb_dir, "SHA256SUMS")
    if not os.path.isfile(sums_path):
        return False, f"Checksum manifest file not found: {sums_path}"

    # Resolve sig_path
    if not sig_path:
        sig_path = sums_path + ".sig"
    if not os.path.isfile(sig_path):
        return False, f"Detached signature file not found: {sig_path}"

    # Resolve operator public key
    resolved_pk_path = _resolve_operator_pk_path(pk_path, candidate_dirs=[deb_dir, os.path.dirname(os.path.abspath(sums_path))])
    if not os.path.isfile(resolved_pk_path):
        return False, f"Operator public key not found: {resolved_pk_path}"

    # 1. Read operator public key
    try:
        with open(resolved_pk_path, "rb") as f:
            operator_pk = f.read()
    except OSError as e:
        return False, f"Failed to read operator public key: {e}"

    if len(operator_pk) != DSA16_L3_PK_BYTES:
        return False, f"Invalid operator public key length: {len(operator_pk)} (expected {DSA16_L3_PK_BYTES})"

    # 2. Read checksum manifest and signature
    try:
        with open(sums_path, "rb") as f:
            sums_bytes = f.read()
    except OSError as e:
        return False, f"Failed to read checksum manifest: {e}"

    try:
        with open(sig_path, "rb") as f:
            sig_bytes = f.read()
    except OSError as e:
        return False, f"Failed to read signature file: {e}"

    if len(sig_bytes) != DSA16_L3_SIG_BYTES:
        return False, f"Invalid signature length: {len(sig_bytes)} (expected {DSA16_L3_SIG_BYTES})"

    # 3. Cryptographically verify SHA256SUMS signature
    sig_ok = verify_dsa16_l3(operator_pk, sums_bytes, sig_bytes)
    if not sig_ok:
        return False, "Cryptographic verification failed: SHA256SUMS signature does not match operator key"

    # 4. Compute package SHA-256
    sha256 = hashlib.sha256()
    try:
        with open(deb_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)
    except OSError as e:
        return False, f"Failed to compute package checksum: {e}"

    deb_hash = sha256.hexdigest().lower()
    deb_filename = os.path.basename(deb_path)

    # 5. Parse SHA256SUMS and verify checksum
    try:
        sums_text = sums_bytes.decode("utf-8")
    except UnicodeDecodeError:
        return False, "Checksum manifest is not valid UTF-8 text"

    expected_hash = None
    for line in sums_text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) == 2:
            entry_hash, entry_file = parts[0].lower(), parts[1].lstrip("*")
            if os.path.basename(entry_file) == deb_filename:
                expected_hash = entry_hash
                break

    if expected_hash is None:
        return False, f"Package {deb_filename} not found in verified SHA256SUMS manifest"

    if deb_hash != expected_hash:
        return False, f"Checksum mismatch for {deb_filename}: computed {deb_hash} != manifest {expected_hash}"

    return True, f"Verified package {deb_filename} [SHA-256: {deb_hash}] (DSA-16 Level 3 operator signature OK)"
