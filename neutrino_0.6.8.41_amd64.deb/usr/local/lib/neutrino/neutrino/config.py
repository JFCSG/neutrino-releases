"""
config.py - Neutrino configuration constants, touch-list specifications, and TOML parser.
Standard library only. No external dependencies.
"""

import os
import re

TOUCH_LIST = [
    "/etc/neutrino/",
    "/etc/systemd/system/neutrino.service",
    "/etc/udev/rules.d/99-neutrino-rapl.rules",
    "/etc/sudoers.d/neutrino",
    "/usr/local/lib/neutrino/",
    "/usr/local/bin/neutrino",
    "/usr/local/bin/neutrino-run",
    "/usr/local/bin/neutrino-setup",
    "/usr/local/bin/neutrino-srun",
    "/usr/local/bin/neutrino-bsub",
    "/opt/neutrino/lib/libkltu_dsa16_l3.so",
    "/opt/neutrino/lib/libkltu_v3.so",
    "/etc/neutrino/pki/operator_neutrino_dsa16_l3.pk",
    "/etc/neutrino/pki/operator_dsa16_l3.pk",
    "/etc/neutrino/recipe.json",
    "/etc/neutrino/recipe.sig",
    "/etc/neutrino/crl.json",
    "/etc/neutrino/crl.sig",
    "/var/lib/neutrino/pki/",
    "/var/lib/neutrino/pki/seen_nonces.jsonl",
    "/var/lib/neutrino/staging/",
    "/var/lib/neutrino/catalog/",
    "/var/lib/neutrino/cache/",
    "/var/lib/neutrino/mq/",
    "/var/lib/neutrino/oltp/",
    "/opt/neutrino/shims/",
    "/etc/neutrino/shims.env",
    "/usr/local/bin/neutrino-enable-shims",
    "/etc/neutrino/apply.d/catalog.allow",
    "/etc/systemd/system/<safe-name>.service.d/neutrino.conf",
    "/usr/local/lib/neutrino/attach/",
    "/usr/local/lib/neutrino/attach/bin/",
    "/usr/local/lib/neutrino/attach/bin/make",
    "/usr/local/lib/neutrino/attach/bin/gmake",
    "/usr/local/lib/neutrino/attach/bin/ninja",
    "/usr/local/lib/neutrino/attach/bin/gcc",
    "/usr/local/lib/neutrino/attach/bin/g++",
    "/usr/local/lib/neutrino/attach/bin/python3",
    "/usr/local/lib/neutrino/attach/bin/go",
    "/usr/local/lib/neutrino/attach/bin/cargo",
    "/usr/local/lib/neutrino/attach/bin/gradle",
    "/var/lib/neutrino/attach/",
    "/var/lib/neutrino/attach/coverage.json",
    "/etc/profile.d/neutrino-attach.sh",
    "/usr/local/bin/make",
    "/usr/local/lib/neutrino/attach/bin/gzip",
    "/usr/local/lib/neutrino/attach/bin/xz",
    "/usr/local/lib/neutrino/attach/bin/bzip2",
    "/usr/local/lib/neutrino/attach/bin/sqlite3",
    "/usr/local/lib/neutrino/attach/bin/neutrino-oltp-load",
    "/usr/local/lib/neutrino/attach/bin/neutrino-mq-append",
    "/usr/local/lib/neutrino/attach/bin/neutrino-etl",
    "/etc/neutrino/apply.d/autopilot.enabled",
    "/var/lib/neutrino/apply/revoked.json",
]

LEGACY_TOUCH_LIST = [
    "/etc/energisaver_dim/",
    "/etc/systemd/system/energisaver_dim.service",
    "/etc/udev/rules.d/99-energisaver_dim-rapl.rules",
    "/etc/sudoers.d/energisaver_dim",
    "/usr/local/lib/energisaver_dim/",
    "/usr/local/bin/energisaver_dim",
    "/var/lib/energisaver_dim/",
]

DEFAULT_CONFIG_PATH = "/etc/neutrino/neutrino.toml"
DEFAULT_TOKEN_PATH = "/etc/neutrino/token"
DEFAULT_LICENSE_PATH = "/etc/neutrino/license.sig"
DEFAULT_JOBS_FILE = "/var/lib/neutrino/jobs.jsonl"
DEFAULT_RAPL_LOG_FILE = "/var/lib/neutrino/rapl.jsonl"
DEFAULT_HOST_LOG_FILE = "/var/lib/neutrino/host.jsonl"
DEFAULT_HOST_SAMPLE_SEC = 60
DEFAULT_HOST_LOG_ENABLE = True
DEFAULT_BACKUP_DIR = "/var/lib/neutrino/backup"
DEFAULT_INSTALL_BACKUP_BASE = "/var/lib/neutrino/install-backups"
DEFAULT_ACTUATE_FLAG_FILE = "/etc/neutrino/actuate.enabled"

ATTACH_BIN_DIR = "/usr/local/lib/neutrino/attach/bin"
ATTACH_STATE_DIR = "/var/lib/neutrino/attach"
ATTACH_COVERAGE_FILE = "/var/lib/neutrino/attach/coverage.json"
ATTACH_PROFILE_D = "/etc/profile.d/neutrino-attach.sh"
DEFAULT_ATTACH_POLL_SEC = 1.0
SAVINGS_CLASSES = frozenset({"compile", "infer-cpu", "batch", "oltp", "mq", "hpc", "render"})


DEFAULT_REVOKED_CLASSES_FILE = "/var/lib/neutrino/apply/revoked.json"
DEFAULT_APPLY_DIR = "/etc/neutrino/apply.d"
DEFAULT_APPLY_STATE_DIR = "/var/lib/neutrino/apply"
DEFAULT_APPLY_BACKUP_DIR = "/var/lib/neutrino/backups"
DEFAULT_APPLY_HISTORY_FILE = "/var/lib/neutrino/apply/history.jsonl"

DEFAULT_CATALOG_DIR = "/var/lib/neutrino/catalog"
DEFAULT_CATALOG_FILE = "/var/lib/neutrino/catalog/candidates.jsonl"
DEFAULT_CATALOG_ALLOW_FILE = "/etc/neutrino/apply.d/catalog.allow"
DEFAULT_CACHE_DIR = "/var/lib/neutrino/cache"
DEFAULT_MQ_DIR = "/var/lib/neutrino/mq"
DEFAULT_OLTP_DIR = "/var/lib/neutrino/oltp"
DEFAULT_SHIMS_DIR = "/opt/neutrino/shims"
DEFAULT_SHIMS_ENV_PATH = "/etc/neutrino/shims.env"

DEFAULT_OPERATOR_NEUTRINO_PK_PATH = "/etc/neutrino/pki/operator_neutrino_dsa16_l3.pk"
DEFAULT_OPERATOR_PK_PATH = DEFAULT_OPERATOR_NEUTRINO_PK_PATH
DEFAULT_NODE_PKI_DIR = "/var/lib/neutrino/pki"
DEFAULT_LEASE_JSON_PATH = "/etc/neutrino/lease.json"
DEFAULT_LEASE_SIG_PATH = "/etc/neutrino/lease.sig"
DEFAULT_RECIPE_JSON_PATH = "/etc/neutrino/recipe.json"
DEFAULT_RECIPE_SIG_PATH = "/etc/neutrino/recipe.sig"
DEFAULT_VOUCHER_JSON_PATH = "/etc/neutrino/voucher.json"
DEFAULT_VOUCHER_SIG_PATH = "/etc/neutrino/voucher.sig"
DEFAULT_CRL_JSON_PATH = "/etc/neutrino/crl.json"
DEFAULT_CRL_SIG_PATH = "/etc/neutrino/crl.sig"
DEFAULT_SEEN_NONCES_PATH = "/var/lib/neutrino/pki/seen_nonces.jsonl"
DEFAULT_LIBKLTU_PATH = "/opt/neutrino/lib/libkltu_dsa16_l3.so"

DEFAULT_BIND = "127.0.0.1"
DEFAULT_PORT = 8741
DEFAULT_LOG_INTERVAL_SEC = 60
DEFAULT_UPSTREAM_URL = "http://127.0.0.1:8080"
DEFAULT_AUTOPILOT_SWITCH_DIR = "/etc/neutrino/autopilot"
DEFAULT_AUTOPILOT_SUBSTRATE_DIR = "/var/lib/neutrino/autopilot"
DEFAULT_AUTOPILOT_SUBSTRATE_FILE = "/var/lib/neutrino/autopilot/substrate.json"

DEFAULTS = {
    "bind": DEFAULT_BIND,
    "port": DEFAULT_PORT,
    "mode": "observe",
    "sku": "observe",
    "token_file": DEFAULT_TOKEN_PATH,
    "license_file": DEFAULT_LICENSE_PATH,
    "jobs_file": DEFAULT_JOBS_FILE,
    "log_file": DEFAULT_RAPL_LOG_FILE,
    "log_interval_sec": DEFAULT_LOG_INTERVAL_SEC,
    "host_log": DEFAULT_HOST_LOG_FILE,
    "host_sample_sec": DEFAULT_HOST_SAMPLE_SEC,
    "host_log_enable": DEFAULT_HOST_LOG_ENABLE,
    "hardware_profile": "cpu-mobile",
    "primary_rail": "rapl-pkg",
    "apply_dir": DEFAULT_APPLY_DIR,
    "apply_state_dir": DEFAULT_APPLY_STATE_DIR,
    "apply_backup_dir": DEFAULT_APPLY_BACKUP_DIR,
    "apply_history_file": DEFAULT_APPLY_HISTORY_FILE,
    "apply_revoked_file": DEFAULT_REVOKED_CLASSES_FILE,
    "operator_pk_file": DEFAULT_OPERATOR_PK_PATH,
    "pki_dir": DEFAULT_NODE_PKI_DIR,
    "lease_json_file": DEFAULT_LEASE_JSON_PATH,
    "lease_sig_file": DEFAULT_LEASE_SIG_PATH,
    "recipe_json_file": DEFAULT_RECIPE_JSON_PATH,
    "recipe_sig_file": DEFAULT_RECIPE_SIG_PATH,
    "voucher_json_file": DEFAULT_VOUCHER_JSON_PATH,
    "voucher_sig_file": DEFAULT_VOUCHER_SIG_PATH,
    "crl_json_file": DEFAULT_CRL_JSON_PATH,
    "crl_sig_file": DEFAULT_CRL_SIG_PATH,
    "seen_nonces_file": DEFAULT_SEEN_NONCES_PATH,
    "libkltu_path": DEFAULT_LIBKLTU_PATH,
    "catalog_dir": DEFAULT_CATALOG_DIR,
    "catalog_file": DEFAULT_CATALOG_FILE,
    "catalog_allow_file": DEFAULT_CATALOG_ALLOW_FILE,
    "cache_dir": DEFAULT_CACHE_DIR,
    "mq_dir": DEFAULT_MQ_DIR,
    "oltp_dir": DEFAULT_OLTP_DIR,
    "shims_dir": DEFAULT_SHIMS_DIR,
    "shims_env_path": DEFAULT_SHIMS_ENV_PATH,
    "upstream_url": DEFAULT_UPSTREAM_URL,
    "autopilot_switch_dir": DEFAULT_AUTOPILOT_SWITCH_DIR,
    "autopilot_substrate_file": DEFAULT_AUTOPILOT_SUBSTRATE_FILE,
}


def parse_simple_toml(content: str) -> dict:
    """
    Minimal, robust TOML reader supporting basic key = "value",
    key = 123, key = true/false, and section tables [section].
    Zero dependencies, compatible across all Python 3 versions.
    """
    res = {}
    current_section = res
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            sec_name = line[1:-1].strip()
            res[sec_name] = {}
            current_section = res[sec_name]
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            k = k.strip()
            v = v.strip()
            # Strip inline comments
            if " #" in v:
                v = v.split(" #", 1)[0].strip()
            if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
                val = v[1:-1]
            elif v.startswith("[") and v.endswith("]"):
                items = [x.strip() for x in v[1:-1].split(",") if x.strip()]
                val = [item[1:-1] if (item.startswith('"') and item.endswith('"')) or (item.startswith("'") and item.endswith("'")) else item for item in items]
            elif v.lower() == "true":
                val = True
            elif v.lower() == "false":
                val = False
            elif re.match(r"^-?\d+$", v):
                val = int(v)
            elif re.match(r"^-?\d+\.\d+$", v):
                val = float(v)
            else:
                val = v
            current_section[k] = val
    return res


def load_config(path: str = DEFAULT_CONFIG_PATH) -> dict:
    cfg = dict(DEFAULTS)
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                parsed = parse_simple_toml(f.read())
            # Merge flat and sectioned keys
            for k, v in parsed.items():
                if isinstance(v, dict):
                    cfg[k] = dict(v)
                    for subk, subv in v.items():
                        cfg[f"{k}.{subk}"] = subv
                else:
                    cfg[k] = v
        except Exception:
            pass

    # Strictly enforce loopback safety guardrail
    bind = cfg.get("bind", DEFAULT_BIND)
    if bind not in ("127.0.0.1", "localhost"):
        # Force fallback to loopback unless explicitly overridden by validated signed cert
        cfg["bind"] = DEFAULT_BIND

    return cfg
