"""
vendor.py - Package ownership and vendor detection for Neutrino capture.

Vendor detection rules:
1. Known vendor package names (apt, dpkg, logrotate, sysstat, mdadm, popularity-contest, etc.)
   are always treated as vendor files.
2. Checks vendor path prefixes (/lib, /usr/lib, /usr/share, /snap, /var/lib/snapd, /opt/snap*, /usr/libexec).
3. Strictly zero package-manager queries (no dpkg, rpm, or pacman subprocesses).
4. Supports vendor_manifest test override for test isolation.
"""

import os
from typing import Tuple, Optional, Set

KNOWN_VENDOR_NAMES: Set[str] = {
    "apt",
    "apt-compat",
    "dpkg",
    "logrotate",
    "sysstat",
    "mdadm",
    "popularity-contest",
    "e2scrub_all",
    "man-db",
    "apport",
}

VENDOR_PATH_PREFIXES = (
    "/lib/",
    "/usr/lib/",
    "/usr/share/",
    "/snap/",
    "/var/lib/snapd/",
    "/opt/snap",
    "/usr/libexec/",
)


def package_owns(
    path_spec: str,
    root: str = "/",
    vendor_manifest: Optional[Set[str]] = None,
) -> bool:
    """
    Returns True if the file at path_spec is owned by vendor/system or vendor_manifest.
    Zero calls to dpkg, rpm, or pacman.
    """
    clean_path = str(path_spec or "").strip()
    bname = os.path.basename(clean_path)

    # Resolve system path relative to root
    if root != "/" and clean_path.startswith(root):
        rel = os.path.relpath(clean_path, root)
        sys_path = "/" + rel.lstrip("/")
    else:
        sys_path = clean_path

    # Test / mock manifest override
    if vendor_manifest is not None:
        return (
            clean_path in vendor_manifest
            or sys_path in vendor_manifest
            or bname in vendor_manifest
        )

    if bname in KNOWN_VENDOR_NAMES:
        return True

    for vp in VENDOR_PATH_PREFIXES:
        if sys_path.startswith(vp):
            return True

    return False


def is_vendor_file(
    path_spec: str,
    root: str = "/",
    vendor_manifest: Optional[Set[str]] = None,
) -> Tuple[bool, str]:
    """
    Determines if a file is vendor-owned without package manager subprocesses.
    Returns (is_vendor: bool, reason: str).
    """
    clean_path = str(path_spec or "").strip()
    bname = os.path.basename(clean_path)

    if vendor_manifest is not None:
        if clean_path in vendor_manifest or bname in vendor_manifest:
            return (True, f"vendor_manifest: {bname}")

    if bname in KNOWN_VENDOR_NAMES:
        return (True, f"known_vendor: {bname}")

    if package_owns(clean_path, root=root, vendor_manifest=vendor_manifest):
        return (True, f"vendor_prefix: {bname}")

    return (False, "operator: unowned")
