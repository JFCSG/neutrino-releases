"""
cron.py - Neutrino capture command prefixer and deployer for cron targets.

Controls:
1. Path validation restricted strictly to /etc/cron.d/, /etc/crontab, or /var/spool/cron/crontabs/ under root.
2. Vendor detection via known vendor names and vendor prefixes; fallback for /etc/cron.d/ non-vendor names.
3. Stable ID formula:
   hex8(sha256(path|schedule|user|original-cmd))
4. Prefixing command field only:
   /usr/local/bin/neutrino-run --class <class> --id cron-<stable-id> -- <orig_cmd>
5. Preserving schedule, user, variable assignments, comments, whitespace, and % stdin rules.
6. Byte-identical restore from snapshot including permissions.
Standard library only. Zero external dependencies.
"""

import hashlib
import json
import os
import secrets
import shutil
from typing import Dict, Any, List, Optional, Tuple, Set

from neutrino.capture.recipe import DENY_BASENAMES, check_deny_match
from neutrino.capture.vendor import is_vendor_file

ALLOWED_CRON_PREFIXES = (
    "/etc/cron.d/",
    "/etc/crontab",
    "/var/spool/cron/crontabs/",
)


def validate_cron_path(path_spec: str, root: str = "/") -> str:
    """
    Validates cron path specification.
    Path must start with an allowed prefix and contain no path escape ('..').
    Returns absolute path within root filesystem.
    """
    norm = str(path_spec or "").strip()
    if ".." in norm.split("/") or ".." in norm:
        raise ValueError(f"Cron path '{norm}' contains path escape ('..')")

    matched_prefix = None
    for pfx in ALLOWED_CRON_PREFIXES:
        if norm == pfx or norm.startswith(pfx):
            matched_prefix = pfx
            break

    if not matched_prefix:
        raise ValueError(
            f"Cron path '{norm}' must be /etc/crontab or reside under /etc/cron.d/ or /var/spool/cron/crontabs/"
        )

    rel = norm.lstrip("/")
    return os.path.join(root, rel)


def split_command_and_stdin(full_cmd: str) -> Tuple[str, str]:
    """
    In cron lines, the first unescaped '%' character terminates the command
    and begins standard input.
    Returns (command_part, stdin_part).
    """
    i = 0
    escaped = False
    while i < len(full_cmd):
        c = full_cmd[i]
        if c == "\\" and not escaped:
            escaped = True
            i += 1
            continue
        if c == "%" and not escaped:
            return (full_cmd[:i].rstrip(), full_cmd[i:])
        escaped = False
        i += 1
    return (full_cmd, "")


def compute_cron_stable_id(rel_path: str, schedule: str, user: str, original_cmd: str) -> str:
    """
    stable-id = hex8(sha256(path|schedule|user|original-cmd))
    """
    key = f"{rel_path}|{schedule}|{user}|{original_cmd}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:8]


CRON_ADDITIONAL_DENY: Set[str] = {
    "reboot",
    "shutdown",
    "poweroff",
    "halt",
}


def prefix_cron_command(
    line: str,
    feature_class: str,
    rel_path: str,
    is_user_crontab: bool = False,
    explicit: bool = False,
    deny_set: Optional[Set[str]] = None,
) -> Tuple[str, Optional[str]]:
    """
    Prefixes the command field of a cron line with the neutrino-run wrapper.
    Preserves comments, whitespace, variable assignments, and schedule/user tokens.
    Returns (rewritten_line, stable_id) or (line, None).
    """
    if deny_set is None:
        deny_set = {d.lower() for d in DENY_BASENAMES} | CRON_ADDITIONAL_DENY
    else:
        deny_set = {d.lower() for d in deny_set} | CRON_ADDITIONAL_DENY

    stripped = line.strip()
    if not stripped or stripped.startswith("#") or stripped.startswith(";"):
        return (line, None)

    # Environment assignment (e.g. SHELL=/bin/bash, PATH=..., MAILTO=...)
    if "=" in stripped and not stripped.startswith("@"):
        first_token = stripped.split()[0]
        if "=" in first_token and not any(first_token.startswith(x) for x in ("0","1","2","3","4","5","6","7","8","9","*")):
            return (line, None)

    # If already wrapped, do not double-wrap
    if "/usr/local/bin/neutrino-run" in line:
        return (line, None)

    ends_with_newline = line.endswith("\n")
    work_line = line[:-1] if ends_with_newline else line

    schedule = ""
    user = ""
    full_cmd = ""

    # Format 1: @special schedule
    if stripped.startswith("@"):
        if is_user_crontab:
            parts = work_line.split(None, 1)
            if len(parts) < 2:
                return (line, None)
            schedule, full_cmd = parts
            user = "root"
            prefix_fmt = f"{schedule} "
        else:
            parts = work_line.split(None, 2)
            if len(parts) < 3:
                return (line, None)
            schedule, user, full_cmd = parts
            prefix_fmt = f"{schedule} {user} "
    else:
        # Standard numeric / asterisk schedule
        if is_user_crontab:
            parts = work_line.split(None, 5)
            if len(parts) < 6:
                return (line, None)
            m, h, dom, mon, dow, full_cmd = parts
            schedule = f"{m} {h} {dom} {mon} {dow}"
            user = "root"
            prefix_fmt = f"{schedule} "
        else:
            parts = work_line.split(None, 6)
            if len(parts) < 7:
                return (line, None)
            m, h, dom, mon, dow, user, full_cmd = parts
            schedule = f"{m} {h} {dom} {mon} {dow}"
            prefix_fmt = f"{schedule} {user} "

    cmd_part, stdin_part = split_command_and_stdin(full_cmd)
    orig_cmd = cmd_part.strip()
    if not orig_cmd:
        return (line, None)

    # Deny list check
    first_cmd_tok = orig_cmd.split()[0]
    cmd_base = os.path.basename(first_cmd_tok)
    deny_hit = check_deny_match(cmd_base, deny_set)
    if not deny_hit:
        deny_hit = check_deny_match(orig_cmd, deny_set)

    if deny_hit:
        if explicit:
            raise ValueError(f"Command '{orig_cmd}' matches denied basename '{deny_hit}'")
        return (line, None)

    stable_id = compute_cron_stable_id(rel_path, schedule, user, orig_cmd)
    wrapper = f"/usr/local/bin/neutrino-run --class {feature_class} --id cron-{stable_id} -- {orig_cmd}{stdin_part}"
    new_line = f"{prefix_fmt}{wrapper}"
    if ends_with_newline:
        new_line += "\n"

    return (new_line, stable_id)


def discover_cron_targets(
    root: str = "/",
    include_vendor: bool = True,
    deny_set: Optional[Set[str]] = None,
    vendor_manifest: Optional[Set[str]] = None,
) -> List[Dict[str, Any]]:
    """
    Discovers cron files and candidate lines under root:
    - /etc/cron.d/*
    - /etc/crontab
    - /var/spool/cron/crontabs/root
    """
    if deny_set is None:
        deny_set = {d.lower() for d in DENY_BASENAMES}

    discovered = []
    files_to_check = []

    # 1. /etc/cron.d/*
    crond_dir = os.path.join(root, "etc", "cron.d")
    if os.path.isdir(crond_dir):
        try:
            for entry in sorted(os.listdir(crond_dir)):
                if entry.startswith(".") or entry.endswith("~") or entry.endswith(".bak"):
                    continue
                p = os.path.join(crond_dir, entry)
                if os.path.isfile(p):
                    files_to_check.append((p, False))
        except OSError:
            pass

    # 2. /etc/crontab
    sys_crontab = os.path.join(root, "etc", "crontab")
    if os.path.isfile(sys_crontab):
        files_to_check.append((sys_crontab, False))

    # 3. Root crontab /var/spool/cron/crontabs/root
    root_crontab = os.path.join(root, "var", "spool", "cron", "crontabs", "root")
    if os.path.isfile(root_crontab):
        files_to_check.append((root_crontab, True))

    for abs_path, is_user in files_to_check:
        rel_path = os.path.relpath(abs_path, root)
        clean_sys_path = "/" + rel_path.lstrip("/")
        is_vendor, vendor_reason = is_vendor_file(
            abs_path, root=root, vendor_manifest=vendor_manifest
        )

        try:
            with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except Exception as ex:
            discovered.append({
                "path": clean_sys_path,
                "rel_path": rel_path,
                "is_vendor": is_vendor,
                "status": f"skipped: unreadable ({ex})",
            })
            continue

        active_lines = 0
        wrapped_lines = 0
        denied_lines = 0
        candidate_lines = 0

        for line in lines:
            s = line.strip()
            if not s or s.startswith("#") or s.startswith(";"):
                continue
            if "=" in s and not s.startswith("@"):
                tok = s.split()[0]
                if "=" in tok and not any(tok.startswith(x) for x in ("0","1","2","3","4","5","6","7","8","9","*")):
                    continue
            active_lines += 1
            if "/usr/local/bin/neutrino-run" in s:
                wrapped_lines += 1
                continue

            # Check deny list
            try:
                _, sid = prefix_cron_command(line, "probe", clean_sys_path, is_user_crontab=is_user, deny_set=deny_set)
                if sid:
                    candidate_lines += 1
                else:
                    denied_lines += 1
            except Exception:
                denied_lines += 1

        if active_lines == 0:
            status = "skipped: empty_or_comments"
        elif is_vendor:
            status = f"skipped: {vendor_reason}"
        elif wrapped_lines == active_lines:
            status = "skipped: already_wrapped"
        elif candidate_lines > 0:
            status = "candidate"
        elif denied_lines > 0:
            status = "skipped: denied"
        else:
            status = "candidate"

        discovered.append({
            "path": clean_sys_path,
            "abs_path": abs_path,
            "rel_path": rel_path,
            "is_vendor": is_vendor,
            "vendor_reason": vendor_reason,
            "is_user_crontab": is_user,
            "active_lines": active_lines,
            "wrapped_lines": wrapped_lines,
            "candidate_lines": candidate_lines,
            "status": status,
        })

    return discovered


def make_cron_snapshot_key(clean_sys_path: str) -> str:
    """Creates a sanitized unique snapshot key for a cron path."""
    norm = clean_sys_path.strip().strip("/")
    return norm.replace("/", "_")


def deploy_cron_target(target: Dict[str, Any], root: str = "/") -> Dict[str, Any]:
    """
    Deploys cron wrapping for a single cron file target.
    Backs up original bytes before mutation into /var/lib/neutrino/apply/capture/cron/<key>/.
    Rewrites commands atomically.
    """
    path_spec = str(target.get("path") or target.get("id") or "").strip()
    tclass = str(target.get("class") or "").strip().lower()
    if not tclass:
        raise ValueError("Missing required 'class' for cron target")

    abs_cron_path = validate_cron_path(path_spec, root=root)
    if not os.path.isfile(abs_cron_path):
        raise FileNotFoundError(f"Cron file not found: {abs_cron_path}")

    rel_path = os.path.relpath(abs_cron_path, root)
    clean_sys_path = "/" + rel_path.lstrip("/")
    is_user_crontab = clean_sys_path.startswith("/var/spool/cron/crontabs/")

    with open(abs_cron_path, "rb") as f:
        orig_bytes = f.read()

    orig_sha = hashlib.sha256(orig_bytes).hexdigest()
    st = os.stat(abs_cron_path)

    target_id = str(target.get("id") or "").strip()
    if not target_id:
        target_id = make_cron_snapshot_key(clean_sys_path)

    snapshot_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", target_id)
    os.makedirs(snapshot_dir, exist_ok=True)

    # Save exact original bytes
    with open(os.path.join(snapshot_dir, "original"), "wb") as f:
        f.write(orig_bytes)

    orig_text = orig_bytes.decode("utf-8", errors="replace")
    lines = orig_text.splitlines(keepends=True)
    new_lines = []
    applied_ids = []

    for line in lines:
        new_line, sid = prefix_cron_command(
            line,
            tclass,
            clean_sys_path,
            is_user_crontab=is_user_crontab,
            explicit=True,
        )
        new_lines.append(new_line)
        if sid:
            applied_ids.append(sid)

    manifest = {
        "id": target_id,
        "key": target_id,
        "kind": "cron",
        "class": tclass,
        "path": clean_sys_path,
        "sha256": orig_sha,
        "mode": st.st_mode,
        "uid": st.st_uid,
        "gid": st.st_gid,
        "applied_ids": applied_ids,
    }
    with open(os.path.join(snapshot_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    new_content = "".join(new_lines)
    tmp_path = f"{abs_cron_path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(new_content)
        f.flush()
        os.fsync(f.fileno())

    os.chmod(tmp_path, st.st_mode)
    try:
        os.chown(tmp_path, st.st_uid, st.st_gid)
    except OSError:
        pass

    os.replace(tmp_path, abs_cron_path)

    return {
        "path": clean_sys_path,
        "abs_path": abs_cron_path,
        "status": "deployed",
        "class": tclass,
        "applied_ids": applied_ids,
    }


def undeploy_cron_target(path_or_key: str, root: str = "/") -> Dict[str, Any]:
    """
    Restores cron file to exact byte-identical original from snapshot.
    """
    clean_path = str(path_or_key or "").strip()
    cands = [clean_path]
    if clean_path.startswith("/"):
        rel = os.path.relpath(clean_path, root) if clean_path.startswith(root) else clean_path.lstrip("/")
        cands.append(make_cron_snapshot_key("/" + rel))
    else:
        cands.append(make_cron_snapshot_key(clean_path))

    snapshot_dir = None
    manifest_file = None
    for cand in cands:
        d1 = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", cand)
        m1 = os.path.join(d1, "manifest.json")
        if os.path.isfile(m1):
            snapshot_dir = d1
            manifest_file = m1
            break
        d2 = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", "cron", cand)
        m2 = os.path.join(d2, "manifest.json")
        if os.path.isfile(m2):
            snapshot_dir = d2
            manifest_file = m2
            break

    if not snapshot_dir or not os.path.isfile(manifest_file):
        return {"target": path_or_key, "status": "no_snapshot"}

    with open(manifest_file, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    clean_sys_path = manifest["path"]
    abs_cron_path = os.path.join(root, clean_sys_path.lstrip("/"))
    backup_file = os.path.join(snapshot_dir, "original")

    if os.path.isfile(backup_file):
        with open(backup_file, "rb") as s, open(abs_cron_path, "wb") as d:
            d.write(s.read())
            d.flush()
            os.fsync(d.fileno())
        os.chmod(abs_cron_path, manifest.get("mode", 0o644))
        try:
            os.chown(abs_cron_path, manifest.get("uid", -1), manifest.get("gid", -1))
        except OSError:
            pass

    shutil.rmtree(snapshot_dir, ignore_errors=True)
    return {"target": clean_sys_path, "status": "restored"}
