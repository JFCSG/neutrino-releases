"""
systemd.py - Neutrino capture drop-in generator and deployer for systemd units.
Controls:
1. Unit text resolution from overlay or $ROOT/etc/systemd/system/<unit>.
2. Parsing first ExecStart= (ignoring comments and handling continuations).
3. Writing $ROOT/etc/systemd/system/<unit>.d/50-neutrino.conf:
   [Service]
   ExecStart=
   ExecStart=/usr/local/bin/neutrino-run --class <class> --id %n -- <original argv>
4. Refusing neutrino.service and deny basenames unless meter_only.
Standard library only. Zero external dependencies.
"""

import hashlib
import json
import os
import re
import secrets
import shutil
from typing import Dict, Any, List, Optional, Tuple, Set

from neutrino.capture.recipe import DENY_BASENAMES, check_deny_match

DROPIN_CONF_NAME = "neutrino.conf"

VENDOR_PATH_PREFIXES = (
    "/lib/",
    "/usr/lib/",
    "/usr/share/",
    "/snap/",
    "/var/lib/snapd/",
    "/opt/snap",
)

GENERIC_SUPERVISOR_PREFIXES = (
    "systemd-",
    "dbus",
    "udev",
    "sshd",
    "ssh.",
    "ssh-",
    "cron",
    "crond",
    "journald",
    "networkd",
    "snapd",
)

VENDOR_EXECSTART_PREFIXES = (
    "/lib/",
    "/usr/lib/",
    "/usr/sbin/",
    "/snap/",
    "/usr/libexec/",
)

NEUTRINO_UNITS = {
    "neutrino.service",
    "neutrino",
    "neutrino-run",
    "neutrino-setup",
    "neutrino-agent",
    "neutrino-srun",
    "neutrino-bsub",
    "neutrino-mq-append",
    "neutrino-oltp-load",
    "neutrino-enable-shims",
    "neutrino-capture-helper",
}


def load_autopilot_deny(root: str = "/") -> Set[str]:
    deny_file = os.path.join(root, "etc", "neutrino", "autopilot.deny")
    denied: Set[str] = set()
    if os.path.isfile(deny_file):
        try:
            with open(deny_file, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        denied.add(line)
                        if line.endswith(".service"):
                            denied.add(line[:-8])
                        else:
                            denied.add(f"{line}.service")
        except Exception:
            pass
    return denied


def load_autopilot_map(root: str = "/") -> Dict[str, str]:
    map_file = os.path.join(root, "etc", "neutrino", "autopilot.map")
    class_map: Dict[str, str] = dict()
    if os.path.isfile(map_file):
        try:
            with open(map_file, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        if "=" in line:
                            u, c = line.split("=", 1)
                        elif ":" in line:
                            u, c = line.split(":", 1)
                        else:
                            continue
                        u_name = u.strip()
                        c_name = c.strip()
                        if u_name and c_name:
                            class_map[u_name] = c_name
                            if u_name.endswith(".service"):
                                class_map[u_name[:-8]] = c_name
                            else:
                                class_map[f"{u_name}.service"] = c_name
        except Exception:
            pass
    return class_map


def extract_execstart_binary(exec_start: str) -> Optional[str]:
    if not exec_start:
        return None
    s = exec_start.strip()
    if "neutrino-run" in s and " -- " in s:
        s = s.split(" -- ", 1)[1].strip()

    import shlex
    try:
        tokens = shlex.split(s)
    except Exception:
        tokens = s.split()

    if not tokens:
        return None

    tok = tokens[0].lstrip("-@+!")
    if not tok and len(tokens) > 1:
        tok = tokens[1].lstrip("-@+!")

    if tok in ("/usr/bin/env", "env", "/bin/env") and len(tokens) > 1:
        for sub_tok in tokens[1:]:
            if sub_tok.startswith("-"):
                continue
            tok = sub_tok
            break

    return tok.strip('"\'')


def is_execstart_vendor(exec_start: str, root: str = "/") -> Tuple[bool, str]:
    bin_path = extract_execstart_binary(exec_start)
    if not bin_path:
        return True, "no_binary"

    if not os.path.isabs(bin_path):
        cand = shutil.which(bin_path) or os.path.join(root, "usr", "local", "bin", bin_path)
        bin_path = cand

    try:
        real_bin = os.path.realpath(bin_path)
    except OSError as ex:
        return True, f"realpath_error: {ex}"

    if root != "/" and real_bin.startswith(root):
        sys_real = "/" + os.path.relpath(real_bin, root).lstrip("/")
    else:
        sys_real = real_bin

    for vp in VENDOR_EXECSTART_PREFIXES:
        if sys_real.startswith(vp):
            return True, f"vendor_execstart ({vp.strip('/')})"

    if "/snap/" in sys_real or os.path.basename(sys_real).startswith("snap."):
        return True, "snap_execstart"

    return False, "site_binary"


def is_eligible_unit(
    unit_name: str,
    unit_path: str,
    unit_content: str,
    root: str = "/",
    deny_set: Optional[Set[str]] = None,
    vendor_manifest: Optional[Set[str]] = None,
) -> Tuple[bool, str]:
    u_norm = unit_name.strip()
    u_base = u_norm[:-8] if u_norm.endswith(".service") else u_norm

    # D6: Self exclusion
    if u_norm in NEUTRINO_UNITS or u_base in NEUTRINO_UNITS or u_norm.startswith("neutrino"):
        return False, "self_neutrino_unit"

    # Deny list check
    if deny_set is None:
        deny_set = load_autopilot_deny(root=root)
    if u_norm in deny_set or u_base in deny_set:
        return False, "denied (autopilot.deny)"

    # Supervisor check
    is_sup, sup_r = is_supervisor_unit(unit_content, u_norm)
    if is_sup:
        return False, sup_r

    # Site unit provenance check
    is_site, site_r = is_site_unit(unit_path, root=root, vendor_manifest=vendor_manifest)
    if not is_site:
        return False, site_r

    # ExecStart check
    exec_start = parse_first_exec_start(unit_content)
    if not exec_start:
        return False, "no_exec_start"

    is_vexec, vexec_r = is_execstart_vendor(exec_start, root=root)
    if is_vexec:
        return False, vexec_r

    # Live churn check (NRestarts < 3)
    is_churn, churn_r = is_churning_unit(u_norm, unit_content=unit_content, root=root)
    if is_churn:
        return False, churn_r

    return True, "eligible" 


def is_site_unit(
    path: str,
    root: str = "/",
    vendor_manifest: Optional[Set[str]] = None,
) -> Tuple[bool, str]:
    """
    Attach iff Provenance = site.
    After realpath, the unit file is NOT owned by dpkg/rpm/pacman AND NOT under
    /lib /usr/lib /usr/share /snap /var/lib/snapd /opt/snap*.
    A dangling alias in /etc/systemd/system that realpaths into those trees is vendor.
    Return True only for regular files under /etc/systemd/system that package_owns says 'not found'.
    Note: Skip by the unit file's realpath and package ownership.
    """
    try:
        real_p = os.path.realpath(path)
    except OSError as ex:
        return False, f"realpath_error: {ex}"

    # Normalize sys_path relative to root
    if root != "/" and real_p.startswith(root):
        sys_real = "/" + os.path.relpath(real_p, root).lstrip("/")
    else:
        sys_real = real_p

    # Check vendor directory prefixes
    for vp in VENDOR_PATH_PREFIXES:
        if sys_real.startswith(vp):
            return False, f"vendor_prefix ({vp.strip('/')})"

    # Check snap prefix/naming on unit or realpath
    bname = os.path.basename(sys_real)
    orig_bname = os.path.basename(path)
    if (
        bname.startswith("snap.")
        or bname.startswith("snap-")
        or orig_bname.startswith("snap.")
        or orig_bname.startswith("snap-")
    ):
        return False, "snap_unit"

    # Must be under /etc/systemd/system/
    if not sys_real.startswith("/etc/systemd/system/"):
        return False, f"not_site_tree ({sys_real})"

    # Must be a regular file
    if not os.path.isfile(real_p):
        return False, "not_regular_file"

    # Check package ownership
    from neutrino.capture.vendor import package_owns
    if package_owns(real_p, root=root, vendor_manifest=vendor_manifest):
        return False, "package_owned"

    return True, "site"


def is_job_unit(
    unit_content: str,
    unit_name: str,
    root: str = "/",
) -> Tuple[bool, str]:
    """
    Role = job. Type=oneshot, or a timer-triggered service.
    Type=simple/notify long-running daemons are NOT jobs. Do not wrap them on autopilot.
    Persistent agents (RemainAfterExit=yes) are NOT jobs.
    """
    if unit_name.endswith(".timer"):
        return True, "timer"

    m_type = re.search(r"^\s*Type\s*=\s*([A-Za-z0-9_-]+)", unit_content, re.IGNORECASE | re.MULTILINE)
    utype = m_type.group(1).lower() if m_type else "simple"

    if utype == "oneshot":
        m_remain = re.search(r"^\s*RemainAfterExit\s*=\s*([A-Za-z0-9_-]+)", unit_content, re.IGNORECASE | re.MULTILINE)
        if m_remain and m_remain.group(1).lower() in ("yes", "true", "1"):
            return False, "persistent_agent (RemainAfterExit=yes)"
        return True, "oneshot"

    if unit_name.endswith(".service"):
        base_name = unit_name[:-8]
        timer_cand = f"{base_name}.timer"
        t_paths = [
            os.path.join(root, "etc", "systemd", "system", timer_cand),
            os.path.join(root, "etc", "systemd", "system", "timers.target.wants", timer_cand),
        ]
        if any(os.path.isfile(tp) for tp in t_paths):
            return True, f"timer_triggered ({timer_cand})"

    if re.search(r"^\s*TriggeredBy\s*=", unit_content, re.IGNORECASE | re.MULTILINE):
        return True, "timer_triggered"

    return False, f"daemon (Type={utype})"


def is_supervisor_unit(unit_content: str, unit_name: str) -> Tuple[bool, str]:
    """
    Supervisor role exemption:
    - Names matching generic supervisors: systemd-*, dbus*, udev*, sshd/ssh.service,
      cron/crond, journald, networkd, snapd.service (the daemon, any vendor).
    - Systemd metadata: DefaultDependencies=no + Before=sysinit/basic/network-pre.
    No brand names in this check.
    """
    bname = unit_name.lower()
    for gen in GENERIC_SUPERVISOR_PREFIXES:
        if bname.startswith(gen) or bname == gen:
            return True, f"generic_supervisor ({gen.rstrip('.-')})"

    m_dd = re.search(r"^\s*DefaultDependencies\s*=\s*([A-Za-z0-9_-]+)", unit_content, re.IGNORECASE | re.MULTILINE)
    dd_no = bool(m_dd and m_dd.group(1).lower() in ("no", "false", "0"))

    m_before = re.search(r"^\s*Before\s*=\s*(.+)$", unit_content, re.IGNORECASE | re.MULTILINE)
    before_val = m_before.group(1).lower() if m_before else ""
    early_targets = ("sysinit", "basic", "network-pre")
    if dd_no and any(t in before_val for t in early_targets):
        return True, "early_boot_supervisor (DefaultDependencies=no + Before)"

    return False, "not_supervisor"


def is_churning_unit(
    unit_name: str,
    unit_content: Optional[str] = None,
    root: str = "/",
) -> Tuple[bool, str]:
    """
    Churn exemption: NRestarts >= 3 -> skip.
    Checks unit_content (for tests/mocks) and systemctl show <unit> -p NRestarts.
    """
    if unit_content:
        m = re.search(r"^\s*NRestarts\s*=\s*(\d+)", unit_content, re.IGNORECASE | re.MULTILINE)
        if m:
            nr = int(m.group(1))
            if nr >= 3:
                return True, f"churn (NRestarts={nr} >= 3)"

    if root == "/" and shutil.which("systemctl"):
        try:
            res = subprocess.run(
                ["systemctl", "show", unit_name, "-p", "NRestarts"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=2,
            )
            if res.returncode == 0:
                for line in res.stdout.splitlines():
                    if line.startswith("NRestarts="):
                        val = line.split("=", 1)[1].strip()
                        if val.isdigit() and int(val) >= 3:
                            return True, f"churn (NRestarts={val} >= 3)"
        except Exception:
            pass

    return False, "not_churning"



def find_unit_file(
    unit_name: str,
    root: str = "/",
    overlay_text: Optional[str] = None,
) -> Tuple[str, str]:
    """
    Locates unit file content either from overlay_text or on disk under root.
    Returns (resolved_path, unit_content).
    """
    if overlay_text is not None:
        return ("<overlay>", overlay_text)

    # Search standard systemd paths under root
    candidate_dirs = [
        os.path.join(root, "etc", "systemd", "system"),
        os.path.join(root, "lib", "systemd", "system"),
        os.path.join(root, "usr", "lib", "systemd", "system"),
    ]

    for cdir in candidate_dirs:
        cand_path = os.path.join(cdir, unit_name)
        if os.path.isfile(cand_path):
            with open(cand_path, "r", encoding="utf-8", errors="replace") as f:
                return (cand_path, f.read())

    # Default expected path for reporting error
    expected = os.path.join(root, "etc", "systemd", "system", unit_name)
    raise FileNotFoundError(f"Systemd unit file not found: {expected}")


def parse_first_exec_start(unit_content: str) -> Optional[str]:
    r"""
    Parses the first active ExecStart= line from unit content,
    ignoring comments (#, ;) and joining line continuations (\).
    If previously wrapped, unwraps to return the original command.
    """
    lines = unit_content.splitlines()
    i = 0
    raw_val = None
    while i < len(lines):
        line = lines[i].strip()
        i += 1
        if not line or line.startswith("#") or line.startswith(";"):
            continue

        if line.startswith("ExecStart="):
            full_val = line[len("ExecStart="):].strip()
            while full_val.endswith("\\") and i < len(lines):
                full_val = full_val[:-1].rstrip() + " " + lines[i].strip()
                i += 1
            raw_val = full_val.strip()
            if raw_val:
                break

    if not raw_val:
        return None

    if "neutrino-run" in raw_val and " -- " in raw_val:
        raw_val = raw_val.split(" -- ", 1)[1].strip()

    return raw_val


def generate_systemd_dropin(feature_class: str = "unspecified", original_exec_start: str = "", include_path_env: bool = False) -> str:
    """
    Generates the exact neutrino.conf drop-in content.
    Includes Environment=PATH=... only when include_path_env is True.
    Default class is 'unspecified' (metering and stamping only).
    """
    env_line = ""
    if include_path_env:
        env_line = 'Environment="PATH=/usr/local/lib/neutrino/path.d:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"\n'
    cls_tag = feature_class or "unspecified"
    return (
        "[Service]\n"
        f"{env_line}"
        "ExecStart=\n"
        f"ExecStart=/usr/local/bin/neutrino-run --class {cls_tag} --id %n -- {original_exec_start}\n"
    )


def deploy_systemd_target(
    target: Dict[str, Any],
    root: str = "/",
    overlay: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Deploys a systemd drop-in for a single target.
    Saves snapshot manifest in $ROOT/var/lib/neutrino/apply/capture/<id>/.
    """
    target_id = str(target.get("id") or "").strip()
    unit = str(target.get("unit") or target_id).strip()
    tclass = str(target.get("class") or "").strip()

    # Rule 1: Refuse .timer and neutrino.service
    if unit.endswith(".timer") or target_id.endswith(".timer"):
        bad = unit if unit.endswith(".timer") else target_id
        service_equiv = bad[:-6] + ".service"
        raise ValueError(
            f"Cannot wrap timer unit '{bad}'. A timer has no ExecStart; wrap '{service_equiv}' instead."
        )
    if unit == "neutrino.service" or target_id == "neutrino.service":
        raise ValueError("Cannot wrap neutrino.service")

    # Rule 2: Deny list check
    deny_hit = check_deny_match(unit, set(DENY_BASENAMES))
    if not deny_hit:
        deny_hit = check_deny_match(target_id, set(DENY_BASENAMES))

    if deny_hit and target.get("meter_only") is not True:
        raise ValueError(
            f"Target '{target_id}' matches denied basename '{deny_hit}' without meter_only: true"
        )

    # Rule 3: Resolve unit file
    overlay_text = overlay.get(unit) if overlay else None
    unit_path, unit_content = find_unit_file(unit, root=root, overlay_text=overlay_text)

    # Rule 4: Parse ExecStart
    exec_start = parse_first_exec_start(unit_content)
    if not exec_start:
        raise ValueError(f"Systemd unit '{unit}' has no valid ExecStart= line")

    has_accepted_path = False
    try:
        from neutrino.apply.path_targets import load_path_targets
        pdata = load_path_targets(root=root)
        has_accepted_path = any(
            c.get("accepted") is True for c in pdata.get("commands", []) if isinstance(c, dict)
        )
    except Exception:
        has_accepted_path = False

    dropin_content = generate_systemd_dropin(tclass, exec_start, include_path_env=has_accepted_path)

    # Rule 5: Snapshot and directory setup
    dropin_dir = os.path.join(root, "etc", "systemd", "system", f"{unit}.d")
    dropin_path = os.path.join(dropin_dir, DROPIN_CONF_NAME)

    snapshot_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", target_id)
    os.makedirs(snapshot_dir, exist_ok=True)

    dir_created = not os.path.isdir(dropin_dir)
    existed = os.path.isfile(dropin_path)

    orig_sha = None
    orig_mode = None
    if existed:
        with open(dropin_path, "rb") as f:
            b = f.read()
        orig_sha = hashlib.sha256(b).hexdigest()
        orig_mode = os.stat(dropin_path).st_mode
        with open(os.path.join(snapshot_dir, "backup_dropin.conf"), "wb") as f:
            f.write(b)

    manifest = {
        "id": target_id,
        "kind": "systemd",
        "class": tclass,
        "unit": unit,
        "dropin_file": os.path.relpath(dropin_path, root),
        "dropin_dir": os.path.relpath(dropin_dir, root),
        "dir_created": dir_created,
        "existed": existed,
        "sha256": orig_sha,
        "mode": orig_mode,
    }
    with open(os.path.join(snapshot_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    # Rule 6: Atomic write drop-in
    os.makedirs(dropin_dir, exist_ok=True)
    tmp_path = f"{dropin_path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(dropin_content)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp_path, 0o644)
    os.rename(tmp_path, dropin_path)

    return {
        "id": target_id,
        "unit": unit,
        "dropin_path": dropin_path,
        "status": "deployed",
    }


def undeploy_systemd_target(target_id: str, root: str = "/") -> Dict[str, Any]:
    """
    Restores systemd unit tree to original state from snapshot.
    Removes 50-neutrino.conf and removes unit.d directory if created by deploy.
    """
    snapshot_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", target_id)
    manifest_file = os.path.join(snapshot_dir, "manifest.json")

    if not os.path.isfile(manifest_file):
        unit = target_id if target_id.endswith(".service") else f"{target_id}.service"
        dropin_dir = os.path.join(root, "etc", "systemd", "system", f"{unit}.d")
        removed_any = False
        for cname in ("neutrino.conf", "50-neutrino.conf"):
            cp = os.path.join(dropin_dir, cname)
            if os.path.isfile(cp):
                try:
                    os.unlink(cp)
                    removed_any = True
                except OSError:
                    pass
        if os.path.isdir(dropin_dir) and not os.listdir(dropin_dir):
            try:
                os.rmdir(dropin_dir)
            except OSError:
                pass
        return {"id": target_id, "status": "restored" if removed_any else "no_snapshot"}

    with open(manifest_file, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    dropin_path = os.path.join(root, manifest["dropin_file"])
    dropin_dir = os.path.join(root, manifest["dropin_dir"])

    if manifest.get("existed"):
        backup_file = os.path.join(snapshot_dir, "backup_dropin.conf")
        if os.path.isfile(backup_file):
            with open(backup_file, "rb") as s, open(dropin_path, "wb") as d:
                d.write(s.read())
            os.chmod(dropin_path, manifest.get("mode", 0o644))
    else:
        if os.path.isfile(dropin_path):
            os.unlink(dropin_path)
        if os.path.isdir(dropin_dir):
            try:
                os.rmdir(dropin_dir)
            except OSError:
                pass

    shutil.rmtree(snapshot_dir, ignore_errors=True)
    return {"id": target_id, "status": "restored"}


def dummy_target(
    target: Any,
    root: str = "/",
    overlay: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Runs dummy verification on a target before attach:
    1. Verifies unit exists, is readable, ends in .service.
    2. Rejects .timer and suggests .service.
    3. Checks deny list.
    4. Parses ExecStart=.
    5. Tests drop-in generation syntax.
    6. Atomically saves dummy record under $ROOT/var/lib/neutrino/apply/dummy/<target_id>.json.
    """
    import time
    if isinstance(target, str):
        target = {
            "id": target,
            "unit": target,
            "kind": "systemd",
            "class": "batch",
        }
    elif not isinstance(target, dict):
        raise ValueError(f"Invalid target specification: {target}")

    target_id = str(target.get("id") or "").strip()
    unit = str(target.get("unit") or target_id).strip()
    tclass = str(target.get("class") or "batch").strip()

    # Rule 1: Refuse .timer
    if unit.endswith(".timer") or target_id.endswith(".timer"):
        bad = unit if unit.endswith(".timer") else target_id
        service_equiv = bad[:-6] + ".service"
        raise ValueError(
            f"Target '{target_id}' cannot wrap timer unit '{bad}'. A timer has no ExecStart; wrap '{service_equiv}' instead."
        )

    # Rule 2: Must end in .service
    if not unit.endswith(".service"):
        raise ValueError(
            f"Target '{target_id}' systemd unit must end in .service, got '{unit}'"
        )

    # Rule 3: Refuse neutrino.service
    if unit == "neutrino.service" or target_id == "neutrino.service":
        raise ValueError("Cannot wrap neutrino.service")

    # Rule 4: Deny list
    deny_hit = check_deny_match(unit, set(DENY_BASENAMES))
    if not deny_hit:
        deny_hit = check_deny_match(target_id, set(DENY_BASENAMES))
    if deny_hit and target.get("meter_only") is not True:
        raise ValueError(
            f"Target '{target_id}' matches denied basename '{deny_hit}' without meter_only: true"
        )

    # Rule 5: Resolve unit file
    overlay_text = overlay.get(unit) if overlay else None
    unit_path, unit_content = find_unit_file(unit, root=root, overlay_text=overlay_text)

    # Rule 6: Parse ExecStart=
    exec_start = parse_first_exec_start(unit_content)
    if not exec_start:
        raise ValueError(f"Systemd unit '{unit}' has no valid ExecStart= line")

    # Rule 7: Test drop-in syntax generation
    dropin_content = generate_systemd_dropin(tclass, exec_start)
    if not dropin_content or "[Service]" not in dropin_content:
        raise ValueError(f"Failed to generate valid drop-in for target '{target_id}'")

    # Rule 8: Save dummy record
    dummy_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "dummy")
    os.makedirs(dummy_dir, exist_ok=True)
    dummy_file = os.path.join(dummy_dir, f"{target_id}.json")

    record = {
        "ok": True,
        "id": target_id,
        "unit": unit,
        "class": tclass,
        "kind": "systemd",
        "exec_start": exec_start,
        "verified_at": time.time(),
        "status": "dummy_ok",
    }
    content = json.dumps(record, indent=2) + "\n"
    tmp_path = f"{dummy_file}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp_path, 0o644)
    os.rename(tmp_path, dummy_file)

    return record


def dummy_status(target_or_id: Any, root: str = "/") -> bool:
    """
    Returns True if dummy verification record exists and status is dummy_ok.
    """
    if isinstance(target_or_id, dict):
        tid = str(target_or_id.get("id") or target_or_id.get("unit") or "").strip()
    else:
        tid = str(target_or_id).strip()

    dummy_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "dummy")
    candidate_files = [
        os.path.join(dummy_dir, f"{tid}.json"),
    ]
    if not tid.endswith(".service"):
        candidate_files.append(os.path.join(dummy_dir, f"{tid}.service.json"))
    else:
        candidate_files.append(os.path.join(dummy_dir, f"{tid[:-8]}.json"))

    for path in candidate_files:
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    rec = json.load(f)
                    if rec.get("status") == "dummy_ok":
                        return True
            except Exception:
                pass
    return False


def attach_target(
    target: Dict[str, Any],
    lever: str = "occupancy",
    root: str = "/",
    overlay: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Attaches a target by deploying systemd drop-in wrapper under class lever.
    Requires dummy verification to have succeeded (dummy_status is True).
    Refuses if unit is denied, matches DENY_BASENAMES, is .timer, or dummy failed.
    """
    target_id = str(target.get("id") or "").strip()
    unit = str(target.get("unit") or target_id).strip()
    tclass = str(target.get("class") or "").strip()

    # Refuse .timer
    if unit.endswith(".timer") or target_id.endswith(".timer"):
        bad = unit if unit.endswith(".timer") else target_id
        raise ValueError(
            f"Cannot wrap timer unit '{bad}'. A timer has no ExecStart; wrap '{bad[:-6]}.service' instead."
        )

    # Refuse neutrino.service
    if unit == "neutrino.service" or target_id == "neutrino.service":
        raise ValueError("Cannot wrap neutrino.service")

    # Check deny list
    deny_hit = check_deny_match(unit, set(DENY_BASENAMES))
    if not deny_hit:
        deny_hit = check_deny_match(target_id, set(DENY_BASENAMES))
    if deny_hit and target.get("meter_only") is not True:
        raise ValueError(
            f"Target '{target_id}' matches denied basename '{deny_hit}' without meter_only: true"
        )

    # Require dummy verification
    if not dummy_status(target, root=root):
        raise RuntimeError(
            f"Cannot attach target '{target_id}': dummy verification has not been run or failed."
        )

    # Deploy systemd drop-in
    res = deploy_systemd_target(target, root=root, overlay=overlay)

    # Reload systemd if root on live system
    if root == "/" and os.geteuid() == 0 and shutil.which("systemctl"):
        try:
            import subprocess
            subprocess.run(["systemctl", "daemon-reload"], check=False, timeout=5)
        except Exception:
            pass

    return res


def detach_target(
    target_or_id: Any,
    root: str = "/",
) -> Dict[str, Any]:
    """
    Detaches a target by removing the systemd drop-in and restoring snapshots.
    """
    if isinstance(target_or_id, dict):
        target_id = str(target_or_id.get("id") or target_or_id.get("unit") or "").strip()
    else:
        target_id = str(target_or_id).strip()

    res = undeploy_systemd_target(target_id, root=root)

    # Reload systemd if root on live system
    if root == "/" and os.geteuid() == 0 and shutil.which("systemctl"):
        try:
            import subprocess
            subprocess.run(["systemctl", "daemon-reload"], check=False, timeout=5)
        except Exception:
            pass

    return res


def get_target_status(target: Dict[str, Any], root: str = "/") -> str:
    """
    Evaluates current target status.
    Returns one of four required statuses:
    'dummy' | 'attached' | 'detached' | 'denied'
    """
    tid = str(target.get("id") or "").strip()
    unit = str(target.get("unit") or tid).strip()
    tclass = str(target.get("class") or "").strip().lower()
    kind = str(target.get("kind") or "systemd").strip().lower()
    is_meter_only_flag = target.get("meter_only") is True

    # 1. Deny check
    if tid == "neutrino.service" or unit == "neutrino.service":
        return "denied"
    if unit.endswith(".timer") or tid.endswith(".timer"):
        return "denied"

    names = [tid, unit]
    if unit.endswith(".service"):
        names.append(unit[:-8])

    deny_set = {d.lower() for d in DENY_BASENAMES}
    deny_hit = None
    for n in names:
        h = check_deny_match(n, deny_set)
        if h:
            deny_hit = h
            break

    if deny_hit and not is_meter_only_flag:
        return "denied"

    # 2. Check attached
    is_attached = False
    if kind == "systemd":
        dropin = os.path.join(root, "etc", "systemd", "system", f"{unit}.d", DROPIN_CONF_NAME)
        if os.path.isfile(dropin):
            try:
                with open(dropin, "r", encoding="utf-8") as f:
                    if "/usr/local/bin/neutrino-run" in f.read():
                        is_attached = True
            except Exception:
                pass
    elif kind == "cron":
        from neutrino.capture.cron import validate_cron_path
        try:
            abs_cron = validate_cron_path(target.get("path") or tid, root=root)
            if os.path.isfile(abs_cron):
                with open(abs_cron, "r", encoding="utf-8", errors="replace") as f:
                    if "/usr/local/bin/neutrino-run" in f.read():
                        is_attached = True
        except Exception:
            pass
    elif kind == "slurm_wrap":
        snap_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", tid)
        if os.path.isdir(snap_dir):
            is_attached = True

    if is_attached:
        return "attached"

    # 3. Check dummy verified
    if dummy_status(target, root=root):
        return "dummy"

    # 4. Otherwise detached
    return "detached"


def discover_systemd_targets(
    root: str = "/",
    include_vendor: bool = False,
    overlay: Optional[Dict[str, str]] = None,
    deny_set: Optional[Set[str]] = None,
    vendor_manifest: Optional[Set[str]] = None,
) -> List[Dict[str, Any]]:
    """
    Discovers local systemd service units for capture under 4-part qualification:
    1. Provenance = site (not vendor prefix, not package owned, regular file under /etc/systemd/system).
    2. Role = job (Type=oneshot, .timer, or timer-triggered. Type=simple/notify daemons skipped).
    3. Not a supervisor role (generic supervisors or DefaultDependencies=no + Before early target).
    4. Not churning (NRestarts >= 3).
    """
    if deny_set is None:
        deny_set = {d.lower() for d in DENY_BASENAMES}

    discovered = []
    seen_units = set()

    operator_dir = os.path.join(root, "etc", "systemd", "system")

    # 1. Scan operator directory
    if os.path.isdir(operator_dir):
        try:
            for entry in sorted(os.listdir(operator_dir)):
                if not entry.endswith(".service"):
                    continue
                full_path = os.path.join(operator_dir, entry)
                if not os.path.isfile(full_path):
                    continue
                try:
                    if os.path.islink(full_path) and os.readlink(full_path) == "/dev/null":
                        continue
                except OSError:
                    pass

                seen_units.add(entry)

                try:
                    with open(full_path, "r", encoding="utf-8", errors="replace") as f:
                        content_u = f.read()
                except Exception as ex:
                    discovered.append({
                        "unit": entry,
                        "path": full_path,
                        "is_vendor": False,
                        "status": f"skipped: unreadable ({ex})",
                    })
                    continue

                is_elig, elig_reason = is_eligible_unit(
                    entry, full_path, content_u, root=root,
                    deny_set=load_autopilot_deny(root=root),
                    vendor_manifest=vendor_manifest,
                )
                if not is_elig:
                    discovered.append({
                        "unit": entry,
                        "path": full_path,
                        "is_vendor": "vendor" in elig_reason or "provenance" in elig_reason or "package" in elig_reason or "snap" in elig_reason,
                        "status": f"skipped: {elig_reason}",
                    })
                    continue

                exec_start = parse_first_exec_start(content_u)
                if not exec_start:
                    discovered.append({
                        "unit": entry,
                        "path": full_path,
                        "is_vendor": False,
                        "status": "skipped: no_exec_start",
                    })
                    continue

                dropin_path = os.path.join(operator_dir, f"{entry}.d", DROPIN_CONF_NAME)
                has_dropin = os.path.isfile(dropin_path)
                if "neutrino-run" in exec_start or "neutrino-run" in content_u or has_dropin:
                    discovered.append({
                        "unit": entry,
                        "path": full_path,
                        "exec_start": exec_start,
                        "is_vendor": False,
                        "status": "skipped: already_wrapped",
                    })
                    continue

                # Run dummy verification
                try:
                    dummy_res = dummy_target(entry, root=root)
                    dummy_ok = bool(dummy_res.get("ok") is True or dummy_res.get("status") == "dummy_ok")
                except Exception:
                    dummy_ok = False

                discovered.append({
                    "unit": entry,
                    "path": full_path,
                    "exec_start": exec_start,
                    "is_vendor": False,
                    "status": "dummy_ok" if dummy_ok else "candidate",
                    "dummy_ok": dummy_ok,
                })
        except OSError:
            pass

    # 2. Overlay entries (for unit testing sandboxes)
    if overlay:
        for entry, content_u in sorted(overlay.items()):
            if not entry.endswith(".service") or entry in seen_units:
                continue
            seen_units.add(entry)

            bname = entry.lower()
            if bname.startswith("snap.") or bname.startswith("snap-"):
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "is_vendor": True,
                    "status": "skipped: provenance (snap_unit)",
                })
                continue

            if vendor_manifest and (entry in vendor_manifest or bname in vendor_manifest):
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "is_vendor": True,
                    "status": "skipped: provenance (package_owned)",
                })
                continue

            # Role
            is_job, job_reason = is_job_unit(content_u, entry, root=root)
            if not is_job:
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "is_vendor": False,
                    "status": f"skipped: role ({job_reason})",
                })
                continue

            # Supervisor
            is_sup, sup_reason = is_supervisor_unit(content_u, entry)
            if is_sup:
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "is_vendor": False,
                    "status": f"skipped: supervisor ({sup_reason})",
                    "denied": True,
                    "deny_reason": sup_reason,
                })
                continue

            deny_hit = check_deny_match(entry, deny_set)
            if deny_hit:
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "is_vendor": False,
                    "status": f"skipped: denied ({deny_hit})",
                    "denied": True,
                    "deny_reason": deny_hit,
                })
                continue

            # Churn
            is_churn, churn_reason = is_churning_unit(entry, unit_content=content_u, root=root)
            if is_churn:
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "is_vendor": False,
                    "status": f"skipped: churn ({churn_reason})",
                })
                continue

            exec_start = parse_first_exec_start(content_u)
            if not exec_start:
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "is_vendor": False,
                    "status": "skipped: no_exec_start",
                })
                continue
            if "neutrino-run" in exec_start or "neutrino-run" in content_u:
                discovered.append({
                    "unit": entry,
                    "path": "<overlay>",
                    "exec_start": exec_start,
                    "is_vendor": False,
                    "status": "skipped: already_wrapped",
                })
                continue
            discovered.append({
                "unit": entry,
                "path": "<overlay>",
                "exec_start": exec_start,
                "is_vendor": False,
                "status": "dummy_ok",
                "dummy_ok": True,
            })

    # 3. Vendor units
    if include_vendor:
        vendor_dirs = [
            os.path.join(root, "lib", "systemd", "system"),
            os.path.join(root, "usr", "lib", "systemd", "system"),
        ]
        for vdir in vendor_dirs:
            if not os.path.isdir(vdir):
                continue
            try:
                for entry in sorted(os.listdir(vdir)):
                    if not entry.endswith(".service") or entry in seen_units:
                        continue
                    full_path = os.path.join(vdir, entry)
                    if not os.path.isfile(full_path):
                        continue
                    seen_units.add(entry)
                    discovered.append({
                        "unit": entry,
                        "path": full_path,
                        "is_vendor": True,
                        "status": "skipped: vendor_unit",
                    })
            except OSError:
                pass

    return discovered
