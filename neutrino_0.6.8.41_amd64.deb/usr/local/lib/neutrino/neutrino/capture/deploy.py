"""
deploy.py - Atomic capture deployment and uninstallation engine.
Controls:
1. deploy_capture(recipe, root=) -> {installed[], skipped[], errors[]}
2. undeploy_capture(recipe, root=) -> restores snapshots.
3. Snapshot dir: $ROOT/var/lib/neutrino/apply/capture/<id>/
4. Manifest sha256 + mode. Partial fail rolls back THAT target only.
5. attach_operator_safe() for principled provenance and role based autonomous capture:
   - Evaluates Provenance (site), Role (job), Not Supervisor, Not Churning.
   - Reconciles targets.json: surgically detaches any existing targets that fail these checks.
   - Restricts PATH wrapping to only unpackaged executables that cron/run-parts actually invoke.
Standard library only. Zero external dependencies.
"""

import json
import os
import shutil
import subprocess
from typing import Dict, Any, List, Optional, Set

from neutrino.capture.recipe import validate_recipe, load_recipe, validate_target, DENY_BASENAMES
from neutrino.capture.systemd import (
    deploy_systemd_target,
    undeploy_systemd_target,
    dummy_target,
    dummy_status,
    attach_target,
    detach_target,
    get_target_status,
    discover_systemd_targets,
    is_site_unit,
    is_job_unit,
    is_supervisor_unit,
    is_churning_unit,
    DROPIN_CONF_NAME,
)
from neutrino.capture.cron import deploy_cron_target, undeploy_cron_target
from neutrino.apply.targets import load_accepted_targets, save_accepted_targets


def deploy_capture(
    recipe: Any,
    root: str = "/",
    overlay: Optional[Dict[str, str]] = None,
) -> Dict[str, List[Any]]:
    """
    Deploys capture drop-ins and cron wrappers for all targets in recipe.
    Returns: {installed: [...], skipped: [...], errors: [...]}
    Partial failure rolls back that target only.
    """
    if isinstance(recipe, str):
        recipe_dict = load_recipe(recipe, strict_targets=False)
    elif isinstance(recipe, dict):
        recipe_dict = validate_recipe(recipe, strict_targets=False)
    else:
        raise ValueError(f"Invalid recipe type: {type(recipe).__name__}")

    targets = recipe_dict.get("targets", [])
    installed: List[str] = []
    skipped: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []

    deny_set = set(recipe_dict.get("deny", DENY_BASENAMES))

    for target in targets:
        tid = target.get("id", "unknown")
        kind = target.get("kind")

        try:
            val_target = validate_target(target, deny_set=deny_set)
        except Exception as e:
            err_msg = str(e)
            if "without meter_only: true" in err_msg or "matches denied basename" in err_msg:
                skipped.append({"id": tid, "reason": err_msg})
            else:
                errors.append({"id": tid, "error": err_msg})
            continue

        try:
            if kind == "systemd":
                deploy_systemd_target(val_target, root=root, overlay=overlay)
                installed.append(tid)
            elif kind == "cron":
                deploy_cron_target(val_target, root=root)
                installed.append(tid)
            elif kind == "slurm_wrap":
                installed.append(tid)
            else:
                errors.append({"id": tid, "error": f"Unknown target kind: {kind}"})
        except Exception as e:
            err_msg = str(e)
            if kind == "systemd":
                try:
                    undeploy_systemd_target(tid, root=root)
                except Exception:
                    pass
            elif kind == "cron":
                try:
                    undeploy_cron_target(tid, root=root)
                except Exception:
                    pass
            errors.append({"id": tid, "error": err_msg})

    return {
        "installed": installed,
        "skipped": skipped,
        "errors": errors,
    }


def undeploy_capture(
    recipe: Optional[Any] = None,
    root: str = "/",
) -> Dict[str, List[Any]]:
    """
    Undeploys all capture targets and restores snapshots.
    Scans $ROOT/var/lib/neutrino/apply/capture/ or targets in recipe.
    """
    capture_base = os.path.join(root, "var", "lib", "neutrino", "apply", "capture")
    uninstalled: List[str] = []
    errors: List[Dict[str, Any]] = []

    target_ids = []
    if os.path.isdir(capture_base):
        target_ids = sorted(os.listdir(capture_base))

    if recipe is not None:
        if isinstance(recipe, str) and os.path.isfile(recipe):
            try:
                rec_data = load_recipe(recipe)
                recipe_ids = [t["id"] for t in rec_data.get("targets", []) if "id" in t]
                for rid in recipe_ids:
                    if rid not in target_ids:
                        target_ids.append(rid)
            except Exception:
                pass
        elif isinstance(recipe, dict):
            recipe_ids = [t["id"] for t in recipe.get("targets", []) if "id" in t]
            for rid in recipe_ids:
                if rid not in target_ids:
                    target_ids.append(rid)

    for tid in target_ids:
        snap_dir = os.path.join(capture_base, tid)
        manifest_file = os.path.join(snap_dir, "manifest.json")
        kind = None
        if os.path.isfile(manifest_file):
            try:
                with open(manifest_file, "r", encoding="utf-8") as f:
                    manifest = json.load(f)
                    kind = manifest.get("kind")
            except Exception:
                pass

        try:
            if kind == "systemd":
                undeploy_systemd_target(tid, root=root)
                uninstalled.append(tid)
            elif kind == "cron":
                undeploy_cron_target(tid, root=root)
                uninstalled.append(tid)
            else:
                # Fallback: attempt both
                undeploy_systemd_target(tid, root=root)
                undeploy_cron_target(tid, root=root)
                uninstalled.append(tid)
        except Exception as e:
            errors.append({"id": tid, "error": str(e)})

    return {
        "uninstalled": uninstalled,
        "errors": errors,
    }


def attach_operator_safe(
    root: str = "/",
    default_class: str = "unspecified",
    cfg: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Autopilot candidate reconciliation and attachment (0.6.1):
    1. Loads autopilot.deny and autopilot.map.
    2. Reconciles existing units:
       - If unit has NRestarts >= 3 (storm detachment), is in autopilot.deny, or is no longer eligible:
         Detaches it, restores backup from snapshot, and removes drop-in.
    3. Scans /etc/systemd/system/*.service:
       - Attaches every eligible site unit with class from autopilot.map or 'unspecified'.
       - Never hardcodes 'batch'.
    4. Daemon reload & selective live restart:
       - If any drop-in was added or removed: runs systemctl daemon-reload.
       - Runs systemctl restart ONLY for newly attached units that are NOT in autopilot.deny.
       - Never restarts already-attached units.
       - Never restarts units in autopilot.deny.
    """
    from neutrino.capture.systemd import (
        is_eligible_unit,
        load_autopilot_deny,
        load_autopilot_map,
        deploy_systemd_target,
        undeploy_systemd_target,
        DROPIN_CONF_NAME,
    )

    apply_dir = cfg.get("apply_dir") if cfg else None
    targets_data = load_accepted_targets(root=root, apply_dir=apply_dir)

    deny_set = load_autopilot_deny(root=root)
    class_map = load_autopilot_map(root=root)

    pruned_units = []
    removed_any_dropin = False
    detached_units = []

    # 1. Collect all units currently tracked or possessing drop-ins on disk
    units_to_check = dict()
    for u in targets_data.get("units", []):
        u_name = str(u.get("unit") or u.get("id") or "").strip()
        if u_name:
            units_to_check[u_name] = u

    systemd_dir = os.path.join(root, "etc", "systemd", "system")
    if os.path.isdir(systemd_dir):
        for entry in os.listdir(systemd_dir):
            if entry.endswith(".d"):
                u_name = entry[:-2]
                dropin_file = os.path.join(systemd_dir, entry, DROPIN_CONF_NAME)
                legacy_file = os.path.join(systemd_dir, entry, "50-neutrino.conf")
                if (os.path.isfile(dropin_file) or os.path.isfile(legacy_file)) and u_name not in units_to_check:
                    units_to_check[u_name] = {"unit": u_name}

    for u_name, u in units_to_check.items():
        u_path = os.path.join(systemd_dir, u_name)
        if not os.path.isfile(u_path):
            for vp in ("/lib/systemd/system", "/usr/lib/systemd/system"):
                cand = os.path.join(root, vp.lstrip("/"), u_name)
                if os.path.isfile(cand):
                    u_path = cand
                    break

        dropin_dir = os.path.join(systemd_dir, f"{u_name}.d")
        dropin_file = os.path.join(dropin_dir, DROPIN_CONF_NAME)
        legacy_file = os.path.join(dropin_dir, "50-neutrino.conf")

        if not os.path.isfile(u_path):
            try:
                undeploy_systemd_target(u_name, root=root)
            except Exception:
                pass
            for f_cand in (dropin_file, legacy_file):
                if os.path.isfile(f_cand):
                    try:
                        os.unlink(f_cand)
                        removed_any_dropin = True
                    except OSError:
                        pass
            if os.path.isdir(dropin_dir) and not os.listdir(dropin_dir):
                try:
                    os.rmdir(dropin_dir)
                except OSError:
                    pass
            detached_units.append(u_name)
            continue

        try:
            with open(u_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception:
            continue

        is_elig, elig_r = is_eligible_unit(u_name, u_path, content, root=root, deny_set=deny_set)
        if is_elig:
            pruned_units.append(u)
        else:
            # Detach ineligible or storming unit
            try:
                undeploy_systemd_target(u_name, root=root)
            except Exception:
                pass
            for f_cand in (dropin_file, legacy_file):
                if os.path.isfile(f_cand):
                    try:
                        os.unlink(f_cand)
                        removed_any_dropin = True
                    except OSError:
                        pass
            if os.path.isdir(dropin_dir) and not os.listdir(dropin_dir):
                try:
                    os.rmdir(dropin_dir)
                except OSError:
                    pass
            detached_units.append(u_name)

    existing_set = {
        str(u.get("unit") or u.get("id") or "").strip().lower()
        for u in pruned_units
    }

    # 2. Discover and Attach eligible units across /etc/systemd/system/
    newly_attached = []
    added_any_dropin = False

    if os.path.isdir(systemd_dir):
        for fname in sorted(os.listdir(systemd_dir)):
            if not fname.endswith(".service"):
                continue
            fpath = os.path.join(systemd_dir, fname)
            if not os.path.isfile(fpath):
                continue
            try:
                if os.path.islink(fpath) and os.readlink(fpath) == "/dev/null":
                    continue
            except OSError:
                pass

            f_norm = fname.strip().lower()
            try:
                with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                    content_u = f.read()
            except Exception:
                continue

            is_elig, elig_r = is_eligible_unit(fname, fpath, content_u, root=root, deny_set=deny_set)
            if not is_elig:
                continue

            # Determine class: check autopilot.map first, fallback to default_class or 'unspecified'
            base_name = fname[:-8]
            target_entry = units_to_check.get(fname) or units_to_check.get(base_name) or {}
            target_cls = target_entry.get("class")
            u_cls = class_map.get(fname) or class_map.get(base_name) or target_cls or default_class or "unspecified"

            from neutrino.capture.systemd import parse_first_exec_start, generate_systemd_dropin
            exec_start = parse_first_exec_start(content_u)
            if not exec_start:
                continue

            desired_dropin = generate_systemd_dropin(u_cls, exec_start)
            dropin_path = os.path.join(systemd_dir, f"{fname}.d", DROPIN_CONF_NAME)

            dropin_matches = False
            if os.path.isfile(dropin_path):
                try:
                    with open(dropin_path, "r", encoding="utf-8") as df:
                        on_disk_text = df.read()
                    if on_disk_text.strip() == desired_dropin.strip():
                        dropin_matches = True
                except Exception:
                    pass

            if not dropin_matches:
                try:
                    tspec = {"id": fname, "unit": fname, "class": u_cls, "kind": "systemd"}
                    deploy_systemd_target(tspec, root=root)
                    if not os.path.isfile(dropin_path):
                        newly_attached.append(fname)
                    added_any_dropin = True
                except Exception:
                    pass

            if f_norm not in existing_set:
                new_entry = {
                    "unit": fname,
                    "class": u_cls,
                    "accepted": True,
                    "attached": True,
                }
                pruned_units.append(new_entry)
                existing_set.add(f_norm)

    targets_data["units"] = pruned_units
    save_accepted_targets(targets_data, root=root, apply_dir=apply_dir)

    # 3. Daemon reload if drop-ins changed
    if (added_any_dropin or removed_any_dropin) and root == "/" and shutil.which("systemctl"):
        try:
            subprocess.run(["systemctl", "daemon-reload"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
        except Exception:
            pass

    # 4. Live Restart ONLY newly attached units that are NOT in deny_set
    if newly_attached and root == "/" and shutil.which("systemctl"):
        for u in newly_attached:
            if u not in deny_set:
                try:
                    subprocess.run(["systemctl", "restart", u], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
                except Exception:
                    pass

    # 2. Cron Lines
    attached_cron = []
    discovered_cron = []
    try:
        from neutrino.capture.cron import discover_cron_targets, deploy_cron_target
        discovered_cron = discover_cron_targets(root=root, include_vendor=False)
        for c in discovered_cron:
            if not c.get("is_vendor") and "skipped" not in c.get("status", ""):
                try:
                    res = deploy_cron_target({"path": c["path"], "class": default_class}, root=root)
                    if res.get("applied_ids") or res.get("lines_wrapped", 0) > 0:
                        attached_cron.append(c["path"])
                except Exception:
                    pass
    except Exception:
        pass

    # 3. Run-Parts Jobs
    attached_runparts = []
    discovered_rp = []
    try:
        from neutrino.capture.runparts import discover_runparts_targets, deploy_runparts_target
        discovered_rp = discover_runparts_targets(root=root, include_vendor=False)
        for r in discovered_rp:
            if not r.get("is_vendor") and "skipped" not in r.get("status", ""):
                try:
                    deploy_runparts_target({"name": r["name"], "path": r["path"], "class": default_class}, root=root)
                    attached_runparts.append(r["name"])
                except Exception:
                    pass
    except Exception:
        pass

    # 4. PATH Commands: Only unpackaged files that cron/run-parts already invoke
    attached_paths = []
    try:
        from neutrino.apply.path_targets import (
            load_path_targets,
            save_path_targets,
            accept_path_command,
            PROHIBITED_PATH_SHIMS,
        )
        from neutrino.capture.path_shim import (
            deploy_path_shim,
            sync_path_environment,
        )
        from neutrino.capture.vendor import package_owns

        NEUTRINO_BINARIES = {
            "neutrino", "neutrino-run", "neutrino-setup", "neutrino-srun",
            "neutrino-bsub", "neutrino-mq-append", "neutrino-oltp-load",
            "neutrino-capture-helper", "neutrino-enable-shims",
        }

        # Find commands invoked by cron/runparts under /usr/local/bin
        referenced_basenames = set()
        for c in discovered_cron:
            for l in c.get("lines", []):
                cmd_str = str(l.get("command") or "")
                for tok in cmd_str.split():
                    if tok.startswith("/usr/local/bin/") or tok.startswith(os.path.join(root, "usr/local/bin/")):
                        referenced_basenames.add(os.path.basename(tok))
        for r in discovered_rp:
            r_path = str(r.get("path") or "")
            if r_path.startswith("/usr/local/bin/") or r_path.startswith(os.path.join(root, "usr/local/bin/")):
                referenced_basenames.add(os.path.basename(r_path))

        path_data = load_path_targets(root=root, apply_dir=apply_dir)
        for bname in sorted(referenced_basenames):
            if bname in NEUTRINO_BINARIES or bname.lower() in PROHIBITED_PATH_SHIMS:
                continue
            bin_path = os.path.join(root, "usr", "local", "bin", bname)
            if not os.path.isfile(bin_path) or not os.access(bin_path, os.X_OK):
                continue
            try:
                real_bin = os.path.realpath(bin_path)
            except OSError:
                continue
            # Provenance: not vendor prefix, not snap, not package owned
            if any(real_bin.startswith(vp) for vp in ("/lib/", "/usr/lib/", "/usr/share/", "/snap/", "/var/lib/snapd/", "/opt/snap")):
                continue
            if bname.startswith("snap.") or "/snap/" in real_bin:
                continue
            if package_owns(real_bin, root=root):
                continue

            accept_res = accept_path_command(bname, feature_class=default_class, root=root, apply_dir=apply_dir)
            if accept_res.get("ok"):
                deploy_path_shim({"basename": bname, "class": default_class}, root=root)
                attached_paths.append(bname)

        path_data = load_path_targets(root=root, apply_dir=apply_dir)
        path_data["commands"] = [
            c for c in path_data.get("commands", [])
            if c.get("basename") in attached_paths
        ]
        save_path_targets(path_data, root=root, apply_dir=apply_dir)
        sync_path_environment(root=root)
    except Exception:
        pass

    attached_units = [
        u.get("unit") or u.get("id")
        for u in targets_data.get("units", [])
        if u.get("attached")
    ]
    return {
        "ok": True,
        "attached_units": attached_units,
        "attached_cron": attached_cron,
        "attached_runparts": attached_runparts,
        "attached_paths": attached_paths,
    }

reconcile = attach_operator_safe
