"""
recipe.py - Neutrino Apply recipe schema loader and validator.
Single validator implementation for both CLI and capture helper.
Controls /etc/neutrino/recipe.json validation:
1. Version must be 1 (or purpose == 'recipe' for desk-signed papers).
2. Classes must be exactly ALL_CLASSES (order-insensitive set):
   - list of 11 slugs OR
   - map slug -> {lever}
3. Meter-only default: idle, heartbeat, unspecified, etl.
   Operator may remove etl, but idle/heartbeat/unspecified cannot be removed.
4. Targets list: id, class, kind in {systemd, cron, slurm_wrap}.
   - systemd: unit basename only ^[A-Za-z0-9:_.-]+\service$, reject neutrino.service
   - cron: path prefix /etc/cron.d/ or /etc/cron.daily/ only, no path traversal
   - slurm_wrap: wrapper name, no host paths
   - deny basenames: oracle, postgres, mariadbd, mysqld, java, sshd, systemd.
     deny hit without meter_only: true -> error
5. Autopilot boolean default false.
Standard library only. Zero external dependencies.
"""

import json
import os
import re
import secrets
from typing import Dict, Any, List, Set, Optional

DEFAULT_RECIPE_JSON_PATH = "/etc/neutrino/recipe.json"

ALL_CLASSES: List[str] = [
    "compile", "infer-cpu", "batch", "oltp", "mq", "hpc", "render", "etl",
    "idle", "heartbeat", "unspecified"
]

MANDATORY_METER_ONLY: Set[str] = {"idle", "heartbeat", "unspecified"}
DEFAULT_METER_ONLY: List[str] = ["idle", "heartbeat", "unspecified", "etl"]

DENY_BASENAMES: List[str] = [
    "sshd", "ssh", "getty", "serial-getty", "user@", "networkmanager",
    "systemd-networkd", "systemd-resolved", "cron", "crond",
    "neutrino", "neutrino.service", "dbus", "udev", "kernel", "journald", "networkd", "snapd"
]

VALID_TARGET_KINDS: Set[str] = {"systemd", "cron", "slurm_wrap"}

SYSTEMD_UNIT_PATTERN = re.compile(r"^[A-Za-z0-9:_.@+-]+\.service$")
SLURM_WRAP_PATTERN = re.compile(r"^[A-Za-z0-9:_.-]+$")


def check_deny_match(candidate: str, deny_set: Set[str]) -> Optional[str]:
    """
    Checks if a candidate string matches any denied basename.
    Matches exact basename, sub-token (delimited by -_.@:), or prefix.
    Deny is strictly for host survival; customer databases are not denied.
    """
    if not candidate:
        return None
    clean = candidate.strip().lower()
    if clean.endswith(".service"):
        clean = clean[:-8]

    if clean in deny_set:
        return clean

    if clean.startswith("systemd-") or clean == "systemd":
        return "systemd-*"
    if clean.startswith("udev") or clean.startswith("systemd-udev"):
        return "udev"
    if clean == "kernel" or clean.startswith("kworker") or clean.startswith("ksoftirqd"):
        return "kernel"
    if clean.startswith("snap.") or clean.startswith("snap-") or clean == "snap" or clean.startswith("snapd"):
        return "snap.*"
    if clean.startswith("journald") or clean.startswith("systemd-journal"):
        return "journald"
    if clean.startswith("networkd") or clean.startswith("systemd-network"):
        return "networkd"
    if clean.startswith("dbus"):
        return "dbus"

    for d in deny_set:
        if d.endswith("@") and (clean.startswith(d) or candidate.lower().startswith(d)):
            return d
        if d in ("getty", "serial-getty", "systemd-networkd", "systemd-resolved", "networkmanager") and clean.startswith(d):
            return d
        if d in ("cron", "crond") and (clean in ("cron", "crond") or clean.startswith("cron.") or clean.startswith("crond.") or clean.startswith("cron-") or clean.startswith("crond-")):
            return d

    tokens = re.split(r"[-_.@:]+", clean)
    for t in tokens:
        if t in deny_set and t not in ("systemd", "cron", "crond", "neutrino"):
            return t

    return None


def validate_target(
    item: Dict[str, Any],
    deny_set: Optional[Set[str]] = None,
    all_set: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """
    Validates an individual target entry according to schema.
    Raises ValueError on violation.
    """
    if not isinstance(item, dict):
        raise ValueError(f"Target entry must be a JSON object, got {type(item).__name__}")

    tid = str(item.get("id") or "").strip()
    if not tid:
        raise ValueError("Target missing required non-empty string 'id'")

    tclass = str(item.get("class") or "").strip().lower()
    if not tclass:
        raise ValueError(f"Target '{tid}' missing required non-empty string 'class'")

    all_set = all_set or set(ALL_CLASSES)
    if tclass not in all_set:
        raise ValueError(
            f"Target '{tid}' specifies unknown class '{tclass}'. Allowed: {sorted(all_set)}"
        )

    kind = str(item.get("kind") or "").strip().lower()
    if kind not in VALID_TARGET_KINDS:
        raise ValueError(
            f"Target '{tid}' invalid kind '{kind}'. Must be one of: {sorted(VALID_TARGET_KINDS)}"
        )

    names_to_check = [tid]

    if kind == "systemd":
        unit = str(item.get("unit") or "").strip()
        if not unit:
            unit = tid
        if "/" in unit or "\\" in unit:
            raise ValueError(f"Target '{tid}' systemd unit must be a basename, found path: '{unit}'")
        if unit.endswith(".timer") or tid.endswith(".timer"):
            bad = unit if unit.endswith(".timer") else tid
            service_equiv = bad[:-6] + ".service"
            raise ValueError(
                f"Target '{tid}' cannot wrap timer unit '{bad}'. A timer has no ExecStart; wrap '{service_equiv}' instead."
            )
        if not SYSTEMD_UNIT_PATTERN.match(unit):
            raise ValueError(
                r"Target '{tid}' systemd unit invalid format '{unit}'. Expected ^[A-Za-z0-9:_.@+-]+\.service$"
            )
        if unit == "neutrino.service" or tid == "neutrino.service":
            raise ValueError(f"Target '{tid}' cannot wrap neutrino.service")
        names_to_check.append(unit)

    elif kind == "cron":
        path = str(item.get("path") or "").strip()
        if not path:
            raise ValueError(f"Target '{tid}' kind 'cron' requires 'path'")
        if ".." in path.split("/") or ".." in path:
            raise ValueError(f"Target '{tid}' cron path contains path escape '..': '{path}'")
        matched_prefix = None
        for pfx in ("/etc/cron.d/", "/etc/cron.daily/"):
            if path.startswith(pfx):
                matched_prefix = pfx
                break
        if not matched_prefix:
            raise ValueError(
                f"Target '{tid}' cron path must start with /etc/cron.d/ or /etc/cron.daily/: '{path}'"
            )
        subfile = path[len(matched_prefix):]
        if not subfile or "/" in subfile or subfile in (".", ".."):
            raise ValueError(f"Target '{tid}' cron path must specify a single file: '{path}'")
        names_to_check.append(subfile)

    elif kind == "slurm_wrap":
        wrapper = str(item.get("wrapper") or "").strip()
        if not wrapper:
            wrapper = tid
        if "/" in wrapper or "\\" in wrapper:
            raise ValueError(
                f"Target '{tid}' slurm_wrap wrapper cannot contain host paths: '{wrapper}'"
            )
        if not SLURM_WRAP_PATTERN.match(wrapper):
            raise ValueError(f"Target '{tid}' slurm_wrap wrapper contains invalid characters: '{wrapper}'")
        names_to_check.append(wrapper)

    deny_set = deny_set or {d.lower() for d in DENY_BASENAMES}
    deny_hit = None
    for name in names_to_check:
        hit = check_deny_match(name, deny_set)
        if hit:
            deny_hit = hit
            break

    if deny_hit:
        is_meter_only = item.get("meter_only") is True
        if not is_meter_only:
            raise ValueError(
                f"Target '{tid}' matches denied basename '{deny_hit}' without meter_only: true"
            )

    target_copy = dict(item)
    target_copy["id"] = tid
    target_copy["class"] = tclass
    target_copy["kind"] = kind
    return target_copy


def validate_recipe(data: Dict[str, Any], strict_targets: bool = True) -> Dict[str, Any]:
    """
    Validates recipe data according to Neutrino recipe schema.
    Returns normalized recipe dictionary.
    Raises ValueError on any schema violation.
    """
    if not isinstance(data, dict):
        raise ValueError("Recipe must be a JSON object")

    # 1. Version check (version == 1 or purpose == 'recipe' desk-shaped paper)
    version = data.get("version")
    if version is None and data.get("purpose") == "recipe":
        version = 1
    if version != 1:
        raise ValueError(f"Recipe version must be 1, got {version}")

    # 2. Autopilot check (default False)
    raw_auto = data.get("autopilot", False)
    if not isinstance(raw_auto, bool):
        raise ValueError(f"Recipe 'autopilot' must be a boolean, got {type(raw_auto).__name__}")
    autopilot = raw_auto

    # 3. Classes check (must be list of 11 slugs OR map slug -> {lever})
    raw_classes = data.get("classes")
    if raw_classes is None:
        raise ValueError("Recipe missing required 'classes' field")

    all_set = set(ALL_CLASSES)

    if isinstance(raw_classes, (list, tuple, set)):
        class_set = {str(c).strip().lower() for c in raw_classes}
        missing = all_set - class_set
        extra = class_set - all_set
        if missing:
            raise ValueError(f"Recipe 'classes' missing required class slugs: {sorted(missing)}")
        if extra:
            raise ValueError(f"Recipe 'classes' contains unknown class slugs: {sorted(extra)}")
    elif isinstance(raw_classes, dict):
        class_set = {str(c).strip().lower() for c in raw_classes.keys()}
        extra = class_set - all_set
        if extra:
            raise ValueError(f"Recipe 'classes' contains unknown class slugs: {sorted(extra)}")
        for k, v in raw_classes.items():
            if not isinstance(v, dict):
                raise ValueError(f"Recipe 'classes' map value for '{k}' must be an object, got {type(v).__name__}")
    else:
        raise ValueError(f"Recipe 'classes' must be a list or object, got {type(raw_classes).__name__}")

    # 4. Meter-only check (default idle, heartbeat, unspecified, etl)
    raw_meter = data.get("meter_only")
    if raw_meter is None:
        meter_only = list(DEFAULT_METER_ONLY)
    else:
        if not isinstance(raw_meter, (list, tuple, set)):
            raise ValueError(f"Recipe 'meter_only' must be a list, got {type(raw_meter).__name__}")
        meter_only = [str(c).strip().lower() for c in raw_meter]
        meter_set = set(meter_only)

        unknown_meter = meter_set - all_set
        if unknown_meter:
            raise ValueError(f"Recipe 'meter_only' contains unknown class slugs: {sorted(unknown_meter)}")

        missing_mandatory = MANDATORY_METER_ONLY - meter_set
        if missing_mandatory:
            raise ValueError(
                f"Mandatory meter-only classes cannot be removed from 'meter_only': {sorted(missing_mandatory)}"
            )

    # If classes was a map, any missing class from all_set defaults to meter_only
    if isinstance(raw_classes, dict):
        missing_from_map = all_set - class_set
        for m_cls in sorted(missing_from_map):
            if m_cls not in meter_only:
                meter_only.append(m_cls)

    meter_set = set(meter_only)
    missing_mandatory = MANDATORY_METER_ONLY - meter_set
    if missing_mandatory:
        raise ValueError(
            f"Mandatory meter-only classes cannot be removed from 'meter_only': {sorted(missing_mandatory)}"
        )

    # 5. Deny basenames
    raw_deny = data.get("deny")
    if raw_deny is None:
        deny_list = list(DENY_BASENAMES)
    else:
        if not isinstance(raw_deny, (list, tuple, set)):
            raise ValueError(f"Recipe 'deny' must be a list of basenames, got {type(raw_deny).__name__}")
        deny_list = [str(d).strip().lower() for d in raw_deny]
    deny_set = {d.lower() for d in deny_list}

    # 6. Targets validation (default [])
    raw_targets = data.get("targets")
    if raw_targets is None:
        targets = []
    elif not isinstance(raw_targets, list):
        raise ValueError(f"Recipe 'targets' must be a list, got {type(raw_targets).__name__}")
    else:
        targets = list(raw_targets)

    # Also collect per-class targets from classes map if present
    if isinstance(raw_classes, dict):
        for cname, cval in raw_classes.items():
            if isinstance(cval, dict) and "targets" in cval:
                ctargets = cval.get("targets")
                if not isinstance(ctargets, list):
                    raise ValueError(f"Class '{cname}' targets must be a list, got {type(ctargets).__name__}")
                for ct in ctargets:
                    if isinstance(ct, dict):
                        item_copy = dict(ct)
                        if "class" not in item_copy:
                            item_copy["class"] = cname
                        targets.append(item_copy)
                    else:
                        targets.append(ct)

    validated_targets = []
    seen_ids = set()

    for idx, item in enumerate(targets):
        if not isinstance(item, dict):
            raise ValueError(f"Target at index {idx} must be a JSON object, got {type(item).__name__}")
        tid = str(item.get("id") or "").strip()
        if not tid:
            raise ValueError(f"Target at index {idx} missing required string 'id'")
        if tid in seen_ids:
            raise ValueError(f"Duplicate target id '{tid}'")
        seen_ids.add(tid)

        if strict_targets:
            val_target = validate_target(item, deny_set=deny_set, all_set=all_set)
            validated_targets.append(val_target)
        else:
            validated_targets.append(dict(item))

    result = dict(data)
    result["version"] = 1
    result["autopilot"] = autopilot
    result["classes"] = list(ALL_CLASSES) if isinstance(raw_classes, (list, tuple, set)) else dict(raw_classes)
    result["meter_only"] = meter_only
    result["deny"] = deny_list
    result["targets"] = validated_targets
    return result


def load_recipe(recipe_path: str = DEFAULT_RECIPE_JSON_PATH, strict_targets: bool = True) -> Dict[str, Any]:
    """
    Loads and validates /etc/neutrino/recipe.json (or specified path).
    Returns validated recipe dictionary.
    Raises FileNotFoundError, ValueError on errors.
    """
    if not os.path.isfile(recipe_path):
        raise FileNotFoundError(f"Recipe file not found: {recipe_path}")

    with open(recipe_path, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in recipe file {recipe_path}: {e}")

    return validate_recipe(data, strict_targets=strict_targets)


def save_recipe(
    data: Dict[str, Any],
    recipe_path: str = DEFAULT_RECIPE_JSON_PATH,
    mode: int = 0o640,
    gid: Optional[int] = None,
) -> str:
    """
    Validates recipe data and atomically writes it with mode 0640 (root:neutrino when installed).
    """
    validated = validate_recipe(data)
    parent = os.path.dirname(recipe_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    if gid is None and os.geteuid() == 0:
        try:
            import grp
            gid = grp.getgrnam("neutrino").gr_gid
        except Exception:
            pass

    content = json.dumps(validated, indent=2) + "\n"
    tmp_path = f"{recipe_path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp_path, mode)
    if gid is not None and os.geteuid() == 0:
        try:
            os.chown(tmp_path, 0, gid)
        except OSError:
            pass
    os.rename(tmp_path, recipe_path)
    return recipe_path


def get_recipe_targets(recipe_path: str = DEFAULT_RECIPE_JSON_PATH, strict_targets: bool = False) -> List[Dict[str, Any]]:
    """
    Safely retrieves targets list from recipe file if it exists.
    Returns empty list if file is absent or invalid.
    """
    if not os.path.isfile(recipe_path):
        return []
    try:
        data = load_recipe(recipe_path, strict_targets=strict_targets)
        return data.get("targets", [])
    except Exception:
        return []


def get_meter_only_classes(recipe_path: str = DEFAULT_RECIPE_JSON_PATH) -> List[str]:
    """
    Safely retrieves effective meter_only list from recipe file if it exists.
    Returns DEFAULT_METER_ONLY if file is absent or invalid.
    """
    if not os.path.isfile(recipe_path):
        return list(DEFAULT_METER_ONLY)
    try:
        data = load_recipe(recipe_path)
        return list(data.get("meter_only", DEFAULT_METER_ONLY))
    except Exception:
        return list(DEFAULT_METER_ONLY)


def check_recipe_class_permitted(feature_class: str, recipe_path: str = DEFAULT_RECIPE_JSON_PATH) -> bool:
    """
    Returns True if feature_class is permitted under recipe rules:
    - feature_class in ALL_CLASSES
    - feature_class NOT in recipe.meter_only
    """
    norm = str(feature_class).strip().lower()
    if norm not in ALL_CLASSES:
        return False
    if not os.path.isfile(recipe_path):
        return norm not in MANDATORY_METER_ONLY
    try:
        rec = load_recipe(recipe_path, strict_targets=False)
        meter_only = rec.get("meter_only", DEFAULT_METER_ONLY)
        return norm not in meter_only
    except Exception:
        return norm not in MANDATORY_METER_ONLY
