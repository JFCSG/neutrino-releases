"""
runparts.py - Neutrino capture wrapper for run-parts cron directories:
/etc/cron.hourly, /etc/cron.daily, /etc/cron.weekly, /etc/cron.monthly

Rules:
1. Do NOT replace /usr/bin/run-parts.
2. Discovers operator-owned executable scripts in run-parts directories.
3. Skips vendor scripts (dpkg/rpm package owned or known vendor names like logrotate, apt-compat).
4. Sidecar wrapper pattern:
   Backs up original script to /var/lib/neutrino/apply/capture/cronrp/<name>/original with original mode.
   Rewrites the script in place to stub:
     #!/bin/sh
     exec /usr/local/bin/neutrino-run --class <cls> --id cronrp-<name> -- <backup_original_path> "$@"
   Stub must execute the backup original, not a second copy of the stub.
5. Revoke restores byte-identical original script and mode from backup.
Standard library only. Zero external dependencies.
"""

import hashlib
import json
import os
import secrets
import shutil
from typing import Dict, Any, List, Optional, Tuple, Set

from neutrino.capture.recipe import DENY_BASENAMES, check_deny_match
from neutrino.capture.vendor import is_vendor_file

RUNPARTS_DIRS = (
    "etc/cron.hourly",
    "etc/cron.daily",
    "etc/cron.weekly",
    "etc/cron.monthly",
)


def discover_runparts_targets(
    root: str = "/",
    include_vendor: bool = True,
    deny_set: Optional[Set[str]] = None,
    vendor_manifest: Optional[Set[str]] = None,
) -> List[Dict[str, Any]]:
    """
    Discovers run-parts scripts across cron.hourly, cron.daily, cron.weekly, cron.monthly.
    """
    if deny_set is None:
        deny_set = {d.lower() for d in DENY_BASENAMES}

    discovered = []

    for rel_dir in RUNPARTS_DIRS:
        abs_dir = os.path.join(root, rel_dir)
        if not os.path.isdir(abs_dir):
            continue

        try:
            entries = sorted(os.listdir(abs_dir))
        except OSError:
            continue

        for entry in entries:
            if (
                entry.startswith(".")
                or entry.endswith("~")
                or entry.endswith(".bak")
                or entry.endswith(".dpkg-old")
                or entry.endswith(".dpkg-dist")
            ):
                continue

            abs_path = os.path.join(abs_dir, entry)
            if not os.path.isfile(abs_path):
                continue

            sys_path = "/" + os.path.relpath(abs_path, root).lstrip("/")
            is_exec = os.access(abs_path, os.X_OK)

            is_vendor, vendor_reason = is_vendor_file(
                abs_path, root=root, vendor_manifest=vendor_manifest
            )

            deny_hit = check_deny_match(entry, deny_set)

            # Check if already wrapped
            already_wrapped = False
            try:
                with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read(512)
                    if "/usr/local/bin/neutrino-run" in content and "cronrp-" in content:
                        already_wrapped = True
            except Exception:
                pass

            if not is_exec:
                status = "skipped: not_executable"
            elif is_vendor:
                status = f"skipped: {vendor_reason}"
            elif deny_hit:
                status = f"skipped: denied ({deny_hit})"
            elif already_wrapped:
                status = "skipped: already_wrapped"
            else:
                status = "candidate"

            discovered.append({
                "name": entry,
                "path": sys_path,
                "abs_path": abs_path,
                "period": os.path.basename(abs_dir),
                "is_executable": is_exec,
                "is_vendor": is_vendor,
                "vendor_reason": vendor_reason,
                "status": status,
            })

    return discovered


def deploy_runparts_target(target: Dict[str, Any], root: str = "/") -> Dict[str, Any]:
    """
    Deploys run-parts stub wrapping for an operator script.
    Saves original executable to $ROOT/var/lib/neutrino/apply/capture/cronrp/<name>/original.
    Stub execs the backup original.
    """
    name = str(target.get("name") or target.get("id") or "").strip()
    path_spec = str(target.get("path") or "").strip()
    tclass = str(target.get("class") or "").strip().lower()

    if not tclass:
        raise ValueError("Missing required 'class' for run-parts target")

    if path_spec:
        rel = path_spec.lstrip("/")
        abs_script_path = os.path.join(root, rel)
    elif name:
        found = None
        for rdir in RUNPARTS_DIRS:
            cand = os.path.join(root, rdir, name)
            if os.path.isfile(cand):
                found = cand
                break
        if not found:
            raise FileNotFoundError(f"Run-parts script '{name}' not found under run-parts directories")
        abs_script_path = found
    else:
        raise ValueError("Must specify 'name' or 'path' for run-parts target")

    if not os.path.isfile(abs_script_path):
        raise FileNotFoundError(f"Run-parts script not found: {abs_script_path}")

    script_name = os.path.basename(abs_script_path)
    deny_hit = check_deny_match(script_name, set(DENY_BASENAMES))
    if deny_hit:
        raise ValueError(f"Run-parts script '{script_name}' matches denied basename '{deny_hit}'")

    with open(abs_script_path, "rb") as f:
        orig_bytes = f.read()

    orig_sha = hashlib.sha256(orig_bytes).hexdigest()
    st = os.stat(abs_script_path)

    snapshot_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", "cronrp", script_name)
    os.makedirs(snapshot_dir, exist_ok=True)

    backup_original_path = os.path.join(snapshot_dir, "original")
    with open(backup_original_path, "wb") as f:
        f.write(orig_bytes)
        f.flush()
        os.fsync(f.fileno())

    os.chmod(backup_original_path, st.st_mode | 0o700)
    try:
        os.chown(backup_original_path, st.st_uid, st.st_gid)
    except OSError:
        pass

    manifest = {
        "name": script_name,
        "kind": "runparts",
        "class": tclass,
        "path": "/" + os.path.relpath(abs_script_path, root).lstrip("/"),
        "backup_path": backup_original_path,
        "sha256": orig_sha,
        "mode": st.st_mode,
        "uid": st.st_uid,
        "gid": st.st_gid,
    }
    with open(os.path.join(snapshot_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    stub_content = (
        "#!/bin/sh\n"
        f'exec /usr/local/bin/neutrino-run --class {tclass} --id cronrp-{script_name} -- {backup_original_path} "$@"\n'
    )

    tmp_path = f"{abs_script_path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(stub_content)
        f.flush()
        os.fsync(f.fileno())

    os.chmod(tmp_path, st.st_mode | 0o755)
    try:
        os.chown(tmp_path, st.st_uid, st.st_gid)
    except OSError:
        pass

    os.replace(tmp_path, abs_script_path)

    return {
        "name": script_name,
        "path": abs_script_path,
        "status": "deployed",
        "class": tclass,
        "backup": backup_original_path,
    }


def undeploy_runparts_target(target_name_or_path: str, root: str = "/") -> Dict[str, Any]:
    """
    Restores original run-parts script to exact byte-identical content and mode.
    """
    script_name = os.path.basename(target_name_or_path)
    snapshot_dir = os.path.join(root, "var", "lib", "neutrino", "apply", "capture", "cronrp", script_name)
    manifest_file = os.path.join(snapshot_dir, "manifest.json")

    if not os.path.isfile(manifest_file):
        return {"target": target_name_or_path, "status": "no_snapshot"}

    with open(manifest_file, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    clean_sys_path = manifest["path"]
    abs_script_path = os.path.join(root, clean_sys_path.lstrip("/"))
    backup_file = os.path.join(snapshot_dir, "original")

    if os.path.isfile(backup_file):
        with open(backup_file, "rb") as s, open(abs_script_path, "wb") as d:
            d.write(s.read())
            d.flush()
            os.fsync(d.fileno())
        os.chmod(abs_script_path, manifest.get("mode", 0o755))
        try:
            os.chown(abs_script_path, manifest.get("uid", -1), manifest.get("gid", -1))
        except OSError:
            pass

    shutil.rmtree(snapshot_dir, ignore_errors=True)
    return {"target": clean_sys_path, "status": "restored"}
