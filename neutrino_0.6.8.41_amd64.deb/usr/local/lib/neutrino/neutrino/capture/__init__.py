"""
neutrino.capture package initialization.
Provides systemd and cron capture drop-in generation and deployment.
Standard library only. Zero external dependencies.
"""

from neutrino.capture.systemd import (
    load_autopilot_deny,
    load_autopilot_map,
    is_eligible_unit,
    parse_first_exec_start,
    generate_systemd_dropin,
    deploy_systemd_target,
    undeploy_systemd_target,
    get_target_status,
    dummy_target,
    dummy_status,
    attach_target,
    detach_target,
)

from neutrino.capture.cron import (
    validate_cron_path,
    prefix_cron_command,
    deploy_cron_target,
    undeploy_cron_target,
)

from neutrino.capture.deploy import (
    reconcile,
    deploy_capture,
    undeploy_capture,
    attach_operator_safe,
)
