"""
path_shim.py - PATH shim generation and environment integration for Neutrino Capture.

Rules:
1. Shims live ONLY in /usr/local/lib/neutrino/path.d/<basename>.
2. Each shim execs:
   /usr/local/bin/neutrino-run --class <cls> --id path-<basename> -- /usr/local/bin/<basename> "$@"
3. Environment enablement:
   - When path-wrap.json has >= 1 accepted commands:
     /etc/profile.d/neutrino-path.sh for interactive/login shells.
     Drop-in Environment=PATH=... on wrapped systemd units.
   - When path-wrap.json has 0 accepted commands:
     No /etc/profile.d/neutrino-path.sh, no shims, no unit drop-in Environment=.
   - CRITICAL: NEVER install /etc/systemd/system.conf.d/50-neutrino-path.conf
     with DefaultEnvironment=PATH=... (global init change prohibited).
Standard library only. Zero external dependencies.
"""

import os
import secrets
from typing import Dict, Any, List, Optional, Set

from neutrino.capture.recipe import DENY_BASENAMES, check_deny_match
from neutrino.apply.path_targets import (
    load_path_targets,
    PROHIBITED_PATH_SHIMS,
)

SHIM_REL_DIR = os.path.join("usr", "local", "lib", "neutrino", "path.d")
PROFILE_REL_PATH = os.path.join("etc", "profile.d", "neutrino-path.sh")


def discover_path_targets(root: str = "/") -> List[Dict[str, Any]]:
    """
    Discovers candidate executables under /usr/local/bin.
    Filters out prohibited binaries, shell interpreters, and deny-list basenames.
    """
    local_bin = os.path.join(root, "usr", "local", "bin")
    if not os.path.isdir(local_bin):
        return []

    path_data = load_path_targets(root=root)
    accepted_map = {
        c["basename"]: c for c in path_data.get("commands", [])
        if isinstance(c, dict) and "basename" in c
    }

    deny_set = {d.lower() for d in DENY_BASENAMES}
    discovered = []

    try:
        entries = sorted(os.listdir(local_bin))
    except OSError:
        return []

    for entry in entries:
        if entry.startswith(".") or entry.endswith("~") or entry.endswith(".bak"):
            continue

        p = os.path.join(local_bin, entry)
        if not os.path.isfile(p):
            continue

        is_exec = os.access(p, os.X_OK)
        is_neutrino = entry.lower().startswith("neutrino")
        is_prohibited = is_neutrino or (entry.lower() in PROHIBITED_PATH_SHIMS)
        deny_hit = check_deny_match(entry, deny_set)

        is_already_shim = False
        try:
            with open(p, "rb") as sf:
                head = sf.read(512)
                if b"neutrino-run" in head or b"Neutrino PATH shim" in head or b"/usr/local/lib/neutrino" in head:
                    is_already_shim = True
        except Exception:
            pass

        acc_info = accepted_map.get(entry)
        is_accepted = bool(acc_info and acc_info.get("accepted") is True)
        mapped_class = acc_info.get("class") if acc_info else None

        if not is_exec:
            status = "skipped: not_executable"
        elif is_already_shim:
            status = f"skipped: already_neutrino_shim ({entry})"
        elif is_prohibited:
            status = f"skipped: prohibited ({entry})"
        elif deny_hit:
            status = f"skipped: denied ({deny_hit})"
        elif is_accepted:
            status = "accepted"
        else:
            status = "candidate"

        discovered.append({
            "basename": entry,
            "path": "/usr/local/bin/" + entry,
            "abs_path": p,
            "is_executable": is_exec,
            "accepted": is_accepted,
            "mapped_class": mapped_class,
            "status": status,
        })

    return discovered


def deploy_path_shim(cmd_entry: Dict[str, Any], root: str = "/") -> str:
    """
    Deploys a single executable shim in /usr/local/lib/neutrino/path.d/<basename>.
    """
    basename = str(cmd_entry.get("basename") or "").strip()
    tclass = str(cmd_entry.get("class") or "").strip().lower()

    if not basename or not tclass:
        raise ValueError("Missing basename or class for path shim")

    if basename.lower() in PROHIBITED_PATH_SHIMS:
        raise ValueError(f"Command '{basename}' is prohibited from PATH shimming")

    deny_hit = check_deny_match(basename, set(DENY_BASENAMES))
    if deny_hit:
        raise ValueError(f"Command '{basename}' matches denied basename '{deny_hit}'")

    shim_dir = os.path.join(root, SHIM_REL_DIR)
    os.makedirs(shim_dir, exist_ok=True)

    shim_path = os.path.join(shim_dir, basename)
    shim_content = (
        "#!/bin/sh\n"
        f'exec /usr/local/bin/neutrino-run --class {tclass} --id path-{basename} -- /usr/local/bin/{basename} "$@"\n'
    )

    tmp_path = f"{shim_path}.tmp.{secrets.token_hex(4)}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(shim_content)
        f.flush()
        os.fsync(f.fileno())

    os.chmod(tmp_path, 0o755)
    os.replace(tmp_path, shim_path)
    return shim_path


def undeploy_path_shim(basename: str, root: str = "/") -> bool:
    """Removes a shim executable from path.d."""
    shim_path = os.path.join(root, SHIM_REL_DIR, basename)
    if os.path.isfile(shim_path):
        try:
            os.unlink(shim_path)
            return True
        except OSError:
            pass
    return False


def sync_path_environment(root: str = "/") -> Dict[str, Any]:
    """
    Synchronizes /usr/local/lib/neutrino/path.d shims and /etc/profile.d/neutrino-path.sh
    based on the accepted commands in path-wrap.json.

    - When >= 1 accepted command:
      Installs all shims and /etc/profile.d/neutrino-path.sh.
    - When 0 accepted commands:
      Removes /etc/profile.d/neutrino-path.sh and all shims.
    - NEVER creates /etc/systemd/system.conf.d/50-neutrino-path.conf.
    """
    path_data = load_path_targets(root=root)
    accepted_cmds = [
        c for c in path_data.get("commands", [])
        if isinstance(c, dict) and c.get("accepted") is True
    ]

    profile_path = os.path.join(root, PROFILE_REL_PATH)
    shim_dir = os.path.join(root, SHIM_REL_DIR)

    if accepted_cmds:
        os.makedirs(shim_dir, exist_ok=True)
        deployed_shims = []
        for cmd in accepted_cmds:
            try:
                deployed_shims.append(deploy_path_shim(cmd, root=root))
            except Exception:
                pass

        # Install /etc/profile.d/neutrino-path.sh
        os.makedirs(os.path.dirname(profile_path), exist_ok=True)
        profile_content = (
            "# Neutrino PATH wrap for interactive/login shells\n"
            'case ":$PATH:" in\n'
            '  *:/usr/local/lib/neutrino/path.d:*) ;;\n'
            '  *) export PATH="/usr/local/lib/neutrino/path.d:$PATH" ;;\n'
            "esac\n"
        )
        tmp_prof = f"{profile_path}.tmp.{secrets.token_hex(4)}"
        with open(tmp_prof, "w", encoding="utf-8") as f:
            f.write(profile_content)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_prof, 0o644)
        os.replace(tmp_prof, profile_path)

        return {
            "profile_installed": True,
            "profile_path": profile_path,
            "shim_count": len(deployed_shims),
            "shims": deployed_shims,
        }
    else:
        # Zero accepted commands: remove profile.d and all shims
        if os.path.isfile(profile_path):
            try:
                os.unlink(profile_path)
            except OSError:
                pass

        if os.path.isdir(shim_dir):
            try:
                for f in os.listdir(shim_dir):
                    fp = os.path.join(shim_dir, f)
                    if os.path.isfile(fp):
                        os.unlink(fp)
            except OSError:
                pass

        return {
            "profile_installed": False,
            "profile_path": None,
            "shim_count": 0,
            "shims": [],
        }
