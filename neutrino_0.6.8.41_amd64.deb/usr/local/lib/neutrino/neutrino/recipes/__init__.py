"""
neutrino.recipes - Verified workload optimization recipes, guides, and registry.
Standard library only. Zero external dependencies. Zero host literals.
"""

from typing import Any, Dict, List, Optional

from neutrino.recipes.registry import (
    RECIPE_REGISTRY,
    REGISTRY_BY_ID,
    list_registry,
    get_registry_recipe,
    get_recipes_for_class,
)

RECIPES: Dict[str, dict] = {
    "compile": {
        "id": "compile",
        "title": "Compile CI",
        "class": "compile",
        "policy": "materialize",
        "summary": "Optimizes Python bytecode compilation workloads during CI/CD package builds and container assembly.",
        "invocation": "neutrino-run --class compile -- python3 -m compileall /path/to/project",
        "details": [
            "Workload Class: compile",
            "Active Policy: materialize (PYTHONPYCACHEPREFIX)",
            "Invocation: neutrino-run --class compile -- python3 -m compileall /path/to/project",
            "Optional Opt-In Shims: eval \"$(neutrino-enable-shims)\" allows per-script interception without system PATH mutations."
        ],
        "disclaimer": "measured on matched-work campaigns; your box will differ",
    },
    "batch": {
        "id": "batch",
        "title": "Packed Batch Unit",
        "class": "batch",
        "policy": "occupancy",
        "summary": "Applies occupancy packing to long-running or periodic customer systemd services.",
        "invocation": "sudo neutrino catalog allow --unit <unit>.service --class batch && sudo neutrino catalog adopt --unit <unit>.service",
        "details": [
            "Workload Class: batch",
            "Active Policy: occupancy (pack-then-idle)",
            "Systemd Drop-in: /etc/systemd/system/<unit>.service.d/neutrino.conf",
            "Inspection: neutrino catalog preview --unit <unit>.service",
            "Adoption: sudo neutrino catalog allow --unit <unit>.service --class batch && sudo neutrino catalog adopt --unit <unit>.service",
            "Unadopt: sudo neutrino catalog unadopt --unit <unit>.service"
        ],
        "disclaimer": "measured on matched-work campaigns; your box will differ",
    },
    "mq": {
        "id": "mq",
        "title": "MQ Persist",
        "class": "mq",
        "policy": "batched-fsync",
        "summary": "Batches synchronous disk writes for message log flush loops and append-heavy data ingestion.",
        "invocation": "neutrino-run --class mq -- neutrino-mq-append --path /var/lib/neutrino/mq/queue.log --records 1000",
        "details": [
            "Workload Class: mq",
            "Active Policy: batched-fsync",
            "Invocation: neutrino-run --class mq -- neutrino-mq-append --path /var/lib/neutrino/mq/queue.log --records 1000",
            "Direct Helper: neutrino-mq-append automatically classified as class 'mq' under C1 classifier."
        ],
        "disclaimer": "measured on matched-work campaigns; your box will differ",
    },
    "oltp": {
        "id": "oltp",
        "title": "SQLite Group-Commit",
        "class": "oltp",
        "policy": "group-commit",
        "summary": "Bundles individual transactional row insertions into cooperative group-commit windows with full durability.",
        "invocation": "neutrino-run --class oltp -- neutrino-oltp-load --path /var/lib/neutrino/oltp/workload.db --records 500",
        "details": [
            "Workload Class: oltp",
            "Active Policy: group-commit",
            "Invocation: neutrino-run --class oltp -- neutrino-oltp-load --path /var/lib/neutrino/oltp/workload.db --records 500",
            "Direct Helper: neutrino-oltp-load automatically classified as class 'oltp' under C1 classifier."
        ],
        "disclaimer": "measured on matched-work campaigns; your box will differ",
    },
}


def list_recipes() -> List[dict]:
    """Return all available recipes sorted by ID."""
    return [RECIPES[k] for k in sorted(RECIPES.keys())]


def get_recipe(recipe_id: str) -> Optional[dict]:
    """Get a recipe by ID, or None if not found."""
    r = RECIPES.get(recipe_id.strip().lower())
    if r is not None:
        return r
    return get_registry_recipe(recipe_id)


def format_recipe_list() -> str:
    """Format available recipes into a clean text table."""
    lines = [
        "=== Neutrino Workload Optimization Recipes ===",
        f"{'RECIPE ID':<12} {'CLASS':<10} {'POLICY':<16} {'SUMMARY'}",
        "-" * 80,
    ]
    for r in list_recipes():
        lines.append(f"{r['id']:<12} {r['class']:<10} {r['policy']:<16} {r['summary']}")
    lines.append("")
    lines.append("Use 'neutrino recipe show <id>' to display detailed recipe instructions.")
    return "\n".join(lines)


def format_recipe_show(recipe_id: str) -> str:
    """Format detailed information for a single recipe."""
    r = get_recipe(recipe_id)
    if not r:
        raise KeyError(f"Recipe '{recipe_id}' not found.")

    lines = [
        f"=== Recipe: {r.get('title', r['id'])} ({r['id']}) ===",
        f"Workload Class: {r['class']}",
        f"Default Policy: {r.get('policy', r.get('lever', 'none'))}",
        f"Summary:        {r.get('summary', r.get('wrap', ''))}",
        "",
        "Invocation:",
        f"  {r.get('invocation', r.get('trigger', ''))}",
        "",
        "Details & Guidance:",
    ]
    for d in r.get("details", []):
        lines.append(f"  - {d}")
    lines.append("")
    disclaimer = r.get("disclaimer", "measured on matched-work campaigns; your box will differ")
    lines.append(f"Note: Energy savings {disclaimer}.")
    return "\n".join(lines)


DEFAULT_RECIPE_TEMPLATE_PATH: str = "/opt/neutrino/share/recipe.default.json"

DEFAULT_AUTOPILOT_RECIPE_CLASSES: Dict[str, dict] = {
    "compile": {"lever": "materialize"},
    "batch": {"lever": "occupancy"},
    "oltp": {"lever": "group-commit"},
    "mq": {"lever": "batched-fsync"},
    "etl": {"lever": "residency-stream"},
    "infer-cpu": {"lever": "materialize"},
    "hpc": {"lever": "occupancy"},
    "render": {"lever": "occupancy"},
}

DEFAULT_RECIPE: Dict[str, Any] = {
    "version": 1,
    "classes": DEFAULT_AUTOPILOT_RECIPE_CLASSES,
}
