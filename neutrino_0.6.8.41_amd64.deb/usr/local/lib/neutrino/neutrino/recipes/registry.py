"""
neutrino.recipes.registry - Frozen Neutrino Workload Optimization Recipe Registry.
Standard library only. Zero external dependencies. Zero host literals.

STACK RULE:
prefix-KV = prefill. dump_guard + commit-stop = decode. Occupancy = CPU pack-then-idle.
Apply all armed recipes that match the job class. Do not require a second ON per lever.
"""

from typing import Any, Dict, List, Optional

# STACK RULE:
# prefix-KV = prefill. dump_guard + commit-stop = decode. Occupancy = CPU pack-then-idle.
# Apply all armed recipes that match the job class. Do not require a second ON per lever.

RECIPE_REGISTRY: List[Dict[str, Any]] = [
    # CPU (RAPL uj_delta, already metered)
    {
        "id": "r-batch-occupancy",
        "class": "batch / hpc / render",
        "classes": ["batch", "hpc", "render"],
        "lever": "occupancy",
        "trigger": "--class batch / hpc / render",
        "wrap": "pack workers then idle; stamp policy",
        "never": "sysfs, governor",
        "measured": "−57.9% package  batch A/B n=5",
        "stacks_with": "N/A",
        "auto": True,
        "rail": "cpu",
    },
    {
        "id": "r-compile-materialize",
        "class": "compile",
        "classes": ["compile"],
        "lever": "materialize",
        "trigger": "--class compile",
        "wrap": "reuse __pycache__ / artifact dir if present",
        "never": "delete source",
        "measured": "−99.3% compile-pub",
        "stacks_with": "N/A",
        "auto": True,
        "rail": "cpu",
    },
    {
        "id": "r-infer-cpu-materialize",
        "class": "infer-cpu",
        "classes": ["infer-cpu"],
        "lever": "materialize",
        "trigger": "--class infer-cpu",
        "wrap": "reuse fitted weights/LUT",
        "never": "change model file",
        "measured": "−99.5% infer-cpu-pub",
        "stacks_with": "N/A",
        "auto": True,
        "rail": "cpu",
    },
    {
        "id": "r-oltp-groupcommit",
        "class": "oltp",
        "classes": ["oltp"],
        "lever": "group-commit",
        "trigger": "--class oltp",
        "wrap": "one txn / batch commit when caller uses neutrino-run wrapper",
        "never": "rewrite customer SQL engine",
        "measured": "−94.1% F0 /tmp; F1 disk direction-only",
        "stacks_with": "r-oltp-pool",
        "auto": True,
        "rail": "cpu",
    },
    {
        "id": "r-mq-fsync",
        "class": "mq",
        "classes": ["mq"],
        "lever": "batched-fsync",
        "trigger": "--class mq",
        "wrap": "fsync every K records",
        "never": "Kafka broker config",
        "measured": "−80.4% mq-fsync",
        "stacks_with": "N/A",
        "auto": True,
        "rail": "cpu",
    },
    {
        "id": "r-oltp-pool",
        "class": "oltp",
        "classes": ["oltp"],
        "lever": "connect-pool",
        "trigger": "--class oltp",
        "wrap": "one connection per job",
        "never": "change TLS certs",
        "measured": "−29.7% F2 noisy",
        "stacks_with": "r-oltp-groupcommit",
        "auto": True,
        "rail": "cpu",
    },
    {
        "id": "r-hpc-wrap",
        "class": "hpc",
        "classes": ["hpc"],
        "lever": "occupancy + J/core-hr",
        "trigger": "neutrino-srun / neutrino-bsub",
        "wrap": "env SLURM/LSF stamp",
        "never": "Spank, slurmctld",
        "measured": "wrap + J/core-hr (no fake −9.4%)",
        "stacks_with": "r-batch-occupancy",
        "auto": True,
        "rail": "cpu",
    },
    {
        "id": "r-etl-stream",
        "class": "etl",
        "classes": ["etl"],
        "lever": "residency",
        "trigger": "--class etl",
        "wrap": "stream vs retain",
        "never": "drop etl if still <5%",
        "measured": "−2.1% weak; auto=false stays",
        "stacks_with": "N/A",
        "auto": False,
        "rail": "cpu",
    },
    # GPU (NVML / llama-server request wrap — no server restart, no extra flag)
    {
        "id": "r-prefix-kv",
        "class": "infer-gpu",
        "classes": ["infer-gpu", "infer-gpu-chat", "infer-gpu-repeat", "infer-gpu-copy", "infer-gpu-agent", "think", "llama-server"],
        "lever": "prefix-KV",
        "trigger": "infer-gpu / llama-server jobs when autopilot ON",
        "wrap": "send cache_prompt=true; keep caller max_tokens / n_predict UNSET (server default); do not pin 512",
        "never": "change GGUF, template, quant",
        "measured": "−7.9% package + 4.3× prefill; A cold; 28/28 letters; not 10% lock",
        "stacks_with": "r-dump-guard, r-commit-stop",
        "auto": True,
        "rail": "gpu",
    },
    {
        "id": "r-dump-guard",
        "class": "infer-gpu",
        "classes": ["infer-gpu", "infer-gpu-chat", "infer-gpu-repeat", "infer-gpu-copy", "infer-gpu-agent", "think", "llama-server"],
        "lever": "dump_guard",
        "trigger": "same infer wrap",
        "wrap": "suppress junk/retry decode already measured on T11",
        "never": "rewrite weights",
        "measured": "T11 −38.7% / 3.57× on that mix",
        "stacks_with": "r-prefix-kv, r-commit-stop",
        "auto": True,
        "rail": "gpu",
    },
    {
        "id": "r-commit-stop",
        "class": "infer-gpu",
        "classes": ["infer-gpu", "infer-gpu-chat", "infer-gpu-repeat", "infer-gpu-copy", "infer-gpu-agent", "think", "llama-server"],
        "lever": "commit-stop",
        "trigger": "same infer wrap",
        "wrap": "stop on first scored letter / commit token; do not set n_predict",
        "never": "change chat template mid-job",
        "measured": "letter/commit stop; no standalone −28.9%",
        "stacks_with": "r-prefix-kv, r-dump-guard",
        "auto": True,
        "rail": "gpu",
    },
]

REGISTRY_BY_ID: Dict[str, Dict[str, Any]] = {r["id"]: r for r in RECIPE_REGISTRY}


def list_registry() -> List[Dict[str, Any]]:
    """Return all recipes in the frozen registry."""
    return list(RECIPE_REGISTRY)


def get_registry_recipe(recipe_id: str) -> Optional[Dict[str, Any]]:
    """Return recipe dict by registry ID (e.g. r-batch-occupancy) or None."""
    return REGISTRY_BY_ID.get(recipe_id.strip().lower())


def get_recipes_for_class(job_class: str) -> List[Dict[str, Any]]:
    """
    Return all registry recipes matching job_class.
    STACK RULE:
    prefix-KV = prefill. dump_guard + commit-stop = decode. Occupancy = CPU pack-then-idle.
    Apply all armed recipes that match the job class. Do not require a second ON per lever.
    """
    if not job_class:
        return []
    norm = str(job_class).strip().lower()
    matches = []
    for r in RECIPE_REGISTRY:
        if norm in r.get("classes", []):
            matches.append(r)
    return matches
